const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const CUSTOMER_UID = "customer_alice";
const OTHER_UID = "customer_bob";
const ADMIN_UID = "admin_owais";
const ADMIN_EMAIL = "owaispeerxada@gmail.com";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write any collection", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("products").get());
  await assertFails(unauthDb.collection("users").doc(CUSTOMER_UID).get());
  await assertFails(unauthDb.collection("orders").get());
});

test("Customer profile PII is isolated per user and cannot be listed by customers", async () => {
  const now = new Date(Date.now() - 2000);
  const aliceDb = testEnv.authenticatedContext(CUSTOMER_UID, { email: "alice@example.com", email_verified: true }).firestore();
  const bobDb = testEnv.authenticatedContext(OTHER_UID, { email: "bob@example.com", email_verified: true }).firestore();

  await assertSucceeds(
    aliceDb.collection("users").doc(CUSTOMER_UID).set({
      userId: CUSTOMER_UID,
      fullName: "Alice Kashmiri",
      email: "alice@example.com",
      phone: "+91 9876543210",
      preferredScent: "Oud & Saffron",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Bob cannot read Alice's profile or list users
  await assertFails(bobDb.collection("users").doc(CUSTOMER_UID).get());
  await assertFails(bobDb.collection("users").get());

  // Customer cannot self-assign admin role
  await assertFails(
    aliceDb.collection("admin_roles").doc(CUSTOMER_UID).set({
      uid: CUSTOMER_UID,
      email: "alice@example.com",
      role: "ADMIN",
      grantedBy: CUSTOMER_UID,
      createdAt: now,
    })
  );
});

test("Email spoofing test: unverified admin email is rejected", async () => {
  const now = new Date(Date.now() - 2000);
  const spoofedDb = testEnv.authenticatedContext("spoof_uid", {
    email: ADMIN_EMAIL,
    email_verified: false,
  }).firestore();

  await assertFails(
    spoofedDb.collection("products").doc("prod_1").set({
      name: "Spoofed Oud",
      categoryId: "attars",
      categoryName: "Attars",
      groupType: "ATTARS",
      priceInr: 999,
      stockCount: 10,
      featured: true,
      enabled: true,
      description: "Test",
      createdAt: now,
      updatedAt: now,
    })
  );
});

test("Verified admin can manage products, categories, store_settings, and orders", async () => {
  const now = new Date(Date.now() - 2000);
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, {
    email: ADMIN_EMAIL,
    email_verified: true,
  }).firestore();

  await assertSucceeds(
    adminDb.collection("categories").doc("cat_oud").set({
      name: "Oud Collection",
      groupType: "ATTARS",
      subtitle: "Pure aged oud oils",
      displayOrder: 1,
      enabled: true,
      drawableResName: "img_featured_oud",
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    adminDb.collection("products").doc("prod_khamrah").set({
      name: "Khamrah Royal Reserve",
      subtitle: "Spiced Cinnamon · Amber Oud",
      categoryId: "cat_oud",
      categoryName: "Oud Collection",
      groupType: "PERFUMES",
      priceInr: 2499,
      discountPriceInr: 2199,
      stockCount: 25,
      featured: true,
      enabled: true,
      demoItem: false,
      badge: "NEW",
      drawableResName: "img_hero_banner",
      imageUrls: [],
      variantLabels: ["100 ml"],
      variantPrices: [2199],
      description: "Rich Arabian perfume curated by THE OWAIS OFFICIAL.",
      rating: 4.9,
      reviewCount: 12,
      createdAt: now,
      updatedAt: now,
    })
  );

  await assertSucceeds(
    adminDb.collection("store_settings").doc("config").set({
      storeName: "OWAIS PERFUMES & ISLAMIC STORE",
      brandOfficial: "THE OWAIS OFFICIAL",
      tagline: "Luxury Fragrances. Authentic Islamic Essentials.",
      location: "Kupwara, Jammu & Kashmir, India",
      whatsappNumber: "+91 9906577880",
      instagramHandle: "@mrowais_15",
      instagramUrl: "https://www.instagram.com/mrowais_15/",
      deliveryChargeInr: 99,
      freeDeliveryThresholdInr: 1999,
      codEnabled: false,
      upiId: "owaisstore@upi",
      upiPayeeName: "Owais Perfumes & Islamic Store",
      paymentInstructions: "Pay via UPI and submit transaction reference.",
      aboutStory: "Authentic fragrances from Kupwara.",
      updatedAt: now,
    })
  );
});

test("Cart, wishlist, and order security: user-scoped queries succeed, self-marking order Paid fails, admin verification succeeds", async () => {
  const now = new Date(Date.now() - 3000);
  const aliceDb = testEnv.authenticatedContext(CUSTOMER_UID, { email: "alice@example.com", email_verified: true }).firestore();
  const bobDb = testEnv.authenticatedContext(OTHER_UID, { email: "bob@example.com", email_verified: true }).firestore();
  const adminDb = testEnv.authenticatedContext(ADMIN_UID, { email: ADMIN_EMAIL, email_verified: true }).firestore();

  // Cart & wishlist scoped writes + filtered list queries succeed
  await assertSucceeds(
    aliceDb.collection("cart").doc("cart_1").set({
      userId: CUSTOMER_UID,
      productId: "prod_1",
      productName: "Khamrah EDP",
      categoryName: "Khamrah",
      variantLabel: "100 ml",
      unitPriceInr: 2199,
      quantity: 1,
      createdAt: now,
      updatedAt: now,
    })
  );
  await assertSucceeds(aliceDb.collection("cart").where("userId", "==", CUSTOMER_UID).get());
  await assertFails(aliceDb.collection("cart").get());

  // Customer cannot forge a Verified payment status on order creation
  await assertFails(
    aliceDb.collection("orders").doc("OWS_FORGED").set({
      userId: CUSTOMER_UID,
      orderNumber: "OWS-9001",
      customerName: "Alice",
      customerPhone: "+91 9900112233",
      deliveryAddress: "Kupwara, J&K",
      itemsSummary: "Khamrah x1",
      itemCount: 1,
      subtotalInr: 2199,
      deliveryChargeInr: 0,
      totalAmountInr: 2199,
      paymentPreference: "UPI",
      paymentStatus: "Verified",
      orderStatus: "Pending",
      idempotencyKey: "idem_forged_1",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Valid Pending / Unverified order succeeds
  await assertSucceeds(
    aliceDb.collection("orders").doc("OWS_VALID_1").set({
      userId: CUSTOMER_UID,
      orderNumber: "OWS-9002",
      customerName: "Alice",
      customerEmail: "alice@example.com",
      customerPhone: "+91 9900112233",
      deliveryAddress: "Kupwara, J&K",
      itemsSummary: "Khamrah x1",
      itemCount: 1,
      subtotalInr: 2199,
      deliveryChargeInr: 99,
      totalAmountInr: 2298,
      paymentPreference: "UPI",
      paymentStatus: "Unverified",
      orderStatus: "Pending",
      idempotencyKey: "idem_valid_1",
      createdAt: now,
      updatedAt: now,
    })
  );

  // Filtered order query succeeds, unfiltered fails for customer
  await assertSucceeds(aliceDb.collection("orders").where("userId", "==", CUSTOMER_UID).get());
  await assertFails(aliceDb.collection("orders").get());
  await assertFails(bobDb.collection("orders").doc("OWS_VALID_1").get());

  // Customer can submit UPI reference -> Pending Verification, but CANNOT mark Verified
  await assertFails(
    aliceDb.collection("orders").doc("OWS_VALID_1").update({
      paymentStatus: "Verified",
      updatedAt: new Date(Date.now() - 1000),
    })
  );
  await assertSucceeds(
    aliceDb.collection("orders").doc("OWS_VALID_1").update({
      upiTransactionRef: "UTR4455667788",
      paymentStatus: "Pending Verification",
      updatedAt: new Date(Date.now() - 1000),
    })
  );

  // Admin can list all orders and confirm payment & shipping status
  await assertSucceeds(adminDb.collection("orders").get());
  await assertSucceeds(
    adminDb.collection("orders").doc("OWS_VALID_1").update({
      paymentStatus: "Verified",
      orderStatus: "Confirmed",
      updatedAt: new Date(Date.now() - 500),
    })
  );
});
