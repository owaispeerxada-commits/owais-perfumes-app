# Google Play Store Preparation Guide — Owais Perfumes & Islamic Store

## 1. Store Listing Metadata
- **App Title (<=30 chars):** `Owais Perfumes & Islamic Store` (30 characters)
- **Package Name:** `com.owais.perfumes.islamicstore`
- **Version:** `1.0.0` (`versionCode = 1`)
- **Brand:** THE OWAIS OFFICIAL
- **Location:** Kupwara, Jammu & Kashmir, India
- **Support Email:** `owaispeerxada@gmail.com`
- **Support WhatsApp:** `+91 9906577880`
- **Instagram:** `@mrowais_15`

### Short Description (<=80 chars)
`Luxury perfumes, pure attars & Islamic essentials by THE OWAIS OFFICIAL.`

### Full Description
Assalamu Alaikum and welcome to **OWAIS PERFUMES & ISLAMIC STORE** (by **THE OWAIS OFFICIAL**, Kupwara, Jammu & Kashmir, India).

Explore luxury fragrances and authentic Islamic essentials crafted for every occasion:
- **Perfumes & Attars:** Arabic Perfumes, Luxury & Premium Perfumes, Oud Collection, Khamrah, Wafa, Mask Oud, White Oud, Roll-on Attars, and 24-Hour Long Lasting Fragrances.
- **Islamic Essentials:** Velvet Holy Quran Pak, Authentic Islamic Books, Turkish Velvet Prayer Mats (Janamaz), Embroidered Topi, Sandalwood & Digital Tasbeeh, Peelu Miswak, Islamic Wall Frames, Gift Sets, and Hijab Accessories.
- **Seamless Ordering:** Browse in Guest mode or sign in with Google for saved delivery addresses, UPI reference submission, Cash on Delivery (store-controlled), WhatsApp order confirmation (+91 9906577880), and real-time order tracking.

---

## 2. Declared Permissions & Play Policy Compliance
- `android.permission.INTERNET` & `ACCESS_NETWORK_STATE`: Required for Firebase Authentication, Cloud Firestore catalog/order sync, and product image loading.
- `android.permission.POST_NOTIFICATIONS`: Requested at runtime on Android 13+ solely for order status update notifications.
- **Media Selection:** Uses Android zero-permission Photo Picker (`ActivityResultContracts.PickVisualMedia`) in the Admin Dashboard — no `READ_MEDIA_IMAGES` or `READ_EXTERNAL_STORAGE` permissions requested.

---

## 3. Data Safety Form Reference
- **Data Collected:** Name, verified Email Address (via Google Sign-In), Phone Number, Delivery Address, and Order History (in-app purchases/orders).
- **Purpose:** App functionality (customer account, checkout prefill, order fulfillment, UPI verification, and status notifications).
- **Data Sharing:** Not sold or shared with third-party advertisers.
- **Encryption & Deletion:** Encrypted in transit via HTTPS/TLS. Customers can delete saved delivery addresses inside the Profile tab or contact `owaispeerxada@gmail.com` for full account/data deletion.

---

## 4. Release Build & Play Console Checklist
1. **Generate Upload Keystore** (never commit `.jks` or passwords to source control):
   ```bash
   keytool -genkeypair -v -keystore my-upload-key.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000
   ```
2. **Add Release Signing SHA-1 / SHA-256** to Firebase Project (`gen-lang-client-0169902578`) in Firebase Console before distributing release AABs so Google Sign-In works on Play-signed builds.
3. **Enable Firebase Storage & FCM (Optional Console Setup):**
   - In Firebase Console -> Storage -> Get Started, create the default bucket and deploy `storage.rules` if admin image uploads via mobile are used.
   - Cloud Messaging server-side push triggers (e.g., Cloud Functions on `orders/{orderId}` updates) can be added if background push notifications while the app is closed are needed.
4. **Build Signed App Bundle (`.aab`):**
   ```bash
   KEYSTORE_PATH=/path/to/my-upload-key.jks STORE_PASSWORD=... KEY_PASSWORD=... gradle :app:bundleRelease
   ```
5. **Upload `.aab`** to Google Play Console -> Closed Testing / Production, complete Privacy Policy URL hosting, Data Safety, Content Rating (Everyone), and Store Graphics (App Icon 512x512, Feature Graphic 1024x500, Phone & Tablet screenshots).
