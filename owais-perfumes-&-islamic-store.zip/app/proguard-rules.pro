# ProGuard / R8 Rules for Owais Perfumes & Islamic Store

-keepattributes Signature
-keepattributes *Annotation*
-keepattributes EnclosingMethod
-keepattributes InnerClasses

# Preserve @Keep annotated Firestore models and serialization classes
-keep @androidx.annotation.Keep class * {
    *;
}
-keepclassmembers class * {
    @androidx.annotation.Keep *;
}

-keep class com.example.data.remote.** { *; }
-keepclassmembers class com.example.data.remote.** { *; }

-keep class com.google.firebase.Timestamp { *; }
-keep class com.google.firebase.firestore.** { *; }
-dontwarn com.google.firebase.firestore.**
