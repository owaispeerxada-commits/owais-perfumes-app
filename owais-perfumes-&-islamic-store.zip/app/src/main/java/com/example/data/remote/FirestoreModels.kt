package com.example.data.remote

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@Keep
@IgnoreExtraProperties
data class FsUserProfile(
    @DocumentId val id: String = "",
    val userId: String = "",
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val preferredScent: String = "Oud & Saffron",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FsDeliveryAddress(
    @DocumentId val id: String = "",
    val userId: String = "",
    val label: String = "Home",
    val recipientName: String = "",
    val phone: String = "",
    val streetAddress: String = "",
    val city: String = "Kupwara",
    val state: String = "Jammu & Kashmir",
    val pincode: String = "193222",
    val defaultAddress: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FsCategory(
    @DocumentId val id: String = "",
    val name: String = "",
    val groupType: String = "PERFUMES",
    val subtitle: String = "",
    val displayOrder: Int = 0,
    val enabled: Boolean = true,
    val drawableResName: String = "img_category_perfumes",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FsProduct(
    @DocumentId val id: String = "",
    val name: String = "",
    val subtitle: String = "",
    val categoryId: String = "",
    val categoryName: String = "",
    val groupType: String = "PERFUMES",
    val priceInr: Int = 0,
    val discountPriceInr: Int = 0,
    val stockCount: Int = 0,
    val featured: Boolean = false,
    val enabled: Boolean = true,
    val demoItem: Boolean = true,
    val badge: String = "DEMO",
    val drawableResName: String = "img_hero_banner",
    val imageUrls: List<String> = emptyList(),
    val variantLabels: List<String> = emptyList(),
    val variantPrices: List<Int> = emptyList(),
    val topNotes: String = "",
    val heartNotes: String = "",
    val baseNotes: String = "",
    val originOrMaterial: String = "",
    val description: String = "",
    val rating: Double = 4.8,
    val reviewCount: Int = 0,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FsCartItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val productId: String = "",
    val productName: String = "",
    val categoryName: String = "",
    val variantLabel: String = "",
    val unitPriceInr: Int = 0,
    val quantity: Int = 1,
    val drawableResName: String = "img_hero_banner",
    val imageUrl: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FsWishlistItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val productId: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FsOrder(
    @DocumentId val id: String = "",
    val userId: String = "",
    val orderNumber: String = "",
    val customerName: String = "",
    val customerEmail: String = "",
    val customerPhone: String = "",
    val deliveryAddress: String = "",
    val itemsSummary: String = "",
    val itemCount: Int = 1,
    val subtotalInr: Int = 0,
    val deliveryChargeInr: Int = 0,
    val totalAmountInr: Int = 0,
    val paymentPreference: String = "WHATSAPP_CONFIRM",
    val paymentStatus: String = "Unverified",
    val upiTransactionRef: String = "",
    val orderStatus: String = "Pending",
    val whatsappMessage: String = "",
    val idempotencyKey: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FsBanner(
    @DocumentId val id: String = "",
    val title: String = "",
    val subtitle: String = "",
    val badgeText: String = "",
    val ctaText: String = "Shop Collection",
    val targetCategory: String = "",
    val drawableResName: String = "img_hero_banner",
    val imageUrl: String = "",
    val active: Boolean = true,
    val displayOrder: Int = 0,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FsStoreSettings(
    @DocumentId val id: String = "",
    val storeName: String = "OWAIS PERFUMES & ISLAMIC STORE",
    val brandOfficial: String = "THE OWAIS OFFICIAL",
    val tagline: String = "Luxury Fragrances. Authentic Islamic Essentials.",
    val location: String = "Kupwara, Jammu & Kashmir, India",
    val whatsappNumber: String = "+91 9906577880",
    val instagramHandle: String = "@mrowais_15",
    val instagramUrl: String = "https://www.instagram.com/mrowais_15/",
    val deliveryChargeInr: Int = 99,
    val freeDeliveryThresholdInr: Int = 1999,
    val codEnabled: Boolean = true,
    val upiId: String = "owaisperfumes@upi",
    val upiPayeeName: String = "Owais Perfumes & Islamic Store",
    val paymentInstructions: String = "",
    val aboutStory: String = "",
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@Keep
@IgnoreExtraProperties
data class FsAdminRole(
    @DocumentId val id: String = "",
    val uid: String = "",
    val email: String = "",
    val role: String = "ADMIN",
    val grantedBy: String = "",
    @ServerTimestamp val createdAt: Timestamp? = null
)
