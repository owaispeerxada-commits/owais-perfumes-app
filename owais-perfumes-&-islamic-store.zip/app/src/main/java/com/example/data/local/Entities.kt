package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cart_items")
data class CartItemEntity(
    @PrimaryKey val cartKey: String,
    val productId: String,
    val productName: String,
    val categoryName: String,
    val variantLabel: String,
    val unitPriceInr: Int,
    val quantity: Int,
    val drawableResName: String,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "wishlist_items")
data class WishlistEntity(
    @PrimaryKey val productId: String,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val orderId: String,
    val createdAt: Long = System.currentTimeMillis(),
    val customerName: String,
    val customerPhone: String,
    val deliveryAddress: String,
    val itemsSummary: String,
    val itemCount: Int,
    val totalAmountInr: Int,
    val status: String,
    val whatsappMessage: String
)

@Entity(tableName = "customer_profile")
data class CustomerProfileEntity(
    @PrimaryKey val id: Int = 1,
    val fullName: String,
    val phoneNumber: String,
    val addressLine: String,
    val city: String,
    val pincode: String,
    val preferredScent: String
)
