package com.example.data.remote

import android.content.Context
import android.net.Uri
import com.example.data.model.OrderStatus
import com.example.data.model.PaymentStatus
import com.example.data.model.Product
import com.example.data.model.ProductCategory
import com.example.data.model.StoreBanner
import com.example.data.model.StoreCatalog
import com.example.data.model.StoreCategory
import com.example.data.model.StoreOrder
import com.example.data.model.StoreSettingsConfig
import com.example.data.remote.StoreFirestoreRepository.Companion.toStoreOrder
import com.google.firebase.Firebase
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.storage.storage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class StoreAdminFirestoreRepository(
    private val appContext: Context,
    private val db: FirebaseFirestore
) {

    fun observeAllOrders(): Flow<List<StoreOrder>> = callbackFlow {
        val reg = db.collection("orders")
            .addSnapshotListener(MetadataChanges.EXCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val orders = snap?.documents?.mapNotNull { doc -> doc.toStoreOrder() }
                    ?.sortedByDescending { it.createdAtMillis }
                    .orEmpty()
                trySend(orders)
            }
        awaitClose { reg.remove() }
    }

    fun observeAllCustomersCount(): Flow<Int> = callbackFlow {
        val reg = db.collection("users")
            .addSnapshotListener(MetadataChanges.EXCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                trySend(snap?.size() ?: 0)
            }
        awaitClose { reg.remove() }
    }

    suspend fun seedInitialStoreDataIfEmpty(): Result<String> = try {
        var createdCount = 0
        val batch = db.batch()

        val catSnap = db.collection("categories").limit(1).get().await()
        if (catSnap.isEmpty) {
            StoreCatalog.defaultCategories.forEach { cat ->
                batch.set(
                    db.collection("categories").document(cat.id),
                    mapOf(
                        "name" to cat.name,
                        "groupType" to cat.groupType.name,
                        "subtitle" to cat.subtitle,
                        "displayOrder" to cat.displayOrder,
                        "enabled" to cat.enabled,
                        "drawableResName" to cat.drawableResName,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                createdCount++
            }
        }

        val prodSnap = db.collection("products").limit(1).get().await()
        if (prodSnap.isEmpty) {
            StoreCatalog.products.forEach { product ->
                batch.set(
                    db.collection("products").document(product.id),
                    productPayload(product, isNew = true)
                )
                createdCount++
            }
        }

        val bannerSnap = db.collection("banners").limit(1).get().await()
        if (bannerSnap.isEmpty) {
            StoreCatalog.defaultBanners.forEach { banner ->
                batch.set(
                    db.collection("banners").document(banner.id),
                    mapOf(
                        "title" to banner.title,
                        "subtitle" to banner.subtitle,
                        "badgeText" to banner.badgeText,
                        "ctaText" to banner.ctaText,
                        "targetCategory" to banner.targetCategory,
                        "drawableResName" to banner.drawableResName,
                        "imageUrl" to banner.imageUrl,
                        "active" to banner.active,
                        "displayOrder" to banner.displayOrder,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                createdCount++
            }
        }

        val settingsRef = db.collection("store_settings").document("main")
        if (!settingsRef.get().await().exists()) {
            val defaults = StoreSettingsConfig()
            batch.set(
                settingsRef,
                mapOf(
                    "storeName" to defaults.storeName,
                    "brandOfficial" to defaults.brandOfficial,
                    "tagline" to defaults.tagline,
                    "location" to defaults.location,
                    "whatsappNumber" to defaults.whatsappNumber,
                    "instagramHandle" to defaults.instagramHandle,
                    "instagramUrl" to defaults.instagramUrl,
                    "deliveryChargeInr" to defaults.deliveryChargeInr,
                    "freeDeliveryThresholdInr" to defaults.freeDeliveryThresholdInr,
                    "codEnabled" to defaults.codEnabled,
                    "upiId" to defaults.upiId,
                    "upiPayeeName" to defaults.upiPayeeName,
                    "paymentInstructions" to defaults.paymentInstructions,
                    "aboutStory" to defaults.aboutStory,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            createdCount++
        }

        if (createdCount > 0) {
            batch.commit().await()
            Result.success("Synced $createdCount catalog & store records to Firestore.")
        } else {
            Result.success("Firestore store catalog is already populated.")
        }
    } catch (e: Exception) {
        if (e is CancellationException) throw e
        Result.failure(e)
    }

    suspend fun saveCategory(category: StoreCategory): Result<Unit> = try {
        val docId = category.id.ifBlank {
            "cat_${category.name.lowercase().replace(Regex("[^a-z0-9]+"), "_").trim('_').take(36)}_${UUID.randomUUID().toString().take(4)}"
        }
        val ref = db.collection("categories").document(docId)
        val snap = ref.get().await()
        if (!snap.exists()) {
            ref.set(
                mapOf(
                    "name" to category.name.trim().take(60),
                    "groupType" to category.groupType.name,
                    "subtitle" to category.subtitle.trim().take(140),
                    "displayOrder" to category.displayOrder.coerceIn(0, 999),
                    "enabled" to category.enabled,
                    "drawableResName" to category.drawableResName.ifBlank { "img_category_perfumes" },
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        } else {
            ref.update(
                mapOf(
                    "name" to category.name.trim().take(60),
                    "groupType" to category.groupType.name,
                    "subtitle" to category.subtitle.trim().take(140),
                    "displayOrder" to category.displayOrder.coerceIn(0, 999),
                    "enabled" to category.enabled,
                    "drawableResName" to category.drawableResName.ifBlank { "img_category_perfumes" },
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
        Result.success(Unit)
    } catch (e: Exception) {
        if (e is CancellationException) throw e
        Result.failure(e)
    }

    suspend fun saveProduct(product: Product): Result<Unit> = try {
        val docId = product.id.ifBlank {
            "prod_${UUID.randomUUID().toString().replace("-", "").take(14)}"
        }
        val ref = db.collection("products").document(docId)
        val snap = ref.get().await()
        if (!snap.exists()) {
            ref.set(productPayload(product, isNew = true)).await()
        } else {
            ref.update(productPayload(product, isNew = false)).await()
        }
        Result.success(Unit)
    } catch (e: Exception) {
        if (e is CancellationException) throw e
        Result.failure(e)
    }

    suspend fun deleteProduct(productId: String): Result<Unit> = try {
        db.collection("products").document(productId).delete().await()
        Result.success(Unit)
    } catch (e: Exception) {
        if (e is CancellationException) throw e
        Result.failure(e)
    }

    suspend fun updateProductFlags(
        productId: String,
        featured: Boolean? = null,
        enabled: Boolean? = null,
        stockCount: Int? = null
    ): Result<Unit> = try {
        val updates = mutableMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
        if (featured != null) updates["featured"] = featured
        if (enabled != null) updates["enabled"] = enabled
        if (stockCount != null) updates["stockCount"] = stockCount.coerceIn(0, 100000)
        db.collection("products").document(productId).update(updates).await()
        Result.success(Unit)
    } catch (e: Exception) {
        if (e is CancellationException) throw e
        Result.failure(e)
    }

    suspend fun updateOrderStatus(
        orderId: String,
        orderStatus: OrderStatus,
        paymentStatus: PaymentStatus
    ): Result<Unit> = try {
        db.collection("orders").document(orderId).update(
            mapOf(
                "orderStatus" to orderStatus.label,
                "paymentStatus" to paymentStatus.label,
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        Result.success(Unit)
    } catch (e: Exception) {
        if (e is CancellationException) throw e
        Result.failure(e)
    }

    suspend fun saveStoreSettings(settings: StoreSettingsConfig): Result<Unit> = try {
        db.collection("store_settings").document("main").set(
            mapOf(
                "storeName" to settings.storeName.trim().ifBlank { "OWAIS PERFUMES & ISLAMIC STORE" }.take(80),
                "brandOfficial" to settings.brandOfficial.trim().ifBlank { "THE OWAIS OFFICIAL" }.take(80),
                "tagline" to settings.tagline.trim().take(160),
                "location" to settings.location.trim().take(160),
                "whatsappNumber" to settings.whatsappNumber.trim().ifBlank { "+91 9906577880" }.take(24),
                "instagramHandle" to settings.instagramHandle.trim().take(60),
                "instagramUrl" to settings.instagramUrl.trim().take(240),
                "deliveryChargeInr" to settings.deliveryChargeInr.coerceIn(0, 50000),
                "freeDeliveryThresholdInr" to settings.freeDeliveryThresholdInr.coerceAtLeast(0),
                "codEnabled" to settings.codEnabled,
                "upiId" to settings.upiId.trim().take(100),
                "upiPayeeName" to settings.upiPayeeName.trim().take(100),
                "paymentInstructions" to settings.paymentInstructions.trim().take(800),
                "aboutStory" to settings.aboutStory.trim().take(1200),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        ).await()
        Result.success(Unit)
    } catch (e: Exception) {
        if (e is CancellationException) throw e
        Result.failure(e)
    }

    suspend fun saveBanner(banner: StoreBanner): Result<Unit> = try {
        val docId = banner.id.ifBlank { "banner_${UUID.randomUUID().toString().take(10)}" }
        val ref = db.collection("banners").document(docId)
        val snap = ref.get().await()
        val payload = mutableMapOf<String, Any>(
            "title" to banner.title.trim().ifBlank { "OWAIS PERFUMES" }.take(100),
            "subtitle" to banner.subtitle.trim().take(200),
            "badgeText" to banner.badgeText.trim().take(50),
            "ctaText" to banner.ctaText.trim().take(40),
            "targetCategory" to banner.targetCategory.take(60),
            "drawableResName" to banner.drawableResName.ifBlank { "img_hero_banner" },
            "imageUrl" to banner.imageUrl.take(500),
            "active" to banner.active,
            "displayOrder" to banner.displayOrder.coerceIn(0, 100),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (!snap.exists()) {
            payload["createdAt"] = FieldValue.serverTimestamp()
            ref.set(payload).await()
        } else {
            ref.update(payload).await()
        }
        Result.success(Unit)
    } catch (e: Exception) {
        if (e is CancellationException) throw e
        Result.failure(e)
    }

    suspend fun uploadProductImage(productId: String, imageUri: Uri): Result<String> = try {
        val safeProductId = productId.ifBlank { "prod_${UUID.randomUUID().toString().take(8)}" }
            .replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
        val fileName = "img_${System.currentTimeMillis()}.jpg"
        val storageRef = Firebase.storage.reference
            .child("products")
            .child(safeProductId)
            .child(fileName)

        val bytes = appContext.contentResolver.openInputStream(imageUri)?.use { it.readBytes() }
            ?: return Result.failure(IllegalStateException("Could not read selected image"))
        if (bytes.size > 5 * 1024 * 1024) {
            return Result.failure(IllegalStateException("Selected image exceeds 5 MB limit"))
        }

        storageRef.putBytes(bytes).await()
        val downloadUrl = storageRef.downloadUrl.await().toString()
        Result.success(downloadUrl)
    } catch (e: Exception) {
        if (e is CancellationException) throw e
        val msg = e.message ?: "Firebase Storage upload failed. Verify Storage bucket is enabled in Firebase Console."
        Result.failure(IllegalStateException(msg, e))
    }

    private fun productPayload(product: Product, isNew: Boolean): Map<String, Any> {
        val safePrice = product.priceInr.coerceIn(1, 500000)
        val safeMrp = (product.originalPriceInr ?: 0).coerceIn(0, 500000)
        val map = mutableMapOf<String, Any>(
            "name" to product.name.trim().ifBlank { "Owais Fragrance" }.take(120),
            "subtitle" to product.subtitle.trim().take(160),
            "categoryId" to product.categoryId.ifBlank { "cat_luxury_perfumes" }.take(80),
            "categoryName" to product.categoryName.ifBlank { product.category.displayName }.take(60),
            "groupType" to product.category.name,
            "priceInr" to safePrice,
            "discountPriceInr" to safeMrp,
            "stockCount" to product.stockCount.coerceIn(0, 100000),
            "featured" to product.isFeatured,
            "enabled" to product.enabled,
            "demoItem" to product.isDemo,
            "badge" to product.badge.trim().take(40),
            "drawableResName" to product.drawableResName.ifBlank { "img_hero_banner" }.take(80),
            "imageUrls" to product.imageUrls.take(6),
            "variantLabels" to product.variants.map { it.label }.ifEmpty { listOf("Standard") }.take(8),
            "variantPrices" to product.variants.map { it.priceInr.coerceIn(1, 500000) }.ifEmpty { listOf(safePrice) }.take(8),
            "topNotes" to product.topNotes.take(140),
            "heartNotes" to product.heartNotes.take(140),
            "baseNotes" to product.baseNotes.take(140),
            "originOrMaterial" to product.originOrMaterial.take(160),
            "description" to product.description.trim().ifBlank { "Authentic product from Owais Perfumes & Islamic Store." }.take(1200),
            "rating" to product.rating.coerceIn(0.0, 5.0),
            "reviewCount" to product.reviewCount.coerceAtLeast(0),
            "updatedAt" to FieldValue.serverTimestamp()
        )
        if (isNew) {
            map["createdAt"] = FieldValue.serverTimestamp()
        }
        return map
    }
}
