package com.example.data.model

enum class ProductCategory(
    val displayName: String,
    val subtitle: String
) {
    PERFUMES("Perfumes", "Arabic, Luxury, Oud, Khamrah & Long Lasting EDPs"),
    ATTARS("Attars", "Mask Oud, White Oud & Pure Roll-on Concentrates"),
    ISLAMIC_PRODUCTS("Islamic Products", "Quran Pak, Prayer Mats, Topi, Tasbeeh, Books & Gifts"),
    CUSTOM("More Collections", "Curated Specialty Arrivals")
}

enum class SortOption(val label: String) {
    FEATURED("Featured"),
    PRICE_LOW_HIGH("Price: Low to High"),
    PRICE_HIGH_LOW("Price: High to Low")
}

enum class OrderStatus(val label: String) {
    PENDING("Pending"),
    CONFIRMED("Confirmed"),
    PROCESSING("Processing"),
    SHIPPED("Shipped"),
    DELIVERED("Delivered"),
    CANCELLED("Cancelled");

    companion object {
        fun fromLabel(value: String): OrderStatus =
            entries.firstOrNull { it.label.equals(value, ignoreCase = true) } ?: PENDING
    }
}

enum class PaymentPreference(val code: String, val label: String) {
    UPI("UPI", "UPI Payment (Manual Verification)"),
    COD("COD", "Cash on Delivery"),
    WHATSAPP_CONFIRM("WHATSAPP_CONFIRM", "Confirm on WhatsApp");

    companion object {
        fun fromCode(code: String): PaymentPreference =
            entries.firstOrNull { it.code.equals(code, ignoreCase = true) } ?: WHATSAPP_CONFIRM
    }
}

enum class PaymentStatus(val label: String) {
    UNVERIFIED("Unverified"),
    PENDING_VERIFICATION("Pending Verification"),
    VERIFIED("Verified"),
    REFUNDED("Refunded");

    companion object {
        fun fromLabel(value: String): PaymentStatus =
            entries.firstOrNull { it.label.equals(value, ignoreCase = true) } ?: UNVERIFIED
    }
}

data class StoreCategory(
    val id: String,
    val name: String,
    val groupType: ProductCategory,
    val subtitle: String,
    val displayOrder: Int = 0,
    val enabled: Boolean = true,
    val drawableResName: String = "img_category_perfumes"
)

data class ProductVariant(
    val label: String,
    val priceInr: Int
)

data class Product(
    val id: String,
    val name: String,
    val subtitle: String,
    val category: ProductCategory,
    val categoryId: String = "",
    val categoryName: String = category.displayName,
    val priceInr: Int,
    val originalPriceInr: Int? = null,
    val stockCount: Int = 25,
    val rating: Double,
    val reviewCount: Int,
    val badge: String,
    val isDemo: Boolean = true,
    val isFeatured: Boolean = false,
    val enabled: Boolean = true,
    val drawableResName: String,
    val imageUrls: List<String> = emptyList(),
    val topNotes: String,
    val heartNotes: String,
    val baseNotes: String,
    val originOrMaterial: String,
    val description: String,
    val variants: List<ProductVariant>
) {
    val effectivePriceInr: Int
        get() = priceInr

    val isLowStock: Boolean
        get() = stockCount in 1..5

    val isOutOfStock: Boolean
        get() = stockCount <= 0
}

data class StoreBanner(
    val id: String,
    val title: String,
    val subtitle: String,
    val badgeText: String,
    val ctaText: String,
    val targetCategory: String = "",
    val drawableResName: String = "img_hero_banner",
    val imageUrl: String = "",
    val active: Boolean = true,
    val displayOrder: Int = 0
)

data class StoreSettingsConfig(
    val storeName: String = StoreConstants.STORE_NAME,
    val brandOfficial: String = StoreConstants.BRAND_OFFICIAL,
    val tagline: String = StoreConstants.TAGLINE,
    val location: String = StoreConstants.STORE_LOCATION,
    val whatsappNumber: String = StoreConstants.WHATSAPP_DISPLAY,
    val instagramHandle: String = StoreConstants.INSTAGRAM_HANDLE,
    val instagramUrl: String = StoreConstants.INSTAGRAM_URL,
    val deliveryChargeInr: Int = 99,
    val freeDeliveryThresholdInr: Int = 1999,
    val codEnabled: Boolean = true,
    val upiId: String = "owaisperfumes@upi",
    val upiPayeeName: String = "Owais Perfumes & Islamic Store",
    val paymentInstructions: String = "Send UPI payment to the UPI ID shown and enter your 12-digit UTR / transaction reference. Our Kupwara team verifies and confirms your order.",
    val aboutStory: String = StoreConstants.ABOUT_STORY
) {
    val whatsappDigits: String
        get() = whatsappNumber.filter { it.isDigit() }.ifBlank { StoreConstants.WHATSAPP_DIGITS }

    fun calculateDeliveryCharge(subtotalInr: Int): Int {
        if (subtotalInr <= 0) return 0
        if (freeDeliveryThresholdInr > 0 && subtotalInr >= freeDeliveryThresholdInr) return 0
        return deliveryChargeInr
    }
}

data class DeliveryAddress(
    val id: String = "",
    val label: String = "Home",
    val recipientName: String = "",
    val phone: String = "",
    val streetAddress: String = "",
    val city: String = "Kupwara",
    val state: String = "Jammu & Kashmir",
    val pincode: String = "193222",
    val defaultAddress: Boolean = false
) {
    fun formattedAddress(): String =
        listOf(streetAddress, city, state, pincode).filter { it.isNotBlank() }.joinToString(", ")
}

data class StoreOrder(
    val id: String,
    val userId: String = "",
    val orderNumber: String,
    val createdAtMillis: Long,
    val customerName: String,
    val customerEmail: String = "",
    val customerPhone: String,
    val deliveryAddress: String,
    val itemsSummary: String,
    val itemCount: Int,
    val subtotalInr: Int,
    val deliveryChargeInr: Int = 0,
    val totalAmountInr: Int,
    val paymentPreference: PaymentPreference = PaymentPreference.WHATSAPP_CONFIRM,
    val paymentStatus: PaymentStatus = PaymentStatus.UNVERIFIED,
    val upiTransactionRef: String = "",
    val orderStatus: OrderStatus = OrderStatus.PENDING,
    val whatsappMessage: String = "",
    val idempotencyKey: String = ""
)

data class AdminAnalytics(
    val totalProducts: Int = 0,
    val totalCustomers: Int = 0,
    val totalOrders: Int = 0,
    val pendingOrders: Int = 0,
    val deliveredOrders: Int = 0,
    val verifiedSalesInr: Int = 0,
    val totalOrderVolumeInr: Int = 0,
    val lowStockProducts: List<Product> = emptyList()
)

object StoreConstants {
    const val STORE_NAME = "OWAIS PERFUMES & ISLAMIC STORE"
    const val BRAND_OFFICIAL = "THE OWAIS OFFICIAL"
    const val TAGLINE = "Luxury Fragrances. Authentic Islamic Essentials."
    const val GREETING = "Assalamu Alaikum"
    const val STORE_LOCATION = "Kupwara, Jammu & Kashmir, India"
    const val STORE_SHORT_LOCATION = "Kupwara, J&K"
    const val WHATSAPP_DISPLAY = "+91 9906577880"
    const val WHATSAPP_DIGITS = "919906577880"
    const val INSTAGRAM_HANDLE = "@mrowais_15"
    const val INSTAGRAM_URL = "https://www.instagram.com/mrowais_15/"
    const val SUPPORT_EMAIL = "owaispeerxada@gmail.com"
    const val OWNER_EMAIL = "owaispeerxada@gmail.com"
    const val ABOUT_STORY = "Founded under THE OWAIS OFFICIAL in Kupwara, Jammu & Kashmir, Owais Perfumes & Islamic Store curates luxury Arabic & French-oriental perfumes, pure alcohol-free attars, and authentic Islamic essentials including velvet Quran Pak editions, prayer mats, Tasbeeh, Topi, Islamic wall frames, hijab accessories, and scholarly books."
    const val DEMO_NOTICE = "THE OWAIS OFFICIAL — Browse fragrances & Sunnah essentials in Guest mode or sign in with Google for cloud order tracking & saved addresses."
}

object StoreCatalog {

    val defaultCategories: List<StoreCategory> = listOf(
        // Perfumes & Attars (10 requested categories)
        StoreCategory("cat_arabic_perfumes", "Arabic Perfumes", ProductCategory.PERFUMES, "Opulent Middle Eastern Eau de Parfum", 1, true, "img_hero_banner"),
        StoreCategory("cat_luxury_perfumes", "Luxury Perfumes", ProductCategory.PERFUMES, "High-Oil Signature Evening Sprays", 2, true, "img_category_perfumes"),
        StoreCategory("cat_premium_perfumes", "Premium Perfumes", ProductCategory.PERFUMES, "Refined Everyday & Occasion EDPs", 3, true, "img_category_perfumes"),
        StoreCategory("cat_oud_collection", "Oud Collection", ProductCategory.PERFUMES, "Aged Agarwood & Royal Oud Creations", 4, true, "img_featured_oud"),
        StoreCategory("cat_khamrah", "Khamrah", ProductCategory.PERFUMES, "Warm Cinnamon, Dates & Praline Elixirs", 5, true, "img_hero_banner"),
        StoreCategory("cat_wafa", "Wafa", ProductCategory.PERFUMES, "Velvet Florals, Saffron & Soft Amber", 6, true, "img_category_perfumes"),
        StoreCategory("cat_mask_oud", "Mask Oud", ProductCategory.ATTARS, "Velvety Musk & Woody Agarwood Oils", 7, true, "img_featured_oud"),
        StoreCategory("cat_white_oud", "White Oud", ProductCategory.ATTARS, "Crisp Clean Woods & White Musk", 8, true, "img_category_perfumes"),
        StoreCategory("cat_roll_on_attar", "Roll-on Attar", ProductCategory.ATTARS, "Alcohol-Free Concentrated Pocket Roll-ons", 9, true, "img_featured_oud"),
        StoreCategory("cat_long_lasting", "Long Lasting Fragrances", ProductCategory.PERFUMES, "24-Hour Extrait & Concentrated Projections", 10, true, "img_hero_banner"),

        // Islamic Products (11 requested categories)
        StoreCategory("cat_quran_pak", "Quran Pak", ProductCategory.ISLAMIC_PRODUCTS, "Velvet Hardcover & Tajweed Editions", 11, true, "img_category_islamic"),
        StoreCategory("cat_islamic_books", "Islamic Books", ProductCategory.ISLAMIC_PRODUCTS, "Seerah, Hadith, Fiqh & Masnoon Duas", 12, true, "img_category_islamic"),
        StoreCategory("cat_prayer_mats", "Prayer Mats", ProductCategory.ISLAMIC_PRODUCTS, "Turkish Velvet & Cushioned Janamaz", 13, true, "img_category_islamic"),
        StoreCategory("cat_islamic_topi", "Islamic Topi", ProductCategory.ISLAMIC_PRODUCTS, "Embroidered Cotton & Heritage Kufi", 14, true, "img_category_islamic"),
        StoreCategory("cat_tasbeeh", "Tasbeeh", ProductCategory.ISLAMIC_PRODUCTS, "Sandalwood, Onyx & Pearl Dhikr Beads", 15, true, "img_category_islamic"),
        StoreCategory("cat_digital_tasbeeh", "Digital Tasbeeh", ProductCategory.ISLAMIC_PRODUCTS, "LED & Brass-Finish Tally Counters", 16, true, "img_category_islamic"),
        StoreCategory("cat_miswak", "Miswak", ProductCategory.ISLAMIC_PRODUCTS, "Fresh Vacuum-Sealed Peelu Sticks & Cases", 17, true, "img_category_islamic"),
        StoreCategory("cat_islamic_wall_frames", "Islamic Wall Frames", ProductCategory.ISLAMIC_PRODUCTS, "Ayat-ul-Kursi & Calligraphy Decor", 18, true, "img_category_islamic"),
        StoreCategory("cat_islamic_gift_sets", "Islamic Gift Sets", ProductCategory.ISLAMIC_PRODUCTS, "Curated Nikah, Eid & Umrah Hampers", 19, true, "img_featured_oud"),
        StoreCategory("cat_hijab_accessories", "Hijab Accessories", ProductCategory.ISLAMIC_PRODUCTS, "Silk Undercaps & Magnetic Gold Pins", 20, true, "img_category_islamic"),
        StoreCategory("cat_other_islamic", "Other Islamic Essentials", ProductCategory.ISLAMIC_PRODUCTS, "Mabkhara, Bakhoor & Daily Sunnah Items", 21, true, "img_category_islamic")
    )

    val defaultBanners: List<StoreBanner> = listOf(
        StoreBanner(
            id = "banner_main",
            title = "OWAIS PERFUMES & ISLAMIC STORE",
            subtitle = "Luxury Fragrances. Authentic Islamic Essentials. Dispatched from Kupwara, J&K.",
            badgeText = "THE OWAIS OFFICIAL",
            ctaText = "Shop Collection",
            targetCategory = "",
            drawableResName = "img_hero_banner",
            active = true,
            displayOrder = 1
        ),
        StoreBanner(
            id = "banner_oud_eid",
            title = "Royal Oud & Khamrah Editions",
            subtitle = "Handpicked 25% Oil Concentrates & Alcohol-Free Attars",
            badgeText = "NEW ARRIVAL",
            ctaText = "Explore Perfumes",
            targetCategory = "cat_oud_collection",
            drawableResName = "img_featured_oud",
            active = true,
            displayOrder = 2
        )
    )

    val products: List<Product> = listOf(
        // PERFUMES
        Product(
            id = "perfume_kashmir_velvet_oud",
            name = "Owais Velvet Oud EDP",
            subtitle = "Dark Spiced Oud · Emerald Edition",
            category = ProductCategory.PERFUMES,
            categoryId = "cat_oud_collection",
            categoryName = "Oud Collection",
            priceInr = 2199,
            originalPriceInr = 2699,
            stockCount = 24,
            rating = 4.9,
            reviewCount = 67,
            badge = "DEMO · LUXURY",
            isFeatured = true,
            drawableResName = "img_hero_banner",
            topNotes = "Cardamom, Black Pepper, Saffron",
            heartNotes = "Turkish Rose, Smoked Incense",
            baseNotes = "Aged Oud, Leather, Tonka Bean",
            originOrMaterial = "Eau de Parfum · 25% Oil Concentration",
            description = "Signature evening Eau de Parfum by THE OWAIS OFFICIAL inspired by crisp Kupwara twilight skies. Crafted with a 25% perfume oil concentration for commanding longevity.",
            variants = listOf(
                ProductVariant("50 ml", 2199),
                ProductVariant("100 ml", 3599)
            )
        ),
        Product(
            id = "perfume_khamrah_elixir",
            name = "Royal Khamrah Qahwa Extrait",
            subtitle = "Spiced Cinnamon · Roasted Dates · Vanilla",
            category = ProductCategory.PERFUMES,
            categoryId = "cat_khamrah",
            categoryName = "Khamrah",
            priceInr = 2399,
            originalPriceInr = 2899,
            stockCount = 18,
            rating = 4.9,
            reviewCount = 92,
            badge = "DEMO · KHAMRAH",
            isFeatured = true,
            drawableResName = "img_hero_banner",
            topNotes = "Cinnamon Bark, Nutmeg, Cardamom",
            heartNotes = "Medjool Dates, Praline, Tuberose",
            baseNotes = "Roasted Tonka, Amberwood, Benzoin",
            originOrMaterial = "Extrait de Parfum · Long Lasting",
            description = "Opulent gourmand-oriental warmth blending golden cinnamon spice, caramelized dates, and smoky benzoin in a collector emerald-gold flacon.",
            variants = listOf(
                ProductVariant("100 ml", 2399),
                ProductVariant("100 ml + 12ml Travel", 2799)
            )
        ),
        Product(
            id = "perfume_wafa_imperial",
            name = "Wafa Gold Signature EDP",
            subtitle = "Kashmiri Saffron · Taif Rose · White Amber",
            category = ProductCategory.PERFUMES,
            categoryId = "cat_wafa",
            categoryName = "Wafa",
            priceInr = 1899,
            originalPriceInr = 2299,
            stockCount = 22,
            rating = 4.8,
            reviewCount = 58,
            badge = "DEMO · WAFA",
            isFeatured = false,
            drawableResName = "img_category_perfumes",
            topNotes = "Bergamot, Pink Pepper, Saffron",
            heartNotes = "Taif Rose, Jasmine Sambac",
            baseNotes = "White Amber, Cashmere Musk",
            originOrMaterial = "Eau de Parfum · Unisex",
            description = "Velvety floral-amber balance crafted for heartfelt daily elegance and celebratory occasions.",
            variants = listOf(
                ProductVariant("50 ml", 1899),
                ProductVariant("100 ml", 2999)
            )
        ),
        Product(
            id = "perfume_arabic_majlis",
            name = "Al-Majlis Arabic Perfume EDP",
            subtitle = "Frankincense · Royal Leather · Woods",
            category = ProductCategory.PERFUMES,
            categoryId = "cat_arabic_perfumes",
            categoryName = "Arabic Perfumes",
            priceInr = 2499,
            originalPriceInr = 2999,
            stockCount = 14,
            rating = 4.9,
            reviewCount = 45,
            badge = "DEMO · ARABIC",
            isFeatured = false,
            drawableResName = "img_featured_oud",
            topNotes = "Omani Frankincense, Saffron",
            heartNotes = "Damask Rose, Myrrh",
            baseNotes = "Cambodian Oud, Suede Leather",
            originOrMaterial = "Arabic Eau de Parfum · 100 ml",
            description = "Regal Arabian craftsmanship uniting sacred frankincense smoke with rich Cambodian oud and supple leather.",
            variants = listOf(
                ProductVariant("100 ml", 2499)
            )
        ),
        Product(
            id = "perfume_emerald_night",
            name = "Emerald Night Luxury EDP",
            subtitle = "Cedarwood · Bergamot · Ambergris",
            category = ProductCategory.PERFUMES,
            categoryId = "cat_luxury_perfumes",
            categoryName = "Luxury Perfumes",
            priceInr = 1849,
            originalPriceInr = 2250,
            stockCount = 20,
            rating = 4.7,
            reviewCount = 54,
            badge = "DEMO · LUXURY",
            isFeatured = false,
            drawableResName = "img_category_perfumes",
            topNotes = "Calabrian Bergamot, Pine Needle",
            heartNotes = "Vetiver, Cedarwood, Clary Sage",
            baseNotes = "Ambergris, Patchouli, Musk",
            originOrMaterial = "Eau de Parfum · Fine Mist Atomizer",
            description = "Crisp alpine woods meet warm ambergris in a refined signature spray tailored for formal gatherings.",
            variants = listOf(
                ProductVariant("50 ml", 1849),
                ProductVariant("100 ml", 2999)
            )
        ),
        Product(
            id = "perfume_zafarani_rose",
            name = "Zafarani Premium Rose Elixir",
            subtitle = "Taif Rose · Honeyed Saffron",
            category = ProductCategory.PERFUMES,
            categoryId = "cat_premium_perfumes",
            categoryName = "Premium Perfumes",
            priceInr = 1999,
            originalPriceInr = 2399,
            stockCount = 19,
            rating = 4.8,
            reviewCount = 41,
            badge = "DEMO · PREMIUM",
            isFeatured = false,
            drawableResName = "img_hero_banner",
            topNotes = "Pink Pepper, Mandarin Zest",
            heartNotes = "Taif Rose, Kashmiri Saffron",
            baseNotes = "Cashmere Wood, Benzoin, Vanilla",
            originOrMaterial = "Unisex Extrait · Heavy Glass Flacon",
            description = "Luminous petals of Taif rose steeped in golden saffron nectar and smooth benzoin resin.",
            variants = listOf(
                ProductVariant("50 ml", 1999),
                ProductVariant("100 ml", 3299)
            )
        ),
        Product(
            id = "perfume_eternal_amber_24h",
            name = "Kupwara Reserve 24H Extrait",
            subtitle = "Extreme Longevity · 35% Pure Perfume Oil",
            category = ProductCategory.PERFUMES,
            categoryId = "cat_long_lasting",
            categoryName = "Long Lasting Fragrances",
            priceInr = 2799,
            originalPriceInr = 3299,
            stockCount = 4, // intentionally low stock for admin alert demo
            rating = 5.0,
            reviewCount = 39,
            badge = "DEMO · 24H EXTRAIT",
            isFeatured = true,
            drawableResName = "img_featured_oud",
            topNotes = "Black Cardamom, Elemi",
            heartNotes = "Smoked Rose, Patchouli Leaf",
            baseNotes = "Aged Agarwood, Ambergris, Labdanum",
            originOrMaterial = "Extrait de Parfum · 35% Concentration",
            description = "High-projection 35% extrait formulated to last beyond 24 hours on garments with just two sprays.",
            variants = listOf(
                ProductVariant("50 ml", 2799),
                ProductVariant("100 ml", 4499)
            )
        ),

        // ATTARS
        Product(
            id = "attar_kashmiri_saffron_oud",
            name = "Royal Kashmiri Saffron Oud Attar",
            subtitle = "Pampore Saffron · Aged Assam Oud",
            category = ProductCategory.ATTARS,
            categoryId = "cat_roll_on_attar",
            categoryName = "Roll-on Attar",
            priceInr = 1499,
            originalPriceInr = 1899,
            stockCount = 30,
            rating = 4.9,
            reviewCount = 84,
            badge = "DEMO · SIGNATURE",
            isFeatured = true,
            drawableResName = "img_featured_oud",
            topNotes = "Kashmiri Kesar, Bergamot",
            heartNotes = "Damask Rose, Warm Amber",
            baseNotes = "Smoky Agarwood, White Musk",
            originOrMaterial = "Alcohol-Free Pure Attar · Hand-poured",
            description = "Our flagship signature attar blending prized Pampore saffron strands with deeply aged agarwood resin.",
            variants = listOf(
                ProductVariant("6 ml Roll-on", 999),
                ProductVariant("12 ml Crystal", 1499),
                ProductVariant("24 ml Gift Box", 2799)
            )
        ),
        Product(
            id = "attar_mask_oud",
            name = "Mask Oud Velvet Concentre",
            subtitle = "Rich Musk · Smoky Dark Agarwood",
            category = ProductCategory.ATTARS,
            categoryId = "cat_mask_oud",
            categoryName = "Mask Oud",
            priceInr = 1299,
            originalPriceInr = 1599,
            stockCount = 21,
            rating = 4.8,
            reviewCount = 71,
            badge = "DEMO · MASK OUD",
            isFeatured = false,
            drawableResName = "img_featured_oud",
            topNotes = "Nutmeg, Warm Musk",
            heartNotes = "Cedar, Dark Patchouli",
            baseNotes = "Aged Assam Oud, Black Musk",
            originOrMaterial = "100% Alcohol-Free Attar Oil",
            description = "Sensuous harmony of velvety musk and deep aged oud crafted for Jummah prayers and winter evenings.",
            variants = listOf(
                ProductVariant("6 ml", 799),
                ProductVariant("12 ml", 1299)
            )
        ),
        Product(
            id = "attar_white_oud_pure",
            name = "Imperial White Oud Attar",
            subtitle = "Crisp White Woods · Lotus · Clean Musk",
            category = ProductCategory.ATTARS,
            categoryId = "cat_white_oud",
            categoryName = "White Oud",
            priceInr = 999,
            originalPriceInr = 1249,
            stockCount = 26,
            rating = 4.9,
            reviewCount = 96,
            badge = "DEMO · WHITE OUD",
            isFeatured = false,
            drawableResName = "img_category_perfumes",
            topNotes = "White Tea, Lemon Blossom",
            heartNotes = "White Agarwood, Jasmine",
            baseNotes = "Crystal White Musk, Sandalwood",
            originOrMaterial = "Alcohol-Free Thick Attar",
            description = "Clean, uplifting white agarwood softened with creamy sandalwood and serene white musk.",
            variants = listOf(
                ProductVariant("6 ml", 599),
                ProductVariant("12 ml", 999),
                ProductVariant("24 ml", 1749)
            )
        ),
        Product(
            id = "attar_madinah_musk",
            name = "Madinah Musk Al-Tahara Roll-On",
            subtitle = "Velvet White Musk · Lotus Silk",
            category = ProductCategory.ATTARS,
            categoryId = "cat_roll_on_attar",
            categoryName = "Roll-on Attar",
            priceInr = 699,
            originalPriceInr = 899,
            stockCount = 40,
            rating = 4.8,
            reviewCount = 112,
            badge = "DEMO · BESTSELLER",
            isFeatured = true,
            drawableResName = "img_category_perfumes",
            topNotes = "Crisp White Lotus, Dew",
            heartNotes = "Powdery Jasmine, Lily",
            baseNotes = "Creamy White Musk, Sandal",
            originOrMaterial = "Alcohol-Free Pocket Roll-On",
            description = "Clean, serene, and softly enveloping white musk prized for daily wear after ablution.",
            variants = listOf(
                ProductVariant("6 ml", 499),
                ProductVariant("12 ml", 699),
                ProductVariant("24 ml", 1249)
            )
        ),

        // ISLAMIC PRODUCTS
        Product(
            id = "islamic_quran_pak",
            name = "Holy Quran Pak (Velvet Gold Edition)",
            subtitle = "15-Line Bold Script · Velvet Slipcase",
            category = ProductCategory.ISLAMIC_PRODUCTS,
            categoryId = "cat_quran_pak",
            categoryName = "Quran Pak",
            priceInr = 1399,
            originalPriceInr = 1699,
            stockCount = 15,
            rating = 5.0,
            reviewCount = 128,
            badge = "DEMO · QURAN PAK",
            isFeatured = true,
            drawableResName = "img_category_islamic",
            topNotes = "Emerald Velvet Hardcover",
            heartNotes = "Gold-Foil Bordered 15-Line Print",
            baseNotes = "Matching Protective Gift Box",
            originOrMaterial = "Acid-Free Ivory Art Paper · Large Clear Script",
            description = "Reverently crafted Holy Quran Pak bound in emerald-green velvet with intricate gold-foil embossing and crystal-clear 15-line Tajweed-friendly script.",
            variants = listOf(
                ProductVariant("Medium (15-Line)", 1399),
                ProductVariant("Large Majlisi + Box", 1999)
            )
        ),
        Product(
            id = "islamic_books",
            name = "Authentic Islamic Books Collection",
            subtitle = "Seerah, Riyad-us-Saliheen & Fortress of Muslim",
            category = ProductCategory.ISLAMIC_PRODUCTS,
            categoryId = "cat_islamic_books",
            categoryName = "Islamic Books",
            priceInr = 1099,
            originalPriceInr = 1399,
            stockCount = 16,
            rating = 4.9,
            reviewCount = 77,
            badge = "DEMO · BOOKS",
            isFeatured = false,
            drawableResName = "img_category_islamic",
            topNotes = "Gold-Stamped Hardcover",
            heartNotes = "English & Urdu Editions",
            baseNotes = "Ribbon Bookmarks Included",
            originOrMaterial = "Authentic Verified Islamic Publishing",
            description = "Curated Islamic library featuring the acclaimed Seerah of the Prophet (PBUH), daily Masnoon Duas (Hisnul Muslim), and timeless spiritual guidance.",
            variants = listOf(
                ProductVariant("Seerah + Hisnul Muslim", 1099),
                ProductVariant("Complete 3-Book Library", 1799)
            )
        ),
        Product(
            id = "islamic_emerald_janamaz",
            name = "Imperial Velvet Prayer Mat (Janamaz)",
            subtitle = "Gold Embroidered Turkish Velvet",
            category = ProductCategory.ISLAMIC_PRODUCTS,
            categoryId = "cat_prayer_mats",
            categoryName = "Prayer Mats",
            priceInr = 1299,
            originalPriceInr = 1599,
            stockCount = 18,
            rating = 4.9,
            reviewCount = 95,
            badge = "DEMO · PRAYER MAT",
            isFeatured = true,
            drawableResName = "img_category_islamic",
            topNotes = "Plush Velvet Pile",
            heartNotes = "Metallic Gold Mihrab Arch",
            baseNotes = "Cushioned Non-Slip Backing",
            originOrMaterial = "115 x 70 cm · Turkish Velvet Craft",
            description = "Deep emerald velvet prayer mat finished with luminous gold-thread Mihrab embroidery and soft knee cushioning for serene Salah.",
            variants = listOf(
                ProductVariant("Standard Prayer Mat", 1299),
                ProductVariant("Mat + Matching Tasbeeh", 1649)
            )
        ),
        Product(
            id = "islamic_topi",
            name = "Royal Embroidered Prayer Topi (Kufi)",
            subtitle = "Breathable Cotton · Gold Geometric Stitch",
            category = ProductCategory.ISLAMIC_PRODUCTS,
            categoryId = "cat_islamic_topi",
            categoryName = "Islamic Topi",
            priceInr = 399,
            originalPriceInr = 499,
            stockCount = 45,
            rating = 4.8,
            reviewCount = 104,
            badge = "DEMO · TOPI",
            isFeatured = false,
            drawableResName = "img_category_islamic",
            topNotes = "Fine Mercerized Cotton",
            heartNotes = "Gold & Emerald Heritage Stitch",
            baseNotes = "Structured Comfort Band",
            originOrMaterial = "All-Season Breathable Fit",
            description = "Structured, breathable Islamic prayer Topi featuring subtle gold geometric needlework inspired by Kashmiri and Ottoman heritage.",
            variants = listOf(
                ProductVariant("Size 56 (S/M)", 399),
                ProductVariant("Size 58 (L)", 399),
                ProductVariant("Size 60 (XL)", 429)
            )
        ),
        Product(
            id = "islamic_sandalwood_tasbih",
            name = "Handcrafted Sandalwood Tasbeeh",
            subtitle = "99 Smooth Beads · Gold Tassel",
            category = ProductCategory.ISLAMIC_PRODUCTS,
            categoryId = "cat_tasbeeh",
            categoryName = "Tasbeeh",
            priceInr = 549,
            originalPriceInr = 699,
            stockCount = 28,
            rating = 4.9,
            reviewCount = 138,
            badge = "DEMO · TASBEEH",
            isFeatured = false,
            drawableResName = "img_category_islamic",
            topNotes = "Natural Aromatic Wood",
            heartNotes = "8mm Hand-turned Beads",
            baseNotes = "Braided Gold-Thread Tassel",
            originOrMaterial = "99 Beads with 33-Bead Dividers",
            description = "Naturally fragrant sandalwood Tasbeeh turned for smooth tactile Dhikr, finished with golden divider markers.",
            variants = listOf(
                ProductVariant("33 Beads", 349),
                ProductVariant("99 Beads", 549)
            )
        ),
        Product(
            id = "islamic_digital_tasbeeh",
            name = "Luxury Gold Digital Tasbeeh Counter",
            subtitle = "Silent Tactile Click · LED Backlight · Leather Case",
            category = ProductCategory.ISLAMIC_PRODUCTS,
            categoryId = "cat_digital_tasbeeh",
            categoryName = "Digital Tasbeeh",
            priceInr = 349,
            originalPriceInr = 499,
            stockCount = 35,
            rating = 4.8,
            reviewCount = 119,
            badge = "DEMO · DIGITAL",
            isFeatured = false,
            drawableResName = "img_category_islamic",
            topNotes = "Metallic Gold Rim",
            heartNotes = "Night-View Soft Green LED",
            baseNotes = "Adjustable Ergonomic Ring",
            originOrMaterial = "Long-Life Battery + Velvet Pouch",
            description = "Compact gold-accented digital Dhikr tally counter with silent button feedback and automatic 5-digit memory.",
            variants = listOf(
                ProductVariant("Emerald & Gold", 349),
                ProductVariant("Pack of 2 (Gift Pouch)", 649)
            )
        ),
        Product(
            id = "islamic_peelu_miswak",
            name = "Natural Peelu Miswak & Travel Case",
            subtitle = "Fresh Salvadora Persica · Gold-Trim Tube",
            category = ProductCategory.ISLAMIC_PRODUCTS,
            categoryId = "cat_miswak",
            categoryName = "Miswak",
            priceInr = 249,
            originalPriceInr = 320,
            stockCount = 60,
            rating = 4.8,
            reviewCount = 165,
            badge = "DEMO · MISWAK",
            isFeatured = false,
            drawableResName = "img_category_islamic",
            topNotes = "Fresh Vacuum Sealed",
            heartNotes = "Hygienic Ventilated Tube",
            baseNotes = "Sunnah Oral Care",
            originOrMaterial = "Pack of 2 Sticks + Travel Case",
            description = "Authentic, aromatic Peelu miswak sticks sealed for freshness with a sleek ventilated pocket travel tube.",
            variants = listOf(
                ProductVariant("2 Sticks + Case", 249),
                ProductVariant("5 Sticks Family Pack", 499)
            )
        ),
        Product(
            id = "islamic_ayat_wall_frame",
            name = "Ayat-ul-Kursi Gold Calligraphy Frame",
            subtitle = "Emerald Velvet Matting · Brushed Gold Border",
            category = ProductCategory.ISLAMIC_PRODUCTS,
            categoryId = "cat_islamic_wall_frames",
            categoryName = "Islamic Wall Frames",
            priceInr = 1599,
            originalPriceInr = 1999,
            stockCount = 4, // low stock alert demo
            rating = 4.9,
            reviewCount = 46,
            badge = "DEMO · WALL ART",
            isFeatured = false,
            drawableResName = "img_category_islamic",
            topNotes = "Metallic Gold Foil Thuluth Script",
            heartNotes = "Shatter-Resistant Clear Acrylic",
            baseNotes = "Ready-to-Hang Solid Backing",
            originOrMaterial = "16 x 22 Inch · Handcrafted Frame",
            description = "Majestic Ayat-ul-Kursi Arabic calligraphy embossed in warm metallic gold over deep emerald velvet matting.",
            variants = listOf(
                ProductVariant("12 x 18 Inch", 1299),
                ProductVariant("16 x 22 Inch", 1599)
            )
        ),
        Product(
            id = "islamic_gift_hamper",
            name = "THE OWAIS Sunnah Gift Hamper",
            subtitle = "Quran Pak · Janamaz · 12ml Attar · Tasbeeh · Topi",
            category = ProductCategory.ISLAMIC_PRODUCTS,
            categoryId = "cat_islamic_gift_sets",
            categoryName = "Islamic Gift Sets",
            priceInr = 2999,
            originalPriceInr = 3599,
            stockCount = 10,
            rating = 5.0,
            reviewCount = 74,
            badge = "DEMO · GIFT SET",
            isFeatured = true,
            drawableResName = "img_featured_oud",
            topNotes = "Emerald Velvet Keepsake Box",
            heartNotes = "Velvet Prayer Mat + Saffron Oud 12ml",
            baseNotes = "Tasbeeh + Prayer Topi + Miswak",
            originOrMaterial = "Curated Nikah, Eid & Umrah Hamper",
            description = "An opulent emerald-and-gold presentation hamper uniting our velvet Prayer Mat, Saffron Oud attar, sandalwood Tasbeeh, embroidered Topi, and Miswak.",
            variants = listOf(
                ProductVariant("Classic Hamper", 2999),
                ProductVariant("Grand Edition (+Quran Pak)", 4199)
            )
        ),
        Product(
            id = "islamic_hijab_kit",
            name = "Silk Hijab & Magnetic Gold Pin Set",
            subtitle = "Modal Undercap · 4 Snag-Free Emerald & Gold Magnets",
            category = ProductCategory.ISLAMIC_PRODUCTS,
            categoryId = "cat_hijab_accessories",
            categoryName = "Hijab Accessories",
            priceInr = 799,
            originalPriceInr = 999,
            stockCount = 24,
            rating = 4.9,
            reviewCount = 88,
            badge = "DEMO · HIJAB",
            isFeatured = false,
            drawableResName = "img_category_islamic",
            topNotes = "Breathable Modal Jersey Cap",
            heartNotes = "4 Strong Neodymium Magnetic Pins",
            baseNotes = "Silk-Touch Travel Organiser",
            originOrMaterial = "Pinless Hold · No Fabric Snags",
            description = "Thoughtfully paired hijab essentials combining a soft modal undercap with strong brushed-gold magnetic pins that never pierce delicate scarves.",
            variants = listOf(
                ProductVariant("Emerald & Gold Set", 799),
                ProductVariant("Matte Black & Gold Set", 799)
            )
        ),
        Product(
            id = "islamic_brass_mabkhara",
            name = "Brass Mabkhara & Royal Bakhoor Set",
            subtitle = "Engraved Incense Burner + 50g Oud Chips",
            category = ProductCategory.ISLAMIC_PRODUCTS,
            categoryId = "cat_other_islamic",
            categoryName = "Other Islamic Essentials",
            priceInr = 1699,
            originalPriceInr = 1999,
            stockCount = 12,
            rating = 4.9,
            reviewCount = 52,
            badge = "DEMO · BAKHOOR",
            isFeatured = false,
            drawableResName = "img_category_islamic",
            topNotes = "Carved Solid Brass Vessel",
            heartNotes = "50g Royal Oud Bakhoor",
            baseNotes = "Tongs & Charcoal Pack",
            originOrMaterial = "Complete Home Fragrance Ritual",
            description = "Elevate your home ambiance for guests and Jummah with an intricately engraved brass mabkhara paired with aromatic oud bakhoor tablets.",
            variants = listOf(
                ProductVariant("Burner Only", 1199),
                ProductVariant("Complete Set", 1699)
            )
        )
    )

    fun findById(id: String): Product? = products.firstOrNull { it.id == id }
}
