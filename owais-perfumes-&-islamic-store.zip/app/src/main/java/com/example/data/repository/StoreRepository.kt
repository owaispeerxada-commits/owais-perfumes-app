package com.example.data.repository

import com.example.data.local.CartItemEntity
import com.example.data.local.CustomerProfileEntity
import com.example.data.local.OrderEntity
import com.example.data.local.StoreDao
import com.example.data.local.WishlistEntity
import com.example.data.model.Product
import com.example.data.model.ProductVariant
import com.example.data.model.StoreCatalog
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class StoreRepository(private val dao: StoreDao) {

    fun getAllProducts(): List<Product> = StoreCatalog.products

    fun getProductById(productId: String): Product? = StoreCatalog.findById(productId)

    val cartItems: Flow<List<CartItemEntity>> = dao.observeCartItems()

    val wishlistIds: Flow<Set<String>> = dao.observeWishlist()
        .map { list -> list.map { it.productId }.toSet() }

    val orders: Flow<List<OrderEntity>> = dao.observeOrders()

    val customerProfile: Flow<CustomerProfileEntity?> = dao.observeProfile()

    suspend fun addToCart(product: Product, variant: ProductVariant, quantity: Int = 1) {
        val key = "${product.id}_${variant.label}"
        val existing = dao.getCartItem(key)
        if (existing != null) {
            dao.updateCartQuantity(key, existing.quantity + quantity)
        } else {
            dao.upsertCartItem(
                CartItemEntity(
                    cartKey = key,
                    productId = product.id,
                    productName = product.name,
                    categoryName = product.category.displayName,
                    variantLabel = variant.label,
                    unitPriceInr = variant.priceInr,
                    quantity = quantity,
                    drawableResName = product.drawableResName
                )
            )
        }
    }

    suspend fun updateCartQuantity(cartKey: String, newQuantity: Int) {
        if (newQuantity <= 0) {
            dao.deleteCartItem(cartKey)
        } else {
            dao.updateCartQuantity(cartKey, newQuantity)
        }
    }

    suspend fun removeFromCart(cartKey: String) {
        dao.deleteCartItem(cartKey)
    }

    suspend fun toggleWishlist(productId: String): Boolean {
        return if (dao.isWishlisted(productId)) {
            dao.deleteWishlistItem(productId)
            false
        } else {
            dao.insertWishlistItem(WishlistEntity(productId = productId))
            true
        }
    }

    suspend fun placeOrder(order: OrderEntity, clearCart: Boolean) {
        if (clearCart) {
            dao.placeOrderAndClearCart(order)
        } else {
            dao.insertOrder(order)
        }
    }

    suspend fun saveProfile(profile: CustomerProfileEntity) {
        dao.upsertProfile(profile)
    }
}
