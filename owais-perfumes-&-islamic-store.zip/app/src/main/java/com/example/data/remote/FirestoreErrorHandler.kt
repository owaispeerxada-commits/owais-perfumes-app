package com.example.data.remote

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import org.json.JSONArray
import org.json.JSONObject

enum class OperationType(val value: String) {
    CREATE("create"),
    UPDATE("update"),
    DELETE("delete"),
    LIST("list"),
    GET("get"),
    WRITE("write")
}

fun handleFirestoreError(
    e: Exception,
    operationType: OperationType,
    path: String,
    auth: FirebaseAuth
): Nothing {
    val currentUser = auth.currentUser
    val providerInfo = JSONArray().apply {
        currentUser?.providerData?.forEach { profile ->
            put(
                JSONObject().apply {
                    put("providerId", profile.providerId)
                    put("displayName", profile.displayName)
                    put("email", profile.email)
                    put("photoUrl", profile.photoUrl?.toString())
                }
            )
        }
    }
    val errInfo = JSONObject().apply {
        put("error", e.message ?: e.toString())
        put("operationType", operationType.value)
        put("path", path)
        put(
            "authInfo",
            JSONObject().apply {
                put("userId", currentUser?.uid)
                put("email", currentUser?.email)
                put("emailVerified", currentUser?.isEmailVerified)
                put("isAnonymous", currentUser?.isAnonymous)
                put("tenantId", currentUser?.tenantId)
                put("providerInfo", providerInfo)
            }
        )
    }
    Log.e("FirestoreError", errInfo.toString())
    throw RuntimeException(errInfo.toString(), e)
}
