package com.example.data.remote

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.local.CartItemEntity
import com.example.data.local.CustomerProfileEntity
import com.example.data.model.DeliveryAddress
import com.example.data.model.OrderStatus
import com.example.data.model.PaymentPreference
import com.example.data.model.PaymentStatus
import com.example.data.model.Product
import com.example.data.model.ProductCategory
import com.example.data.model.ProductVariant
import com.example.data.model.StoreBanner
import com.example.data.model.StoreCatalog
import com.example.data.model.StoreCategory
import com.example.data.model.StoreConstants
import com.example.data.model.StoreOrder
import com.example.data.model.StoreSettingsConfig
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import java.util.UUID

class StoreFirestoreRepository(context: Context) {

    private val appContext = context.applicationContext
    val db: FirebaseFirestore = FirebaseFirestore.getInstance(
        appContext.getString(R.string.firestore_database_id)
    )
    val auth: FirebaseAuth = FirebaseAuth.getInstance()

    fun isBootstrappedAdmin(user: FirebaseUser?): Boolean {
        if (user == null) return false
        return user.isEmailVerified &&
            user.email?.equals(StoreConstants.OWNER_EMAIL, ignoreCase = true) == true
    }

    suspend fun checkIsAdmin(user: FirebaseUser?): Boolean {
        if (user == null) return false
        if (isBootstrappedAdmin(user)) return true
        return try {
            val snap = db.collection("admin_roles").document(user.uid).get().await()
            snap.exists()
        } catch (_: Exception) {
            false
        }
    }

    suspend fun ensureUserProfile(user: FirebaseUser): Result<Unit> {
        val path = "users/${user.uid}"
        return try {
            val ref = db.collection("users").document(user.uid)
            val snap = ref.get().await()
            if (!snap.exists()) {
                val safeName = user.displayName?.take(80)?.ifBlank { "Valued Patron" } ?: "Valued Patron"
                val safeEmail = user.email?.take(160)?.ifBlank { "${user.uid}@owaisstore.app" }
                    ?: "${user.uid}@owaisstore.app"
                val payload = mapOf(
                    "userId" to user.uid,
                    "fullName" to safeName,
                    "email" to safeEmail,
                    "phone" to (user.phoneNumber ?: ""),
                    "preferredScent" to "Oud & Saffron",
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                ref.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            Log.e("StoreFirestoreRepo", "ensureUserProfile failed at $path", e)
            Result.failure(e)
        }
    }

    fun observeUserProfile(uid: String): Flow<CustomerProfileEntity?> = callbackFlow {
        val reg = db.collection("users").document(uid)
            .addSnapshotListener(MetadataChanges.EXCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                if (snap != null && snap.exists()) {
                    val fs = snap.toObject(FsUserProfile::class.java)
                    trySend(
                        fs?.let {
                            CustomerProfileEntity(
                                id = 1,
                                fullName = it.fullName,
                                phoneNumber = it.phone,
                                addressLine = "",
                                city = "Kupwara",
                                pincode = "193222",
                                preferredScent = it.preferredScent.ifBlank { "Oud & Saffron" }
                            )
                        }
                    )
                } else {
                    trySend(null)
                }
            }
        awaitClose { reg.remove() }
    }

    suspend fun saveUserProfile(
        uid: String,
        email: String,
        fullName: String,
        phone: String,
        preferredScent: String
    ): Result<Unit> {
        val ref = db.collection("users").document(uid)
        return try {
            val snap = ref.get().await()
            val safeName = fullName.trim().ifBlank { "Valued Patron" }.take(80)
            val safeEmail = email.ifBlank { auth.currentUser?.email ?: "${uid}@owaisstore.app" }.take(160)
            if (!snap.exists()) {
                ref.set(
                    mapOf(
                        "userId" to uid,
                        "fullName" to safeName,
                        "email" to safeEmail,
                        "phone" to phone.trim().take(24),
                        "preferredScent" to preferredScent.take(60),
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                ref.update(
                    mapOf(
                        "fullName" to safeName,
                        "email" to safeEmail,
                        "phone" to phone.trim().take(24),
                        "preferredScent" to preferredScent.take(60),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            Result.failure(e)
        }
    }

    fun observeAddresses(uid: String): Flow<List<DeliveryAddress>> = callbackFlow {
        val reg = db.collection("users").document(uid).collection("addresses")
            .orderBy("updatedAt", Query.Direction.DESCENDING)
            .addSnapshotListener(MetadataChanges.EXCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val list = snap?.documents?.mapNotNull { doc ->
                    doc.toObject(FsDeliveryAddress::class.java)?.let {
                        DeliveryAddress(
                            id = doc.id,
                            label = it.label,
                            recipientName = it.recipientName,
                            phone = it.phone,
                            streetAddress = it.streetAddress,
                            city = it.city,
                            state = it.state,
                            pincode = it.pincode,
                            defaultAddress = it.defaultAddress
                        )
                    }
                }.orEmpty()
                trySend(list)
            }
        awaitClose { reg.remove() }
    }

    suspend fun saveDeliveryAddress(uid: String, address: DeliveryAddress): Result<Unit> {
        return try {
            val col = db.collection("users").document(uid).collection("addresses")
            val docId = address.id.ifBlank { "addr_${UUID.randomUUID().toString().take(12)}" }
            val ref = col.document(docId)
            val snap = ref.get().await()
            if (!snap.exists()) {
                ref.set(
                    mapOf(
                        "userId" to uid,
                        "label" to address.label.trim().ifBlank { "Home" }.take(40),
                        "recipientName" to address.recipientName.trim().ifBlank { "Customer" }.take(80),
                        "phone" to address.phone.trim().take(24),
                        "streetAddress" to address.streetAddress.trim().take(240),
                        "city" to address.city.trim().take(80),
                        "state" to address.state.trim().take(80),
                        "pincode" to address.pincode.trim().take(16),
                        "defaultAddress" to address.defaultAddress,
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                ref.update(
                    mapOf(
                        "label" to address.label.trim().ifBlank { "Home" }.take(40),
                        "recipientName" to address.recipientName.trim().ifBlank { "Customer" }.take(80),
                        "phone" to address.phone.trim().take(24),
                        "streetAddress" to address.streetAddress.trim().take(240),
                        "city" to address.city.trim().take(80),
                        "state" to address.state.trim().take(80),
                        "pincode" to address.pincode.trim().take(16),
                        "defaultAddress" to address.defaultAddress,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            Result.failure(e)
        }
    }

    suspend fun deleteDeliveryAddress(uid: String, addressId: String): Result<Unit> = try {
        db.collection("users").document(uid).collection("addresses").document(addressId).delete().await()
        Result.success(Unit)
    } catch (e: Exception) {
        if (e is CancellationException) throw e
        Result.failure(e)
    }

    fun observeCategories(): Flow<List<StoreCategory>> = callbackFlow {
        val reg = db.collection("categories")
            .orderBy("displayOrder", Query.Direction.ASCENDING)
            .addSnapshotListener(MetadataChanges.EXCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val list = snap?.documents?.mapNotNull { doc ->
                    doc.toObject(FsCategory::class.java)?.let {
                        StoreCategory(
                            id = doc.id,
                            name = it.name,
                            groupType = runCatching { ProductCategory.valueOf(it.groupType) }
                                .getOrDefault(ProductCategory.CUSTOM),
                            subtitle = it.subtitle,
                            displayOrder = it.displayOrder,
                            enabled = it.enabled,
                            drawableResName = it.drawableResName.ifBlank { "img_category_perfumes" }
                        )
                    }
                }.orEmpty()
                trySend(list)
            }
        awaitClose { reg.remove() }
    }

    fun observeProducts(): Flow<List<Product>> = callbackFlow {
        val reg = db.collection("products")
            .addSnapshotListener(MetadataChanges.EXCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val list = snap?.documents?.mapNotNull { doc ->
                    doc.toObject(FsProduct::class.java)?.toDomain(doc.id)
                }.orEmpty()
                trySend(list)
            }
        awaitClose { reg.remove() }
    }

    fun observeBanners(): Flow<List<StoreBanner>> = callbackFlow {
        val reg = db.collection("banners")
            .orderBy("displayOrder", Query.Direction.ASCENDING)
            .addSnapshotListener(MetadataChanges.EXCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val list = snap?.documents?.mapNotNull { doc ->
                    doc.toObject(FsBanner::class.java)?.let {
                        StoreBanner(
                            id = doc.id,
                            title = it.title,
                            subtitle = it.subtitle,
                            badgeText = it.badgeText,
                            ctaText = it.ctaText,
                            targetCategory = it.targetCategory,
                            drawableResName = it.drawableResName.ifBlank { "img_hero_banner" },
                            imageUrl = it.imageUrl,
                            active = it.active,
                            displayOrder = it.displayOrder
                        )
                    }
                }.orEmpty()
                trySend(list)
            }
        awaitClose { reg.remove() }
    }

    fun observeStoreSettings(): Flow<StoreSettingsConfig?> = callbackFlow {
        val reg = db.collection("store_settings").document("main")
            .addSnapshotListener(MetadataChanges.EXCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val fs = if (snap != null && snap.exists()) snap.toObject(FsStoreSettings::class.java) else null
                trySend(
                    fs?.let {
                        StoreSettingsConfig(
                            storeName = it.storeName,
                            brandOfficial = it.brandOfficial,
                            tagline = it.tagline,
                            location = it.location,
                            whatsappNumber = it.whatsappNumber,
                            instagramHandle = it.instagramHandle,
                            instagramUrl = it.instagramUrl,
                            deliveryChargeInr = it.deliveryChargeInr,
                            freeDeliveryThresholdInr = it.freeDeliveryThresholdInr,
                            codEnabled = it.codEnabled,
                            upiId = it.upiId,
                            upiPayeeName = it.upiPayeeName,
                            paymentInstructions = it.paymentInstructions,
                            aboutStory = it.aboutStory.ifBlank { StoreConstants.ABOUT_STORY }
                        )
                    }
                )
            }
        awaitClose { reg.remove() }
    }

    fun observeCart(uid: String): Flow<List<CartItemEntity>> = callbackFlow {
        val reg = db.collection("cart")
            .whereEqualTo("userId", uid)
            .addSnapshotListener(MetadataChanges.EXCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val items = snap?.documents?.mapNotNull { doc ->
                    val ts = doc.getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                        ?.toDate()?.time ?: System.currentTimeMillis()
                    doc.toObject(FsCartItem::class.java)?.let {
                        CartItemEntity(
                            cartKey = doc.id,
                            productId = it.productId,
                            productName = it.productName,
                            categoryName = it.categoryName,
                            variantLabel = it.variantLabel,
                            unitPriceInr = it.unitPriceInr,
                            quantity = it.quantity,
                            drawableResName = it.drawableResName.ifBlank { "img_hero_banner" },
                            addedAt = ts
                        )
                    }
                }?.sortedByDescending { it.addedAt }.orEmpty()
                trySend(items)
            }
        awaitClose { reg.remove() }
    }

    suspend fun addToCart(
        uid: String,
        product: Product,
        variant: ProductVariant,
        quantity: Int
    ): Result<Unit> {
        val cleanKey = "${uid}_${product.id}_${variant.label}".replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
        val ref = db.collection("cart").document(cleanKey)
        return try {
            val snap = ref.get().await()
            if (snap.exists()) {
                val currentQty = (snap.getLong("quantity") ?: 1L).toInt()
                val updatedQty = (currentQty + quantity).coerceIn(1, 50)
                ref.update(
                    mapOf(
                        "quantity" to updatedQty,
                        "unitPriceInr" to variant.priceInr,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                ).await()
            } else {
                val payload = mapOf(
                    "userId" to uid,
                    "productId" to product.id,
                    "productName" to product.name.take(120),
                    "categoryName" to product.categoryName.take(60),
                    "variantLabel" to variant.label.take(60),
                    "unitPriceInr" to variant.priceInr,
                    "quantity" to quantity.coerceIn(1, 50),
                    "drawableResName" to product.drawableResName.take(80),
                    "imageUrl" to product.imageUrls.firstOrNull().orEmpty().take(500),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                ref.set(payload).await()
            }
            Result.success(Unit)
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            Result.failure(e)
        }
    }

    suspend fun updateCartQuantity(cartKey: String, newQuantity: Int): Result<Unit> = try {
        val ref = db.collection("cart").document(cartKey)
        if (newQuantity <= 0) {
            ref.delete().await()
        } else {
            ref.update(
                mapOf(
                    "quantity" to newQuantity.coerceAtMost(50),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
        Result.success(Unit)
    } catch (e: Exception) {
        if (e is CancellationException) throw e
        Result.failure(e)
    }

    suspend fun removeFromCart(cartKey: String): Result<Unit> = try {
        db.collection("cart").document(cartKey).delete().await()
        Result.success(Unit)
    } catch (e: Exception) {
        if (e is CancellationException) throw e
        Result.failure(e)
    }

    fun observeWishlist(uid: String): Flow<Set<String>> = callbackFlow {
        val reg = db.collection("wishlist")
            .whereEqualTo("userId", uid)
            .addSnapshotListener(MetadataChanges.EXCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val ids = snap?.documents?.mapNotNull { it.getString("productId") }?.toSet().orEmpty()
                trySend(ids)
            }
        awaitClose { reg.remove() }
    }

    suspend fun toggleWishlist(uid: String, productId: String): Result<Boolean> {
        val docId = "${uid}_${productId}".replace(Regex("[^a-zA-Z0-9_\\-]"), "_")
        val ref = db.collection("wishlist").document(docId)
        return try {
            val snap = ref.get().await()
            if (snap.exists()) {
                ref.delete().await()
                Result.success(false)
            } else {
                ref.set(
                    mapOf(
                        "userId" to uid,
                        "productId" to productId,
                        "createdAt" to FieldValue.serverTimestamp()
                    )
                ).await()
                Result.success(true)
            }
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            Result.failure(e)
        }
    }

    fun observeUserOrders(uid: String): Flow<List<StoreOrder>> = callbackFlow {
        val reg = db.collection("orders")
            .whereEqualTo("userId", uid)
            .addSnapshotListener(MetadataChanges.EXCLUDE) { snap, err ->
                if (err != null) {
                    close(err)
                    return@addSnapshotListener
                }
                val orders = snap?.documents?.mapNotNull { doc -> doc.toStoreOrder() }
                    ?.sortedByDescending { it.createdAtMillis }
                    .orEmpty()
                trySend(orders)
            }
        awaitClose { reg.remove() }
    }

    suspend fun placeOrder(
        user: FirebaseUser,
        orderNumber: String,
        customerName: String,
        customerPhone: String,
        deliveryAddress: String,
        items: List<CartItemEntity>,
        deliveryChargeInr: Int,
        paymentPreference: PaymentPreference,
        upiTransactionRef: String,
        whatsappMessage: String,
        idempotencyKey: String,
        clearCart: Boolean
    ): Result<StoreOrder> {
        val orderDocId = "ord_${idempotencyKey.replace(Regex("[^a-zA-Z0-9_\\-]"), "_")}"
        val orderRef = db.collection("orders").document(orderDocId)
        return try {
            val existing = orderRef.get().await()
            if (existing.exists()) {
                val mapped = existing.toStoreOrder()
                if (mapped != null) return Result.success(mapped)
            }

            val subtotalInr = items.sumOf { it.unitPriceInr * it.quantity }
            val totalAmountInr = subtotalInr + deliveryChargeInr
            val itemCount = items.sumOf { it.quantity }
            val summary = items.joinToString("\n") {
                "${it.productName} (${it.variantLabel}) x${it.quantity} — ₹${it.unitPriceInr * it.quantity}"
            }.take(2000)
            val paymentStatus = if (paymentPreference == PaymentPreference.UPI && upiTransactionRef.isNotBlank()) {
                PaymentStatus.PENDING_VERIFICATION.label
            } else {
                PaymentStatus.UNVERIFIED.label
            }
            val safePhone = customerPhone.trim().let { if (it.length >= 6) it.take(24) else "+91 0000000000" }
            val payload = mapOf(
                "userId" to user.uid,
                "orderNumber" to orderNumber.take(40),
                "customerName" to customerName.trim().ifBlank { user.displayName ?: "Valued Patron" }.take(80),
                "customerEmail" to user.email.orEmpty().take(160),
                "customerPhone" to safePhone,
                "deliveryAddress" to deliveryAddress.trim().ifBlank { StoreConstants.STORE_LOCATION }.take(300),
                "itemsSummary" to summary,
                "itemCount" to itemCount.coerceIn(1, 100),
                "subtotalInr" to subtotalInr.coerceAtLeast(1),
                "deliveryChargeInr" to deliveryChargeInr.coerceAtLeast(0),
                "totalAmountInr" to totalAmountInr.coerceAtLeast(1),
                "paymentPreference" to paymentPreference.code,
                "paymentStatus" to paymentStatus,
                "upiTransactionRef" to upiTransactionRef.trim().take(80),
                "orderStatus" to OrderStatus.PENDING.label,
                "whatsappMessage" to whatsappMessage.take(3500),
                "idempotencyKey" to idempotencyKey.take(128),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )

            val batch = db.batch()
            batch.set(orderRef, payload)
            if (clearCart) {
                items.forEach { cartItem ->
                    batch.delete(db.collection("cart").document(cartItem.cartKey))
                }
            }
            batch.commit().await()

            val created = StoreOrder(
                id = orderDocId,
                userId = user.uid,
                orderNumber = orderNumber,
                createdAtMillis = System.currentTimeMillis(),
                customerName = payload["customerName"] as String,
                customerEmail = payload["customerEmail"] as String,
                customerPhone = safePhone,
                deliveryAddress = payload["deliveryAddress"] as String,
                itemsSummary = summary,
                itemCount = itemCount,
                subtotalInr = subtotalInr,
                deliveryChargeInr = deliveryChargeInr,
                totalAmountInr = totalAmountInr,
                paymentPreference = paymentPreference,
                paymentStatus = PaymentStatus.fromLabel(paymentStatus),
                upiTransactionRef = upiTransactionRef.trim(),
                orderStatus = OrderStatus.PENDING,
                whatsappMessage = whatsappMessage,
                idempotencyKey = idempotencyKey
            )
            Result.success(created)
        } catch (e: Exception) {
            if (e is CancellationException) throw e
            Result.failure(e)
        }
    }

    suspend fun cancelPendingOrder(orderId: String): Result<Unit> = try {
        db.collection("orders").document(orderId)
            .update(
                mapOf(
                    "orderStatus" to OrderStatus.CANCELLED.label,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        Result.success(Unit)
    } catch (e: Exception) {
        if (e is CancellationException) throw e
        Result.failure(e)
    }

    suspend fun submitUpiReference(orderId: String, utrRef: String): Result<Unit> = try {
        db.collection("orders").document(orderId)
            .update(
                mapOf(
                    "upiTransactionRef" to utrRef.trim().take(80),
                    "paymentStatus" to PaymentStatus.PENDING_VERIFICATION.label,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        Result.success(Unit)
    } catch (e: Exception) {
        if (e is CancellationException) throw e
        Result.failure(e)
    }

    companion object {
        fun FsProduct.toDomain(docId: String): Product {
            val catGroup = runCatching { ProductCategory.valueOf(groupType) }
                .getOrDefault(ProductCategory.PERFUMES)
            val variants = if (variantLabels.isNotEmpty() && variantLabels.size == variantPrices.size) {
                variantLabels.zip(variantPrices).map { (label, price) -> ProductVariant(label, price) }
            } else {
                listOf(ProductVariant("Standard", priceInr))
            }
            return Product(
                id = docId,
                name = name,
                subtitle = subtitle,
                category = catGroup,
                categoryId = categoryId,
                categoryName = categoryName.ifBlank { catGroup.displayName },
                priceInr = priceInr,
                originalPriceInr = if (discountPriceInr > priceInr) discountPriceInr else null,
                stockCount = stockCount,
                rating = rating,
                reviewCount = reviewCount,
                badge = badge.ifBlank { "OWAIS OFFICIAL" },
                isDemo = demoItem,
                isFeatured = featured,
                enabled = enabled,
                drawableResName = drawableResName.ifBlank { "img_hero_banner" },
                imageUrls = imageUrls,
                topNotes = topNotes,
                heartNotes = heartNotes,
                baseNotes = baseNotes,
                originOrMaterial = originOrMaterial,
                description = description,
                variants = variants
            )
        }

        fun DocumentSnapshot.toStoreOrder(): StoreOrder? {
            val fs = toObject(FsOrder::class.java) ?: return null
            val ts = getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
                ?.toDate()?.time ?: System.currentTimeMillis()
            return StoreOrder(
                id = id,
                userId = fs.userId,
                orderNumber = fs.orderNumber,
                createdAtMillis = ts,
                customerName = fs.customerName,
                customerEmail = fs.customerEmail,
                customerPhone = fs.customerPhone,
                deliveryAddress = fs.deliveryAddress,
                itemsSummary = fs.itemsSummary,
                itemCount = fs.itemCount,
                subtotalInr = fs.subtotalInr,
                deliveryChargeInr = fs.deliveryChargeInr,
                totalAmountInr = fs.totalAmountInr,
                paymentPreference = PaymentPreference.fromCode(fs.paymentPreference),
                paymentStatus = PaymentStatus.fromLabel(fs.paymentStatus),
                upiTransactionRef = fs.upiTransactionRef,
                orderStatus = OrderStatus.fromLabel(fs.orderStatus),
                whatsappMessage = fs.whatsappMessage,
                idempotencyKey = fs.idempotencyKey
            )
        }
    }
}
