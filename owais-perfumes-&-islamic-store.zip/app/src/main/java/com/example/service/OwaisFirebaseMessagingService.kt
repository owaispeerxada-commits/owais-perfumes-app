package com.example.service

import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class OwaisFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d("OwaisFCM", "FCM registration token refreshed")
    }

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        val title = message.notification?.title
            ?: message.data["title"]
            ?: "OWAIS PERFUMES & ISLAMIC STORE"
        val body = message.notification?.body
            ?: message.data["body"]
            ?: "Your order status has been updated."
        val id = (message.messageId?.hashCode() ?: System.currentTimeMillis().toInt())

        OwaisNotificationHelper.showOrderNotification(
            context = applicationContext,
            notificationId = id,
            title = title,
            body = body
        )
    }
}
