package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.outlined.Category
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.data.local.StoreDatabase
import com.example.data.remote.StoreFirestoreRepository
import com.example.data.repository.StoreRepository
import com.example.service.OwaisNotificationHelper
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.CartScreen
import com.example.ui.screens.CategoriesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LegalInfoScreen
import com.example.ui.screens.LegalInfoTopic
import com.example.ui.screens.OrdersScreen
import com.example.ui.screens.ProductDetailScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.SearchScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.WishlistScreen
import com.example.ui.theme.BrightGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.EmeraldVelvet
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MatteBlack
import com.example.ui.theme.OnyxSurface
import com.example.ui.theme.OwaisLuxuryTheme
import com.example.ui.theme.SageMuted
import com.example.ui.viewmodel.StoreUiEvent
import com.example.ui.viewmodel.StoreViewModel
import com.example.ui.viewmodel.StoreViewModelFactory
import com.example.util.openUpiPaymentApp
import com.example.util.openWhatsAppWithMessage
import kotlinx.coroutines.launch

object StoreRoutes {
    const val HOME = "home"
    const val CATEGORIES = "categories"
    const val WISHLIST = "wishlist"
    const val ORDERS = "orders"
    const val PROFILE = "profile"
    const val SEARCH = "search"
    const val CART = "cart"
    const val ADMIN = "admin"
    const val PRODUCT_DETAIL = "product/{productId}"
    const val LEGAL_INFO = "legal/{topic}"

    fun productDetail(productId: String): String = "product/$productId"
    fun legalInfo(topic: LegalInfoTopic): String = "legal/${topic.name}"
}

private enum class TopLevelTab(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    HOME(StoreRoutes.HOME, "Home", Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
    CATEGORIES(StoreRoutes.CATEGORIES, "Categories", Icons.Filled.Category, Icons.Outlined.Category, "nav_categories"),
    WISHLIST(StoreRoutes.WISHLIST, "Wishlist", Icons.Filled.Favorite, Icons.Outlined.FavoriteBorder, "nav_wishlist"),
    ORDERS(StoreRoutes.ORDERS, "My Orders", Icons.Filled.ReceiptLong, Icons.Outlined.ReceiptLong, "nav_orders"),
    PROFILE(StoreRoutes.PROFILE, "Profile", Icons.Filled.Person, Icons.Outlined.Person, "nav_profile")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )

        OwaisNotificationHelper.ensureNotificationChannel(applicationContext)

        val database = StoreDatabase.getInstance(applicationContext)
        val localRepository = StoreRepository(database.storeDao())
        val firestoreRepository = StoreFirestoreRepository(applicationContext)

        setContent {
            OwaisLuxuryTheme {
                val storeViewModel: StoreViewModel = viewModel(
                    factory = StoreViewModelFactory(application, localRepository, firestoreRepository)
                )
                OwaisStoreApp(viewModel = storeViewModel)
            }
        }
    }
}

@Composable
fun OwaisStoreApp(viewModel: StoreViewModel) {
    var showSplash by rememberSaveable { mutableStateOf(true) }

    if (showSplash) {
        SplashScreen(onFinished = { showSplash = false })
        return
    }

    val navController = rememberNavController()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val isAdmin by viewModel.isAdmin.collectAsStateWithLifecycle()
    val categories by viewModel.categories.collectAsStateWithLifecycle()
    val allProducts by viewModel.allProducts.collectAsStateWithLifecycle()
    val activeProducts by viewModel.activeProducts.collectAsStateWithLifecycle()
    val banners by viewModel.banners.collectAsStateWithLifecycle()
    val storeSettings by viewModel.storeSettings.collectAsStateWithLifecycle()

    val homeProducts by viewModel.homeProducts.collectAsStateWithLifecycle()
    val selectedHomeCategory by viewModel.selectedHomeCategory.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val searchCategory by viewModel.searchCategory.collectAsStateWithLifecycle()
    val searchSubCategoryId by viewModel.searchSubCategoryId.collectAsStateWithLifecycle()
    val sortOption by viewModel.sortOption.collectAsStateWithLifecycle()
    val searchResults by viewModel.searchResults.collectAsStateWithLifecycle()
    val cartItems by viewModel.cartItems.collectAsStateWithLifecycle()
    val cartCount by viewModel.cartItemCount.collectAsStateWithLifecycle()
    val cartSubtotal by viewModel.cartSubtotalInr.collectAsStateWithLifecycle()
    val wishlistIds by viewModel.wishlistIds.collectAsStateWithLifecycle()
    val wishlistProducts by viewModel.wishlistProducts.collectAsStateWithLifecycle()
    val orders by viewModel.orders.collectAsStateWithLifecycle()
    val customerProfile by viewModel.customerProfile.collectAsStateWithLifecycle()
    val savedAddresses by viewModel.savedAddresses.collectAsStateWithLifecycle()
    val adminOrders by viewModel.adminOrders.collectAsStateWithLifecycle()
    val adminAnalytics by viewModel.adminAnalytics.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        viewModel.events.collect { event ->
            when (event) {
                is StoreUiEvent.ShowMessage -> {
                    snackbarHostState.showSnackbar(
                        message = event.message,
                        duration = SnackbarDuration.Short
                    )
                }

                is StoreUiEvent.LaunchWhatsAppOrder -> {
                    val launched = openWhatsAppWithMessage(
                        context = context,
                        message = event.message,
                        whatsappDigits = storeSettings.whatsappDigits
                    )
                    val msg = if (launched) {
                        "Order ${event.orderId} saved! Opening WhatsApp (${storeSettings.whatsappNumber})"
                    } else {
                        "Order ${event.orderId} saved & message copied for WhatsApp (${storeSettings.whatsappNumber})"
                    }
                    val result = snackbarHostState.showSnackbar(
                        message = msg,
                        actionLabel = "My Orders",
                        duration = SnackbarDuration.Long
                    )
                    if (result == SnackbarResult.ActionPerformed) {
                        navController.navigate(StoreRoutes.ORDERS)
                    }
                }

                is StoreUiEvent.LaunchUpiPayment -> {
                    val opened = openUpiPaymentApp(
                        context = context,
                        upiId = event.upiId,
                        payeeName = event.payeeName,
                        amountInr = event.amountInr,
                        orderNote = "Order ${event.orderNumber}"
                    )
                    val msg = if (opened) {
                        "Order ${event.orderNumber} placed — complete UPI & submit UTR in My Orders."
                    } else {
                        "Order ${event.orderNumber} placed — UPI ID (${event.upiId}) copied. Submit UTR in My Orders."
                    }
                    val result = snackbarHostState.showSnackbar(
                        message = msg,
                        actionLabel = "My Orders",
                        duration = SnackbarDuration.Long
                    )
                    if (result == SnackbarResult.ActionPerformed) {
                        navController.navigate(StoreRoutes.ORDERS)
                    }
                }
            }
        }
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route
    val showTopLevelNav = currentRoute in TopLevelTab.entries.map { it.route }

    fun navigateToTab(route: String) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        val useNavigationRail = maxWidth >= 600.dp

        Row(modifier = Modifier.fillMaxSize()) {
            if (showTopLevelNav && useNavigationRail) {
                NavigationRail(
                    containerColor = OnyxSurface,
                    contentColor = IvoryText
                ) {
                    TopLevelTab.entries.forEach { tab ->
                        val selected = currentRoute == tab.route
                        NavigationRailItem(
                            selected = selected,
                            onClick = { navigateToTab(tab.route) },
                            modifier = Modifier.testTag(tab.testTag),
                            icon = {
                                TabIconWithBadge(
                                    tab = tab,
                                    selected = selected,
                                    ordersCount = orders.size,
                                    wishlistCount = wishlistProducts.size
                                )
                            },
                            label = {
                                Text(
                                    text = tab.label,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = BrightGold,
                                selectedTextColor = BrightGold,
                                indicatorColor = EmeraldVelvet,
                                unselectedIconColor = SageMuted,
                                unselectedTextColor = SageMuted
                            )
                        )
                    }
                }
            }

            Scaffold(
                modifier = Modifier.weight(1f),
                containerColor = MatteBlack,
                contentWindowInsets = if (showTopLevelNav) {
                    WindowInsets.statusBars
                } else {
                    WindowInsets(0)
                },
                snackbarHost = {
                    SnackbarHost(hostState = snackbarHostState) { data ->
                        Snackbar(
                            snackbarData = data,
                            containerColor = EmeraldVelvet,
                            contentColor = IvoryText,
                            actionColor = BrightGold
                        )
                    }
                },
                bottomBar = {
                    if (showTopLevelNav && !useNavigationRail) {
                        NavigationBar(
                            containerColor = OnyxSurface,
                            contentColor = IvoryText,
                            windowInsets = WindowInsets.navigationBars
                        ) {
                            TopLevelTab.entries.forEach { tab ->
                                val selected = currentRoute == tab.route
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateToTab(tab.route) },
                                    modifier = Modifier.testTag(tab.testTag),
                                    icon = {
                                        TabIconWithBadge(
                                            tab = tab,
                                            selected = selected,
                                            ordersCount = orders.size,
                                            wishlistCount = wishlistProducts.size
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = tab.label,
                                            style = MaterialTheme.typography.labelSmall,
                                            maxLines = 1
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = BrightGold,
                                        selectedTextColor = BrightGold,
                                        indicatorColor = EmeraldVelvet,
                                        unselectedIconColor = SageMuted,
                                        unselectedTextColor = SageMuted
                                    )
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                NavHost(
                    navController = navController,
                    startDestination = StoreRoutes.HOME,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    composable(StoreRoutes.HOME) {
                        HomeScreen(
                            allProducts = activeProducts,
                            filteredProducts = homeProducts,
                            banners = banners,
                            storeSettings = storeSettings,
                            isSignedIn = currentUser != null,
                            userEmail = currentUser?.email,
                            selectedCategory = selectedHomeCategory,
                            wishlistIds = wishlistIds,
                            cartCount = cartCount,
                            onCategorySelected = { viewModel.selectHomeCategory(it) },
                            onProductClick = { product ->
                                navController.navigate(StoreRoutes.productDetail(product.id))
                            },
                            onWishlistToggle = { viewModel.toggleWishlist(it) },
                            onAddToCart = { viewModel.addToCart(it) },
                            onOpenSearch = { category, subCatId ->
                                viewModel.selectSearchCategory(category, subCatId)
                                navController.navigate(StoreRoutes.SEARCH)
                            },
                            onOpenCart = { navController.navigate(StoreRoutes.CART) },
                            onNotify = { msg ->
                                scope.launch { snackbarHostState.showSnackbar(msg) }
                            }
                        )
                    }

                    composable(StoreRoutes.CATEGORIES) {
                        CategoriesScreen(
                            categories = categories,
                            products = activeProducts,
                            onCategorySelected = { group, subCatId ->
                                viewModel.selectSearchCategory(group, subCatId)
                                navController.navigate(StoreRoutes.SEARCH)
                            },
                            onOpenSearch = {
                                viewModel.selectSearchCategory(null, null)
                                navController.navigate(StoreRoutes.SEARCH)
                            }
                        )
                    }

                    composable(StoreRoutes.SEARCH) {
                        SearchScreen(
                            query = searchQuery,
                            selectedCategory = searchCategory,
                            selectedSubCategoryId = searchSubCategoryId,
                            allCategories = categories,
                            sortOption = sortOption,
                            results = searchResults,
                            wishlistIds = wishlistIds,
                            onQueryChange = { viewModel.updateSearchQuery(it) },
                            onCategorySelected = { group, subCatId ->
                                viewModel.selectSearchCategory(group, subCatId)
                            },
                            onSortSelected = { viewModel.selectSortOption(it) },
                            onProductClick = { product ->
                                navController.navigate(StoreRoutes.productDetail(product.id))
                            },
                            onWishlistToggle = { viewModel.toggleWishlist(it) },
                            onAddToCart = { viewModel.addToCart(it) },
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable(StoreRoutes.WISHLIST) {
                        WishlistScreen(
                            wishlistProducts = wishlistProducts,
                            onProductClick = { product ->
                                navController.navigate(StoreRoutes.productDetail(product.id))
                            },
                            onWishlistToggle = { viewModel.toggleWishlist(it) },
                            onAddToCart = { viewModel.addToCart(it) },
                            onExploreClick = { navigateToTab(StoreRoutes.HOME) }
                        )
                    }

                    composable(StoreRoutes.CART) {
                        CartScreen(
                            cartItems = cartItems,
                            subtotalInr = cartSubtotal,
                            storeSettings = storeSettings,
                            customerProfile = customerProfile,
                            savedAddresses = savedAddresses,
                            onQuantityChange = { key, qty -> viewModel.updateCartQuantity(key, qty) },
                            onRemoveItem = { key -> viewModel.removeFromCart(key) },
                            onProductClick = { productId ->
                                navController.navigate(StoreRoutes.productDetail(productId))
                            },
                            onExploreClick = { navigateToTab(StoreRoutes.HOME) },
                            onBack = { navController.popBackStack() },
                            onPlaceOrder = { name, phone, address, pref, upiRef, launchWhatsApp ->
                                viewModel.checkoutCart(name, phone, address, pref, upiRef, launchWhatsApp)
                            }
                        )
                    }

                    composable(StoreRoutes.ORDERS) {
                        OrdersScreen(
                            orders = orders,
                            isSignedIn = currentUser != null,
                            storeSettings = storeSettings,
                            onExploreClick = { navigateToTab(StoreRoutes.HOME) },
                            onCancelOrder = { orderId -> viewModel.cancelOrder(orderId) },
                            onSubmitUpiRef = { orderId, utr -> viewModel.submitUpiRef(orderId, utr) },
                            onNotify = { msg ->
                                scope.launch { snackbarHostState.showSnackbar(msg) }
                            }
                        )
                    }

                    composable(StoreRoutes.PROFILE) {
                        ProfileScreen(
                            currentUser = currentUser,
                            isAdmin = isAdmin,
                            profile = customerProfile,
                            savedAddresses = savedAddresses,
                            storeSettings = storeSettings,
                            ordersCount = orders.size,
                            wishlistCount = wishlistProducts.size,
                            onSignedIn = { user -> viewModel.onSignedInSuccess(user) },
                            onSignOut = { viewModel.signOut() },
                            onOpenAdminDashboard = { navController.navigate(StoreRoutes.ADMIN) },
                            onSaveProfile = { name, phone, addr, city, pin, scent ->
                                viewModel.saveCustomerProfile(name, phone, addr, city, pin, scent)
                            },
                            onSaveAddress = { addr -> viewModel.saveDeliveryAddress(addr) },
                            onDeleteAddress = { addrId -> viewModel.deleteDeliveryAddress(addrId) },
                            onOpenOrders = { navigateToTab(StoreRoutes.ORDERS) },
                            onOpenWishlist = { navigateToTab(StoreRoutes.WISHLIST) },
                            onOpenLegalTopic = { topic ->
                                navController.navigate(StoreRoutes.legalInfo(topic))
                            },
                            onNotify = { msg ->
                                scope.launch { snackbarHostState.showSnackbar(msg) }
                            }
                        )
                    }

                    composable(StoreRoutes.ADMIN) {
                        if (isAdmin) {
                            AdminDashboardScreen(
                                analytics = adminAnalytics,
                                products = allProducts,
                                categories = categories,
                                orders = adminOrders,
                                banners = banners,
                                storeSettings = storeSettings,
                                onBack = { navController.popBackStack() },
                                onSeedCatalog = { viewModel.adminSeedCatalog() },
                                onSaveProduct = { prod -> viewModel.adminSaveProduct(prod) },
                                onDeleteProduct = { prodId -> viewModel.adminDeleteProduct(prodId) },
                                onToggleFeatured = { prod -> viewModel.adminToggleProductFeatured(prod) },
                                onToggleEnabled = { prod -> viewModel.adminToggleProductEnabled(prod) },
                                onUploadProductImage = { prodId, uri, cb ->
                                    viewModel.adminUploadProductImage(prodId, uri, cb)
                                },
                                onSaveCategory = { cat -> viewModel.adminSaveCategory(cat) },
                                onUpdateOrderStatus = { id, status, pStatus ->
                                    viewModel.adminUpdateOrderStatus(id, status, pStatus)
                                },
                                onSaveStoreSettings = { cfg -> viewModel.adminSaveStoreSettings(cfg) },
                                onSaveBanner = { banner -> viewModel.adminSaveBanner(banner) }
                            )
                        } else {
                            LaunchedEffect(Unit) { navController.popBackStack() }
                        }
                    }

                    composable(
                        route = StoreRoutes.LEGAL_INFO,
                        arguments = listOf(navArgument("topic") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val topicName = backStackEntry.arguments?.getString("topic").orEmpty()
                        val topic = runCatching { LegalInfoTopic.valueOf(topicName) }
                            .getOrDefault(LegalInfoTopic.ABOUT_US)
                        LegalInfoScreen(
                            topic = topic,
                            storeSettings = storeSettings,
                            onBack = { navController.popBackStack() },
                            onNotify = { msg -> scope.launch { snackbarHostState.showSnackbar(msg) } }
                        )
                    }

                    composable(
                        route = StoreRoutes.PRODUCT_DETAIL,
                        arguments = listOf(navArgument("productId") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val productId = backStackEntry.arguments?.getString("productId").orEmpty()
                        val product = viewModel.getProduct(productId)
                        if (product != null) {
                            ProductDetailScreen(
                                product = product,
                                isWishlisted = product.id in wishlistIds,
                                storeSettings = storeSettings,
                                customerProfile = customerProfile,
                                savedAddresses = savedAddresses,
                                onBack = { navController.popBackStack() },
                                onWishlistToggle = { viewModel.toggleWishlist(product) },
                                onAddToCart = { variant, qty ->
                                    viewModel.addToCart(product, variant, qty)
                                },
                                onBuyNow = { variant, qty, name, phone, addr, pref, upiRef, launchWa ->
                                    viewModel.buySingleProductNow(
                                        product, variant, qty, name, phone, addr, pref, upiRef, launchWa
                                    )
                                },
                                onOrderViaWhatsApp = { variant, qty ->
                                    viewModel.orderSingleProductViaWhatsApp(product, variant, qty)
                                }
                            )
                        } else {
                            LaunchedEffect(Unit) { navController.popBackStack() }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TabIconWithBadge(
    tab: TopLevelTab,
    selected: Boolean,
    ordersCount: Int,
    wishlistCount: Int
) {
    val badgeCount = when (tab) {
        TopLevelTab.ORDERS -> ordersCount
        TopLevelTab.WISHLIST -> wishlistCount
        else -> 0
    }
    val icon = if (selected) tab.selectedIcon else tab.unselectedIcon

    BadgedBox(
        badge = {
            if (badgeCount > 0) {
                Badge(
                    containerColor = ChampagneGold,
                    contentColor = MatteBlack
                ) {
                    Text(badgeCount.toString())
                }
            }
        }
    ) {
        Icon(
            imageVector = icon,
            contentDescription = tab.label
        )
    }
}
