package com.example.util

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.data.local.CartItemEntity
import com.example.data.model.PaymentPreference
import com.example.data.model.StoreConstants
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun formatInr(amount: Int): String {
    val formatter = NumberFormat.getNumberInstance(Locale("en", "IN"))
    return "₹${formatter.format(amount)}"
}

fun formatOrderDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
    return sdf.format(Date(timestamp))
}

fun buildWhatsAppOrderMessage(
    orderId: String,
    items: List<CartItemEntity>,
    totalAmountInr: Int,
    customerName: String,
    customerPhone: String,
    deliveryAddress: String,
    deliveryChargeInr: Int = 0,
    paymentPreference: PaymentPreference = PaymentPreference.WHATSAPP_CONFIRM,
    upiTransactionRef: String = ""
): String {
    val subtotalInr = items.sumOf { it.unitPriceInr * it.quantity }
    val sb = StringBuilder()
    sb.appendLine("Assalamu Alaikum *THE OWAIS OFFICIAL — OWAIS PERFUMES & ISLAMIC STORE*,")
    sb.appendLine("I would like to confirm my order:")
    sb.appendLine()
    sb.appendLine("*Order ID:* $orderId")
    sb.appendLine("*Items:*")
    items.forEachIndexed { index, item ->
        val lineTotal = item.unitPriceInr * item.quantity
        sb.appendLine("${index + 1}. ${item.productName} (${item.variantLabel}) x${item.quantity} — ${formatInr(lineTotal)}")
    }
    sb.appendLine()
    sb.appendLine("*Subtotal:* ${formatInr(subtotalInr)}")
    sb.appendLine("*Delivery Charge:* ${if (deliveryChargeInr == 0) "FREE" else formatInr(deliveryChargeInr)}")
    sb.appendLine("*Total Amount:* ${formatInr(totalAmountInr)}")
    sb.appendLine("*Payment Method:* ${paymentPreference.label}")
    if (upiTransactionRef.isNotBlank()) {
        sb.appendLine("*UPI Ref / UTR:* $upiTransactionRef")
    }
    sb.appendLine()
    sb.appendLine("*Customer Details:*")
    sb.appendLine("Name: ${customerName.ifBlank { "Valued Customer" }}")
    if (customerPhone.isNotBlank()) {
        sb.appendLine("Phone: $customerPhone")
    }
    sb.appendLine("Address: ${deliveryAddress.ifBlank { StoreConstants.STORE_LOCATION }}")
    sb.appendLine()
    sb.append("JazakAllahu Khayran!")
    return sb.toString()
}

fun openWhatsAppWithMessage(
    context: Context,
    message: String,
    whatsappDigits: String = StoreConstants.WHATSAPP_DIGITS
): Boolean {
    val cleanDigits = whatsappDigits.filter { it.isDigit() }.ifBlank { StoreConstants.WHATSAPP_DIGITS }
    val encoded = Uri.encode(message)
    val uri = Uri.parse("https://wa.me/$cleanDigits?text=$encoded")
    val intent = Intent(Intent.ACTION_VIEW, uri).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    return try {
        context.startActivity(intent)
        true
    } catch (_: ActivityNotFoundException) {
        copyToClipboard(context, "WhatsApp Order", message)
        false
    }
}

fun openWhatsAppConcierge(
    context: Context,
    whatsappDigits: String = StoreConstants.WHATSAPP_DIGITS
): Boolean {
    val greeting = "Assalamu Alaikum Owais Perfumes & Islamic Store! I would like to inquire about your collection."
    return openWhatsAppWithMessage(context, greeting, whatsappDigits)
}

fun openUpiPaymentApp(
    context: Context,
    upiId: String,
    payeeName: String,
    amountInr: Int,
    orderNote: String
): Boolean {
    if (upiId.isBlank() || amountInr <= 0) return false
    val uri = Uri.Builder()
        .scheme("upi")
        .authority("pay")
        .appendQueryParameter("pa", upiId.trim())
        .appendQueryParameter("pn", payeeName.ifBlank { StoreConstants.BRAND_OFFICIAL })
        .appendQueryParameter("tn", orderNote)
        .appendQueryParameter("am", "$amountInr.00")
        .appendQueryParameter("cu", "INR")
        .build()

    val intent = Intent(Intent.ACTION_VIEW, uri).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    return try {
        context.startActivity(intent)
        true
    } catch (_: ActivityNotFoundException) {
        copyToClipboard(context, "UPI ID", upiId)
        false
    }
}

fun openInstagramProfile(
    context: Context,
    instagramUrl: String = StoreConstants.INSTAGRAM_URL,
    handle: String = StoreConstants.INSTAGRAM_HANDLE
): Boolean {
    val targetUrl = instagramUrl.ifBlank { StoreConstants.INSTAGRAM_URL }
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUrl)).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    return try {
        context.startActivity(intent)
        true
    } catch (_: ActivityNotFoundException) {
        copyToClipboard(context, "Instagram Handle", handle)
        false
    }
}

fun openStoreInMaps(
    context: Context,
    location: String = StoreConstants.STORE_LOCATION
): Boolean {
    val targetLocation = location.ifBlank { StoreConstants.STORE_LOCATION }
    val geoUri = Uri.parse("geo:0,0?q=" + Uri.encode(targetLocation))
    val intent = Intent(Intent.ACTION_VIEW, geoUri).apply {
        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    return try {
        context.startActivity(intent)
        true
    } catch (_: ActivityNotFoundException) {
        val webUri = Uri.parse("https://maps.google.com/?q=" + Uri.encode(targetLocation))
        return try {
            context.startActivity(Intent(Intent.ACTION_VIEW, webUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            true
        } catch (_: ActivityNotFoundException) {
            copyToClipboard(context, "Store Address", targetLocation)
            false
        }
    }
}

fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
    clipboard?.setPrimaryClip(ClipData.newPlainText(label, text))
}
