package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.SearchOff
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.Product
import com.example.data.model.ProductCategory
import com.example.data.model.SortOption
import com.example.data.model.StoreCategory
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.components.LuxuryProductCard
import com.example.ui.theme.BrightGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.EmeraldVelvet
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MatteBlack
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.OnyxSurface
import com.example.ui.theme.SageMuted

@Composable
fun SearchScreen(
    query: String,
    selectedCategory: ProductCategory?,
    selectedSubCategoryId: String?,
    allCategories: List<StoreCategory>,
    sortOption: SortOption,
    results: List<Product>,
    wishlistIds: Set<String>,
    onQueryChange: (String) -> Unit,
    onCategorySelected: (ProductCategory?, String?) -> Unit,
    onSortSelected: (SortOption) -> Unit,
    onProductClick: (Product) -> Unit,
    onWishlistToggle: (Product) -> Unit,
    onAddToCart: (Product) -> Unit,
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    if (onBack != null) {
        BackHandler(onBack = onBack)
    }

    val quickTags = listOf("Khamrah", "Wafa", "Mask Oud", "White Oud", "Quran Pak", "Topi", "Tasbeeh", "Prayer Mat")
    val activeSubCat = allCategories.firstOrNull { it.id == selectedSubCategoryId }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        val columns = if (maxWidth >= 600.dp) 3 else 2
        val resultRows = results.chunked(columns)

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 28.dp)
        ) {
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (onBack != null) {
                            IconButton(
                                onClick = onBack,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("search_back_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back",
                                    tint = ChampagneGold
                                )
                            }
                        }
                        Text(
                            text = activeSubCat?.name ?: "Search Collection",
                            style = MaterialTheme.typography.headlineMedium,
                            color = IvoryText
                        )
                    }

                    OutlinedTextField(
                        value = query,
                        onValueChange = onQueryChange,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("search_input_field"),
                        placeholder = {
                            Text(
                                text = "Search Oud, Khamrah, Quran Pak, Tasbeeh...",
                                color = SageMuted
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.Search,
                                contentDescription = "Search",
                                tint = ChampagneGold
                            )
                        },
                        trailingIcon = {
                            if (query.isNotEmpty()) {
                                IconButton(
                                    onClick = { onQueryChange("") },
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .testTag("search_clear_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Close,
                                        contentDescription = "Clear search",
                                        tint = IvoryText
                                    )
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = OnyxSurface,
                            unfocusedContainerColor = OnyxSurface,
                            focusedBorderColor = ChampagneGold,
                            unfocusedBorderColor = ObsidianBorder,
                            focusedTextColor = IvoryText,
                            unfocusedTextColor = IvoryText,
                            cursorColor = ChampagneGold
                        )
                    )

                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(quickTags) { tag ->
                            Surface(
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .clickable { onQueryChange(tag) }
                                    .testTag("quick_tag_$tag"),
                                shape = RoundedCornerShape(50),
                                color = OnyxSurface,
                                border = BorderStroke(1.dp, ObsidianBorder)
                            ) {
                                Text(
                                    text = tag,
                                    style = MaterialTheme.typography.labelMedium,
                                    color = ChampagneGold,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                                )
                            }
                        }
                    }

                    // Broad group filters
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            FilterChip(
                                selected = selectedCategory == null && selectedSubCategoryId == null,
                                onClick = { onCategorySelected(null, null) },
                                label = { Text("All") },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = CharcoalElevated,
                                    labelColor = IvoryText,
                                    selectedContainerColor = EmeraldVelvet,
                                    selectedLabelColor = BrightGold
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = selectedCategory == null && selectedSubCategoryId == null,
                                    borderColor = ObsidianBorder,
                                    selectedBorderColor = ChampagneGold
                                )
                            )
                        }
                        items(ProductCategory.entries.filter { it != ProductCategory.CUSTOM }) { cat ->
                            val isSelected = selectedCategory == cat && selectedSubCategoryId == null
                            FilterChip(
                                selected = isSelected,
                                onClick = { onCategorySelected(cat, null) },
                                label = { Text(cat.displayName) },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = CharcoalElevated,
                                    labelColor = IvoryText,
                                    selectedContainerColor = EmeraldVelvet,
                                    selectedLabelColor = BrightGold
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    borderColor = ObsidianBorder,
                                    selectedBorderColor = ChampagneGold
                                )
                            )
                        }
                    }

                    // Specific sub-category chips (all 21+ categories)
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(allCategories.filter { it.enabled }.sortedBy { it.displayOrder }) { subCat ->
                            val isSelected = selectedSubCategoryId == subCat.id
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    onCategorySelected(
                                        null,
                                        if (isSelected) null else subCat.id
                                    )
                                },
                                label = { Text(subCat.name, style = MaterialTheme.typography.labelSmall) },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = OnyxSurface,
                                    labelColor = SageMuted,
                                    selectedContainerColor = EmeraldVelvet,
                                    selectedLabelColor = BrightGold
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = isSelected,
                                    borderColor = ObsidianBorder,
                                    selectedBorderColor = ChampagneGold
                                )
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${results.size} product(s)",
                            style = MaterialTheme.typography.bodySmall,
                            color = SageMuted
                        )

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(SortOption.entries) { option ->
                                val selected = sortOption == option
                                Surface(
                                    modifier = Modifier
                                        .clickable { onSortSelected(option) }
                                        .testTag("sort_${option.name.lowercase()}"),
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (selected) EmeraldVelvet else OnyxSurface,
                                    border = BorderStroke(
                                        1.dp,
                                        if (selected) ChampagneGold else ObsidianBorder
                                    )
                                ) {
                                    Text(
                                        text = option.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (selected) BrightGold else SageMuted,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            if (results.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(36.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.SearchOff,
                            contentDescription = null,
                            tint = ChampagneGold.copy(alpha = 0.7f),
                            modifier = Modifier.size(54.dp)
                        )
                        Text(
                            text = "No matching fragrances or essentials",
                            style = MaterialTheme.typography.titleLarge,
                            color = IvoryText,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Try searching for \"Khamrah\", \"Oud\", \"Janamaz\", or clear filters.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = SageMuted,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        GoldPrimaryButton(
                            text = "Reset Search & Filters",
                            onClick = {
                                onQueryChange("")
                                onCategorySelected(null, null)
                                onSortSelected(SortOption.FEATURED)
                            }
                        )
                    }
                }
            } else {
                items(resultRows) { rowProducts ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 7.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        rowProducts.forEach { product ->
                            LuxuryProductCard(
                                product = product,
                                isWishlisted = product.id in wishlistIds,
                                onCardClick = { onProductClick(product) },
                                onWishlistToggle = { onWishlistToggle(product) },
                                onAddToCart = { onAddToCart(product) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        repeat(columns - rowProducts.size) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}
