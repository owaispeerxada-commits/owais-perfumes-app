package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Luxury Palette: Matte Black, Imperial Emerald Green, Champagne Gold
val MatteBlack = Color(0xFF080A09)
val OnyxSurface = Color(0xFF101513)
val CharcoalElevated = Color(0xFF161E1B)
val ObsidianBorder = Color(0xFF26332D)

val EmeraldDeep = Color(0xFF0B271B)
val EmeraldVelvet = Color(0xFF0F3D2B)
val EmeraldAccent = Color(0xFF196144)
val EmeraldSoft = Color(0xFF2B7A5B)

val ChampagneGold = Color(0xFFD4AF37)
val BrightGold = Color(0xFFE9CB6A)
val AntiqueGold = Color(0xFF9E7E24)
val GoldWash = Color(0x26D4AF37)

val IvoryText = Color(0xFFF5F1E6)
val SageMuted = Color(0xFFA7B5AD)
val SubtleText = Color(0xFF7D8C84)
val ErrorRose = Color(0xFFCF6679)
