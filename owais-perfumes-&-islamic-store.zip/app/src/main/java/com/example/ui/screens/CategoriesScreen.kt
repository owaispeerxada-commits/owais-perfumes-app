package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.Product
import com.example.data.model.ProductCategory
import com.example.data.model.StoreCategory
import com.example.ui.components.IslamicGeometricDivider
import com.example.ui.components.productDrawableRes
import com.example.ui.theme.BrightGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldVelvet
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MatteBlack
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.OnyxSurface
import com.example.ui.theme.SageMuted

@Composable
fun CategoriesScreen(
    categories: List<StoreCategory>,
    products: List<Product>,
    onCategorySelected: (ProductCategory?, String?) -> Unit,
    onOpenSearch: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeCats = categories.filter { it.enabled }.sortedBy { it.displayOrder }
    val perfumeCats = activeCats.filter {
        it.groupType == ProductCategory.PERFUMES || it.groupType == ProductCategory.ATTARS
    }
    val islamicCats = activeCats.filter { it.groupType == ProductCategory.ISLAMIC_PRODUCTS }
    val customCats = activeCats.filter { it.groupType == ProductCategory.CUSTOM }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        val columns = if (maxWidth >= 600.dp) 3 else 2

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("categories_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Shop By Categories",
                            style = MaterialTheme.typography.headlineMedium,
                            color = IvoryText
                        )
                        Text(
                            text = "${activeCats.size} curated perfume, attar & Sunnah collections",
                            style = MaterialTheme.typography.bodySmall,
                            color = SageMuted
                        )
                    }
                    IconButton(
                        onClick = onOpenSearch,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("categories_search_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Search,
                            contentDescription = "Search products",
                            tint = BrightGold
                        )
                    }
                }
            }

            if (perfumeCats.isNotEmpty()) {
                item {
                    CategoryGroupHeader(
                        title = "Perfumes & Attars",
                        subtitle = "Arabic, Luxury, Oud, Khamrah, Wafa, Mask Oud, White Oud & Roll-ons",
                        onSeeAll = { onCategorySelected(ProductCategory.PERFUMES, null) }
                    )
                }
                items(perfumeCats.chunked(columns)) { rowCats ->
                    CategoryRowGrid(
                        rowCats = rowCats,
                        columns = columns,
                        products = products,
                        onClick = { cat -> onCategorySelected(null, cat.id) }
                    )
                }
            }

            if (islamicCats.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(6.dp))
                    IslamicGeometricDivider()
                    CategoryGroupHeader(
                        title = "Islamic Products",
                        subtitle = "Quran Pak, Books, Prayer Mats, Topi, Tasbeeh, Digital, Frames & Gifts",
                        onSeeAll = { onCategorySelected(ProductCategory.ISLAMIC_PRODUCTS, null) }
                    )
                }
                items(islamicCats.chunked(columns)) { rowCats ->
                    CategoryRowGrid(
                        rowCats = rowCats,
                        columns = columns,
                        products = products,
                        onClick = { cat -> onCategorySelected(null, cat.id) }
                    )
                }
            }

            if (customCats.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(6.dp))
                    IslamicGeometricDivider()
                    CategoryGroupHeader(
                        title = "Special Store Collections",
                        subtitle = "Curated by THE OWAIS OFFICIAL",
                        onSeeAll = { onCategorySelected(null, null) }
                    )
                }
                items(customCats.chunked(columns)) { rowCats ->
                    CategoryRowGrid(
                        rowCats = rowCats,
                        columns = columns,
                        products = products,
                        onClick = { cat -> onCategorySelected(null, cat.id) }
                    )
                }
            }
        }
    }
}

@Composable
private fun CategoryGroupHeader(
    title: String,
    subtitle: String,
    onSeeAll: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge,
                color = BrightGold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = SageMuted,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
        Surface(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .clickable(onClick = onSeeAll),
            color = EmeraldDeep,
            border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                text = "View All",
                style = MaterialTheme.typography.labelSmall,
                color = BrightGold,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )
        }
    }
}

@Composable
private fun CategoryRowGrid(
    rowCats: List<StoreCategory>,
    columns: Int,
    products: List<Product>,
    onClick: (StoreCategory) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        rowCats.forEach { cat ->
            val count = products.count { it.categoryId == cat.id }
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(112.dp)
                    .testTag("cat_tile_${cat.id}")
                    .clickable { onClick(cat) },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = OnyxSurface),
                border = BorderStroke(1.dp, ObsidianBorder)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = productDrawableRes(cat.drawableResName)),
                        contentDescription = cat.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(
                                        Color.Black.copy(alpha = 0.25f),
                                        MatteBlack.copy(alpha = 0.92f)
                                    )
                                )
                            )
                    )
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = cat.name,
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = IvoryText,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = if (count > 0) "$count item(s)" else cat.groupType.displayName,
                                style = MaterialTheme.typography.labelSmall,
                                color = ChampagneGold
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = EmeraldVelvet.copy(alpha = 0.9f)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                                contentDescription = "Open ${cat.name}",
                                tint = BrightGold,
                                modifier = Modifier
                                    .padding(4.dp)
                                    .size(16.dp)
                            )
                        }
                    }
                }
            }
        }
        repeat(columns - rowCats.size) {
            Spacer(modifier = Modifier.weight(1f))
        }
    }
}
