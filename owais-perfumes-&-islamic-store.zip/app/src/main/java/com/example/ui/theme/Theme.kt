package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val OwaisDarkColorScheme = darkColorScheme(
    primary = ChampagneGold,
    onPrimary = MatteBlack,
    primaryContainer = EmeraldVelvet,
    onPrimaryContainer = BrightGold,
    secondary = EmeraldAccent,
    onSecondary = IvoryText,
    secondaryContainer = EmeraldDeep,
    onSecondaryContainer = IvoryText,
    tertiary = BrightGold,
    onTertiary = MatteBlack,
    tertiaryContainer = GoldWash,
    onTertiaryContainer = BrightGold,
    background = MatteBlack,
    onBackground = IvoryText,
    surface = OnyxSurface,
    onSurface = IvoryText,
    surfaceVariant = CharcoalElevated,
    onSurfaceVariant = SageMuted,
    surfaceContainerLowest = MatteBlack,
    surfaceContainerLow = OnyxSurface,
    surfaceContainer = CharcoalElevated,
    surfaceContainerHigh = EmeraldDeep,
    outline = ObsidianBorder,
    outlineVariant = AntiqueGold,
    error = ErrorRose,
    onError = MatteBlack
)

val OwaisShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun OwaisLuxuryTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = OwaisDarkColorScheme,
        typography = OwaisTypography,
        shapes = OwaisShapes,
        content = content
    )
}
