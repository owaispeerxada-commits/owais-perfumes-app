package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.data.model.OrderStatus
import com.example.data.model.PaymentPreference
import com.example.data.model.PaymentStatus
import com.example.data.model.StoreOrder
import com.example.data.model.StoreSettingsConfig
import com.example.ui.components.EmeraldOutlinedButton
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.theme.BrightGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldVelvet
import com.example.ui.theme.ErrorRose
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MatteBlack
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.OnyxSurface
import com.example.ui.theme.SageMuted
import com.example.util.formatInr
import com.example.util.formatOrderDate
import com.example.util.openWhatsAppWithMessage

@Composable
fun OrdersScreen(
    orders: List<StoreOrder>,
    isSignedIn: Boolean,
    storeSettings: StoreSettingsConfig,
    onExploreClick: () -> Unit,
    onCancelOrder: (String) -> Unit,
    onSubmitUpiRef: (String, String) -> Unit,
    onNotify: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var utrDialogOrder by remember { mutableStateOf<StoreOrder?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MatteBlack),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (orders.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = EmeraldDeep.copy(alpha = 0.6f),
                    border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.4f)),
                    modifier = Modifier.size(84.dp)
                ) {
                    Icon(
                        imageVector = Icons.Outlined.ReceiptLong,
                        contentDescription = null,
                        tint = ChampagneGold,
                        modifier = Modifier
                            .padding(20.dp)
                            .fillMaxSize()
                    )
                }
                Spacer(modifier = Modifier.height(18.dp))
                Text(
                    text = "No Orders Placed Yet",
                    style = MaterialTheme.typography.headlineSmall,
                    color = IvoryText,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (isSignedIn) {
                        "Place an order from your shopping bag or Buy Now to track real-time fulfillment and payment verification."
                    } else {
                        "Browse in Guest mode or sign in with Google in Profile to track cloud orders in real time."
                    },
                    style = MaterialTheme.typography.bodyMedium,
                    color = SageMuted,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(20.dp))
                GoldPrimaryButton(
                    text = "Start Shopping",
                    onClick = onExploreClick,
                    modifier = Modifier.testTag("empty_orders_explore_button")
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "My Orders",
                            style = MaterialTheme.typography.headlineMedium,
                            color = IvoryText
                        )
                        Text(
                            text = if (isSignedIn) {
                                "Live order tracking · Support: ${storeSettings.whatsappNumber}"
                            } else {
                                "Guest order history stored locally on device"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = SageMuted
                        )
                    }
                }

                items(orders, key = { it.id }) { order ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = OnyxSurface),
                        border = BorderStroke(1.dp, ObsidianBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Order ${order.orderNumber}",
                                        style = MaterialTheme.typography.titleLarge,
                                        color = BrightGold
                                    )
                                    Text(
                                        text = formatOrderDate(order.createdAtMillis),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SageMuted
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(50),
                                    color = if (order.orderStatus == OrderStatus.CANCELLED) ErrorRose.copy(alpha = 0.18f) else EmeraldVelvet,
                                    border = BorderStroke(
                                        1.dp,
                                        if (order.orderStatus == OrderStatus.CANCELLED) ErrorRose else ChampagneGold.copy(alpha = 0.6f)
                                    )
                                ) {
                                    Text(
                                        text = order.orderStatus.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (order.orderStatus == OrderStatus.CANCELLED) ErrorRose else BrightGold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                                    )
                                }
                            }

                            if (order.orderStatus != OrderStatus.CANCELLED) {
                                OrderTrackingTimeline(currentStatus = order.orderStatus)
                            }

                            HorizontalDivider(color = ObsidianBorder)

                            Text(
                                text = order.itemsSummary,
                                style = MaterialTheme.typography.bodyMedium,
                                color = IvoryText
                            )

                            Text(
                                text = "Deliver to: ${order.customerName} · ${order.deliveryAddress}",
                                style = MaterialTheme.typography.bodySmall,
                                color = SageMuted
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Payment: ${order.paymentPreference.code} (${order.paymentStatus.label})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = ChampagneGold
                                )
                                if (order.upiTransactionRef.isNotBlank()) {
                                    Text(
                                        text = "UTR: ${order.upiTransactionRef}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = IvoryText
                                    )
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "${order.itemCount} item(s)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SageMuted
                                    )
                                    Text(
                                        text = formatInr(order.totalAmountInr),
                                        style = MaterialTheme.typography.titleLarge.copy(
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = BrightGold
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    if (isSignedIn && order.orderStatus == OrderStatus.PENDING) {
                                        TextButton(onClick = { onCancelOrder(order.id) }) {
                                            Text("Cancel", color = ErrorRose)
                                        }
                                    }
                                    if (isSignedIn &&
                                        order.paymentPreference == PaymentPreference.UPI &&
                                        order.paymentStatus != PaymentStatus.VERIFIED &&
                                        order.orderStatus != OrderStatus.CANCELLED
                                    ) {
                                        TextButton(onClick = { utrDialogOrder = order }) {
                                            Text("Submit UTR", color = ChampagneGold)
                                        }
                                    }
                                    EmeraldOutlinedButton(
                                        text = "WhatsApp",
                                        onClick = {
                                            if (!openWhatsAppWithMessage(context, order.whatsappMessage, storeSettings.whatsappDigits)) {
                                                onNotify("WhatsApp unavailable — order summary copied to clipboard")
                                            }
                                        },
                                        leadingIcon = {
                                            Icon(
                                                imageVector = Icons.Outlined.Chat,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    val targetOrder = utrDialogOrder
    if (targetOrder != null) {
        var utrInput by remember(targetOrder.id) { mutableStateOf(targetOrder.upiTransactionRef) }
        AlertDialog(
            onDismissRequest = { utrDialogOrder = null },
            containerColor = OnyxSurface,
            titleContentColor = IvoryText,
            textContentColor = IvoryText,
            title = { Text("Submit UPI Reference") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "UPI ID: ${storeSettings.upiId} · Amount: ${formatInr(targetOrder.totalAmountInr)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = ChampagneGold
                    )
                    OutlinedTextField(
                        value = utrInput,
                        onValueChange = { utrInput = it },
                        label = { Text("12-digit UTR / Ref ID") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ChampagneGold,
                            unfocusedBorderColor = ObsidianBorder,
                            focusedTextColor = IvoryText,
                            unfocusedTextColor = IvoryText
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                GoldPrimaryButton(
                    text = "Submit Ref",
                    enabled = utrInput.trim().length >= 4,
                    onClick = {
                        onSubmitUpiRef(targetOrder.id, utrInput.trim())
                        utrDialogOrder = null
                    }
                )
            },
            dismissButton = {
                TextButton(onClick = { utrDialogOrder = null }) {
                    Text("Close", color = SageMuted)
                }
            }
        )
    }
}

@Composable
private fun OrderTrackingTimeline(currentStatus: OrderStatus) {
    val stages = listOf(
        OrderStatus.PENDING,
        OrderStatus.CONFIRMED,
        OrderStatus.PROCESSING,
        OrderStatus.SHIPPED,
        OrderStatus.DELIVERED
    )
    val currentIndex = stages.indexOf(currentStatus).coerceAtLeast(0)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        stages.forEachIndexed { idx, stage ->
            val reached = idx <= currentIndex
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(if (reached) ChampagneGold else ObsidianBorder)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = stage.label,
                    style = MaterialTheme.typography.labelSmall,
                    color = if (reached) BrightGold else SageMuted,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
            }
        }
    }
}
