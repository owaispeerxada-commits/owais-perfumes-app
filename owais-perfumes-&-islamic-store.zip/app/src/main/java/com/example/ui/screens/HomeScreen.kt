package com.example.ui.screens

import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.Storefront
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.Product
import com.example.data.model.ProductCategory
import com.example.data.model.StoreBanner
import com.example.data.model.StoreConstants
import com.example.data.model.StoreSettingsConfig
import com.example.ui.components.DemoCatalogNoticeBanner
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.components.IslamicGeometricDivider
import com.example.ui.components.LuxuryProductCard
import com.example.ui.components.OwaisBrandLogo
import com.example.ui.components.ProductMediaImage
import com.example.ui.components.WhatsAppOrderButton
import com.example.ui.theme.BrightGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldVelvet
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MatteBlack
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.OnyxSurface
import com.example.ui.theme.SageMuted
import com.example.util.openInstagramProfile
import com.example.util.openStoreInMaps
import com.example.util.openWhatsAppConcierge

@Composable
fun HomeScreen(
    allProducts: List<Product>,
    filteredProducts: List<Product>,
    banners: List<StoreBanner>,
    storeSettings: StoreSettingsConfig,
    isSignedIn: Boolean,
    userEmail: String?,
    selectedCategory: ProductCategory?,
    wishlistIds: Set<String>,
    cartCount: Int,
    onCategorySelected: (ProductCategory?) -> Unit,
    onProductClick: (Product) -> Unit,
    onWishlistToggle: (Product) -> Unit,
    onAddToCart: (Product) -> Unit,
    onOpenSearch: (ProductCategory?, String?) -> Unit,
    onOpenCart: () -> Unit,
    onNotify: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val perfumesList = allProducts.filter { it.category == ProductCategory.PERFUMES }
    val attarsList = allProducts.filter { it.category == ProductCategory.ATTARS }
    val islamicList = allProducts.filter { it.category == ProductCategory.ISLAMIC_PRODUCTS }
    val featuredList = allProducts.filter { it.isFeatured }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(MatteBlack)
    ) {
        val columns = if (maxWidth >= 600.dp) 3 else 2

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .testTag("home_feed"),
            contentPadding = PaddingValues(bottom = 28.dp)
        ) {
            item {
                HomeTopHeader(
                    cartCount = cartCount,
                    storeLocation = storeSettings.location,
                    onSearchClick = { onOpenSearch(selectedCategory, null) },
                    onCartClick = onOpenCart
                )
            }

            item {
                HeroBannerPager(
                    banners = banners.ifEmpty {
                        listOf(
                            StoreBanner(
                                id = "default",
                                title = storeSettings.storeName,
                                subtitle = storeSettings.tagline,
                                badgeText = storeSettings.brandOfficial,
                                ctaText = "Shop Collection"
                            )
                        )
                    },
                    storeLocation = storeSettings.location,
                    onBannerAction = { banner ->
                        if (banner.targetCategory.isNotBlank()) {
                            onOpenSearch(null, banner.targetCategory)
                        } else {
                            onOpenSearch(null, null)
                        }
                    },
                    onWhatsAppClick = {
                        if (!openWhatsAppConcierge(context, storeSettings.whatsappDigits)) {
                            onNotify("WhatsApp unavailable — greeting copied (${storeSettings.whatsappNumber})")
                        }
                    },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }

            item {
                DemoCatalogNoticeBanner(
                    isSignedIn = isSignedIn,
                    userEmail = userEmail,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }

            item {
                Column(modifier = Modifier.padding(top = 12.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Shop By Categories",
                            style = MaterialTheme.typography.headlineSmall,
                            color = IvoryText
                        )
                        Text(
                            text = "Search All",
                            style = MaterialTheme.typography.labelMedium,
                            color = ChampagneGold,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onOpenSearch(null, null) }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                                .testTag("home_view_all_button")
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            CategoryShowcaseCard(
                                title = "Perfumes",
                                subtitle = "${perfumesList.size} Luxury EDPs",
                                imageRes = R.drawable.img_category_perfumes,
                                isSelected = selectedCategory == ProductCategory.PERFUMES,
                                onClick = {
                                    onCategorySelected(
                                        if (selectedCategory == ProductCategory.PERFUMES) null
                                        else ProductCategory.PERFUMES
                                    )
                                },
                                testTag = "category_card_perfumes"
                            )
                        }
                        item {
                            CategoryShowcaseCard(
                                title = "Attars",
                                subtitle = "${attarsList.size} Pure Concentrates",
                                imageRes = R.drawable.img_featured_oud,
                                isSelected = selectedCategory == ProductCategory.ATTARS,
                                onClick = {
                                    onCategorySelected(
                                        if (selectedCategory == ProductCategory.ATTARS) null
                                        else ProductCategory.ATTARS
                                    )
                                },
                                testTag = "category_card_attars"
                            )
                        }
                        item {
                            CategoryShowcaseCard(
                                title = "Islamic Products",
                                subtitle = "${islamicList.size} Sunnah Essentials",
                                imageRes = R.drawable.img_category_islamic,
                                isSelected = selectedCategory == ProductCategory.ISLAMIC_PRODUCTS,
                                onClick = {
                                    onCategorySelected(
                                        if (selectedCategory == ProductCategory.ISLAMIC_PRODUCTS) null
                                        else ProductCategory.ISLAMIC_PRODUCTS
                                    )
                                },
                                testTag = "category_card_islamic"
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        item {
                            CategoryFilterPill(
                                label = "All Sections (${allProducts.size})",
                                selected = selectedCategory == null,
                                onClick = { onCategorySelected(null) },
                                tag = "filter_chip_all"
                            )
                        }
                        items(ProductCategory.entries.filter { it != ProductCategory.CUSTOM }) { cat ->
                            CategoryFilterPill(
                                label = cat.displayName,
                                selected = selectedCategory == cat,
                                onClick = { onCategorySelected(cat) },
                                tag = "filter_chip_${cat.name.lowercase()}"
                            )
                        }
                    }
                }
            }

            if (selectedCategory == null) {
                if (featuredList.isNotEmpty()) {
                    item {
                        Column(modifier = Modifier.padding(top = 18.dp)) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Featured Curations",
                                    style = MaterialTheme.typography.headlineSmall,
                                    color = BrightGold
                                )
                                Text(
                                    text = "${featuredList.size} signature picks",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SageMuted
                                )
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            LazyRow(
                                contentPadding = PaddingValues(horizontal = 16.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(featuredList, key = { "feat_${it.id}" }) { product ->
                                    LuxuryProductCard(
                                        product = product,
                                        isWishlisted = product.id in wishlistIds,
                                        onCardClick = { onProductClick(product) },
                                        onWishlistToggle = { onWishlistToggle(product) },
                                        onAddToCart = { onAddToCart(product) },
                                        modifier = Modifier.width(188.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                categorySection(
                    title = "Perfumes",
                    subtitle = ProductCategory.PERFUMES.subtitle,
                    sectionProducts = perfumesList,
                    columns = columns,
                    wishlistIds = wishlistIds,
                    onSeeAll = { onOpenSearch(ProductCategory.PERFUMES, null) },
                    onProductClick = onProductClick,
                    onWishlistToggle = onWishlistToggle,
                    onAddToCart = onAddToCart
                )

                categorySection(
                    title = "Attars",
                    subtitle = ProductCategory.ATTARS.subtitle,
                    sectionProducts = attarsList,
                    columns = columns,
                    wishlistIds = wishlistIds,
                    onSeeAll = { onOpenSearch(ProductCategory.ATTARS, null) },
                    onProductClick = onProductClick,
                    onWishlistToggle = onWishlistToggle,
                    onAddToCart = onAddToCart
                )

                categorySection(
                    title = "Islamic Products",
                    subtitle = ProductCategory.ISLAMIC_PRODUCTS.subtitle,
                    sectionProducts = islamicList,
                    columns = columns,
                    wishlistIds = wishlistIds,
                    onSeeAll = { onOpenSearch(ProductCategory.ISLAMIC_PRODUCTS, null) },
                    onProductClick = onProductClick,
                    onWishlistToggle = onWishlistToggle,
                    onAddToCart = onAddToCart
                )
            } else {
                categorySection(
                    title = selectedCategory.displayName,
                    subtitle = selectedCategory.subtitle,
                    sectionProducts = filteredProducts,
                    columns = columns,
                    wishlistIds = wishlistIds,
                    onSeeAll = { onOpenSearch(selectedCategory, null) },
                    onProductClick = onProductClick,
                    onWishlistToggle = onWishlistToggle,
                    onAddToCart = onAddToCart
                )
            }

            item {
                AboutUsSectionCard(
                    storeSettings = storeSettings,
                    onWhatsAppClick = {
                        if (!openWhatsAppConcierge(context, storeSettings.whatsappDigits)) {
                            onNotify("WhatsApp unavailable — greeting copied (${storeSettings.whatsappNumber})")
                        }
                    },
                    onInstagramClick = {
                        if (!openInstagramProfile(context, storeSettings.instagramUrl, storeSettings.instagramHandle)) {
                            onNotify("Browser unavailable — ${storeSettings.instagramHandle} copied")
                        }
                    },
                    onLocationClick = {
                        if (!openStoreInMaps(context, storeSettings.location)) {
                            onNotify("Maps unavailable — ${storeSettings.location} copied")
                        }
                    },
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 20.dp)
                )
            }
        }
    }
}

private fun LazyListScope.categorySection(
    title: String,
    subtitle: String,
    sectionProducts: List<Product>,
    columns: Int,
    wishlistIds: Set<String>,
    onSeeAll: () -> Unit,
    onProductClick: (Product) -> Unit,
    onWishlistToggle: (Product) -> Unit,
    onAddToCart: (Product) -> Unit
) {
    if (sectionProducts.isEmpty()) return

    item {
        Column(modifier = Modifier.padding(top = 20.dp, bottom = 6.dp)) {
            IslamicGeometricDivider(
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 2.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.headlineSmall,
                        color = BrightGold
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = SageMuted,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Text(
                    text = "See all",
                    style = MaterialTheme.typography.labelMedium,
                    color = ChampagneGold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onSeeAll)
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                )
            }
        }
    }

    val rows = sectionProducts.chunked(columns)
    items(rows) { rowProducts ->
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 7.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            rowProducts.forEach { product ->
                LuxuryProductCard(
                    product = product,
                    isWishlisted = product.id in wishlistIds,
                    onCardClick = { onProductClick(product) },
                    onWishlistToggle = { onWishlistToggle(product) },
                    onAddToCart = { onAddToCart(product) },
                    modifier = Modifier.weight(1f)
                )
            }
            repeat(columns - rowProducts.size) {
                Spacer(modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun HomeTopHeader(
    cartCount: Int,
    storeLocation: String,
    onSearchClick: () -> Unit,
    onCartClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                Brush.verticalGradient(
                    colors = listOf(EmeraldDeep.copy(alpha = 0.9f), MatteBlack)
                )
            )
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            OwaisBrandLogo(
                emblemSize = 48.dp,
                showFullText = true,
                modifier = Modifier.weight(1f)
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onSearchClick,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("home_search_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = "Search products",
                        tint = IvoryText
                    )
                }

                IconButton(
                    onClick = onCartClick,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("home_cart_button")
                ) {
                    BadgedBox(
                        badge = {
                            if (cartCount > 0) {
                                Badge(
                                    containerColor = ChampagneGold,
                                    contentColor = MatteBlack
                                ) {
                                    Text(cartCount.toString())
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Filled.ShoppingBag,
                            contentDescription = "Shopping cart",
                            tint = BrightGold
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${StoreConstants.GREETING} · Welcome",
                style = MaterialTheme.typography.labelLarge,
                color = ChampagneGold
            )
            Text(
                text = storeLocation,
                style = MaterialTheme.typography.labelSmall,
                color = SageMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun HeroBannerPager(
    banners: List<StoreBanner>,
    storeLocation: String,
    onBannerAction: (StoreBanner) -> Unit,
    onWhatsAppClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pagerState = rememberPagerState(pageCount = { banners.size })

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        HorizontalPager(state = pagerState, modifier = Modifier.fillMaxWidth()) { page ->
            val banner = banners[page]
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(238.dp),
                shape = RoundedCornerShape(22.dp),
                border = BorderStroke(1.3.dp, ChampagneGold.copy(alpha = 0.7f)),
                colors = CardDefaults.cardColors(containerColor = OnyxSurface)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    ProductMediaImage(
                        imageUrl = banner.imageUrl,
                        fallbackDrawableName = banner.drawableResName,
                        contentDescription = banner.title,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        MatteBlack.copy(alpha = 0.94f),
                                        EmeraldDeep.copy(alpha = 0.76f),
                                        Color.Black.copy(alpha = 0.25f)
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(18.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = MatteBlack.copy(alpha = 0.8f),
                            border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.75f))
                        ) {
                            Text(
                                text = banner.badgeText.ifBlank { StoreConstants.BRAND_OFFICIAL },
                                style = MaterialTheme.typography.labelSmall,
                                color = BrightGold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                            )
                        }

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = banner.title,
                                style = MaterialTheme.typography.headlineMedium,
                                color = IvoryText,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = banner.subtitle,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                color = BrightGold,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = storeLocation,
                                style = MaterialTheme.typography.labelSmall,
                                color = SageMuted
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            GoldPrimaryButton(
                                text = banner.ctaText.ifBlank { "Shop Collection" },
                                onClick = { onBannerAction(banner) },
                                modifier = Modifier.testTag("hero_explore_button"),
                                leadingIcon = {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            )
                            WhatsAppOrderButton(
                                text = "WhatsApp",
                                onClick = onWhatsAppClick,
                                modifier = Modifier.testTag("hero_whatsapp_button")
                            )
                        }
                    }
                }
            }
        }

        if (banners.size > 1) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                repeat(banners.size) { index ->
                    val selected = pagerState.currentPage == index
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 3.dp)
                            .size(width = if (selected) 18.dp else 6.dp, height = 6.dp)
                            .clip(CircleShape)
                            .background(if (selected) ChampagneGold else ObsidianBorder)
                    )
                }
            }
        }
    }
}

@Composable
private fun CategoryShowcaseCard(
    title: String,
    subtitle: String,
    @DrawableRes imageRes: Int,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier
            .width(176.dp)
            .height(122.dp)
            .testTag(testTag)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) ChampagneGold else ObsidianBorder
        )
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(id = imageRes),
                contentDescription = title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.15f),
                                MatteBlack.copy(alpha = 0.9f)
                            )
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(12.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleLarge,
                    color = if (isSelected) BrightGold else IvoryText
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = SageMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun CategoryFilterPill(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = {
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium
            )
        },
        modifier = Modifier
            .minimumInteractiveComponentSize()
            .testTag(tag),
        shape = RoundedCornerShape(50),
        colors = FilterChipDefaults.filterChipColors(
            containerColor = CharcoalElevated,
            labelColor = IvoryText,
            selectedContainerColor = EmeraldVelvet,
            selectedLabelColor = BrightGold
        ),
        border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = selected,
            borderColor = ObsidianBorder,
            selectedBorderColor = ChampagneGold
        )
    )
}

@Composable
private fun AboutUsSectionCard(
    storeSettings: StoreSettingsConfig,
    onWhatsAppClick: () -> Unit,
    onInstagramClick: () -> Unit,
    onLocationClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("about_us_section"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = EmeraldDeep.copy(alpha = 0.72f)),
        border = BorderStroke(1.2.dp, ChampagneGold.copy(alpha = 0.55f))
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Storefront,
                    contentDescription = null,
                    tint = ChampagneGold,
                    modifier = Modifier.size(20.dp)
                )
                Text(
                    text = "About Us",
                    style = MaterialTheme.typography.headlineSmall,
                    color = BrightGold
                )
            }

            OwaisBrandLogo(emblemSize = 52.dp, showFullText = true)

            Text(
                text = storeSettings.tagline,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                color = ChampagneGold
            )

            Text(
                text = storeSettings.aboutStory,
                style = MaterialTheme.typography.bodySmall,
                color = IvoryText.copy(alpha = 0.9f)
            )

            HorizontalDivider(color = ObsidianBorder)

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MatteBlack.copy(alpha = 0.5f))
                    .clickable(onClick = onLocationClick)
                    .padding(12.dp)
                    .testTag("about_location_button"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.LocationOn,
                    contentDescription = "Store Location",
                    tint = ChampagneGold
                )
                Column {
                    Text(
                        text = "Store Location",
                        style = MaterialTheme.typography.labelSmall,
                        color = SageMuted
                    )
                    Text(
                        text = storeSettings.location,
                        style = MaterialTheme.typography.bodyMedium,
                        color = IvoryText
                    )
                }
            }

            WhatsAppOrderButton(
                text = "Order on WhatsApp · ${storeSettings.whatsappNumber}",
                onClick = onWhatsAppClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("about_whatsapp_button")
            )

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable(onClick = onInstagramClick)
                    .testTag("about_instagram_button"),
                shape = RoundedCornerShape(14.dp),
                color = CharcoalElevated,
                border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.55f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Outlined.PhotoCamera,
                        contentDescription = null,
                        tint = BrightGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Follow Instagram ${storeSettings.instagramHandle}",
                        style = MaterialTheme.typography.labelLarge,
                        color = IvoryText
                    )
                }
            }
        }
    }
}
