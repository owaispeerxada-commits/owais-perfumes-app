package com.example.ui.components

import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddShoppingCart
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.Product
import com.example.data.model.StoreConstants
import com.example.ui.theme.BrightGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldVelvet
import com.example.ui.theme.ErrorRose
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MatteBlack
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.OnyxSurface
import com.example.ui.theme.SageMuted
import com.example.util.formatInr
import kotlin.math.cos
import kotlin.math.sin

@DrawableRes
fun productDrawableRes(name: String): Int = when (name) {
    "img_hero_banner" -> R.drawable.img_hero_banner
    "img_category_perfumes" -> R.drawable.img_category_perfumes
    "img_category_islamic" -> R.drawable.img_category_islamic
    "img_featured_oud" -> R.drawable.img_featured_oud
    else -> R.drawable.owais_logo_icon
}

@Composable
fun ProductMediaImage(
    imageUrl: String?,
    fallbackDrawableName: String,
    contentDescription: String,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop
) {
    if (!imageUrl.isNullOrBlank()) {
        AsyncImage(
            model = imageUrl,
            contentDescription = contentDescription,
            placeholder = painterResource(id = productDrawableRes(fallbackDrawableName)),
            error = painterResource(id = productDrawableRes(fallbackDrawableName)),
            contentScale = contentScale,
            modifier = modifier
        )
    } else {
        Image(
            painter = painterResource(id = productDrawableRes(fallbackDrawableName)),
            contentDescription = contentDescription,
            contentScale = contentScale,
            modifier = modifier
        )
    }
}

@Composable
fun OwaisBrandLogo(
    modifier: Modifier = Modifier,
    emblemSize: Dp = 54.dp,
    showFullText: Boolean = true
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(emblemSize)
                .clip(CircleShape)
                .background(EmeraldDeep)
                .border(1.8.dp, ChampagneGold, CircleShape)
                .padding(2.dp),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.owais_logo_icon),
                contentDescription = "OWAIS PERFUMES & ISLAMIC STORE Logo",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxSize()
                    .clip(CircleShape)
                    .border(0.8.dp, BrightGold.copy(alpha = 0.5f), CircleShape)
            )
        }

        if (showFullText) {
            Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
                Text(
                    text = StoreConstants.BRAND_OFFICIAL,
                    style = MaterialTheme.typography.labelSmall.copy(
                        letterSpacing = 1.6.sp
                    ),
                    color = ChampagneGold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "OWAIS PERFUMES",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    color = IvoryText,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "& ISLAMIC STORE",
                    style = MaterialTheme.typography.labelMedium.copy(
                        letterSpacing = 1.2.sp
                    ),
                    color = BrightGold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun IslamicGeometricDivider(
    modifier: Modifier = Modifier,
    color: Color = ChampagneGold.copy(alpha = 0.55f)
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(20.dp)
    ) {
        val midY = size.height / 2f
        val midX = size.width / 2f
        val starRadius = 6.dp.toPx()

        drawLine(
            brush = Brush.horizontalGradient(
                colors = listOf(Color.Transparent, color),
                startX = 0f,
                endX = midX - starRadius * 2f
            ),
            start = Offset(0f, midY),
            end = Offset(midX - starRadius * 2f, midY),
            strokeWidth = 1.dp.toPx()
        )

        drawLine(
            brush = Brush.horizontalGradient(
                colors = listOf(color, Color.Transparent),
                startX = midX + starRadius * 2f,
                endX = size.width
            ),
            start = Offset(midX + starRadius * 2f, midY),
            end = Offset(size.width, midY),
            strokeWidth = 1.dp.toPx()
        )

        val path = Path()
        val points = 8
        for (i in 0 until points * 2) {
            val r = if (i % 2 == 0) starRadius else starRadius * 0.45f
            val angle = (i * Math.PI / points) - Math.PI / 2
            val x = midX + (r * cos(angle)).toFloat()
            val y = midY + (r * sin(angle)).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        drawPath(path = path, color = color, style = Stroke(width = 1.2.dp.toPx()))
    }
}

@Composable
fun DemoCatalogNoticeBanner(
    isSignedIn: Boolean = false,
    userEmail: String? = null,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = EmeraldDeep.copy(alpha = 0.85f),
        border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Outlined.Verified,
                contentDescription = "Store status information",
                tint = ChampagneGold,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = if (isSignedIn) {
                    "Cloud Sync Active (${userEmail ?: "Google Account"}) · Orders & saved addresses backed by Firebase."
                } else {
                    StoreConstants.DEMO_NOTICE
                },
                style = MaterialTheme.typography.bodySmall,
                color = IvoryText.copy(alpha = 0.9f)
            )
        }
    }
}

@Composable
fun LuxuryProductCard(
    product: Product,
    isWishlisted: Boolean,
    onCardClick: () -> Unit,
    onWishlistToggle: () -> Unit,
    onAddToCart: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("product_card_${product.id}")
            .clickable(onClick = onCardClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = OnyxSurface
        ),
        border = BorderStroke(1.dp, ObsidianBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1.1f)
                    .background(MatteBlack)
            ) {
                ProductMediaImage(
                    imageUrl = product.imageUrls.firstOrNull(),
                    fallbackDrawableName = product.drawableResName,
                    contentDescription = product.name,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Black.copy(alpha = 0.32f),
                                    Color.Transparent,
                                    MatteBlack.copy(alpha = 0.78f)
                                )
                            )
                        )
                )

                Surface(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp),
                    shape = RoundedCornerShape(8.dp),
                    color = MatteBlack.copy(alpha = 0.85f),
                    border = BorderStroke(
                        0.8.dp,
                        if (product.isOutOfStock) ErrorRose else ChampagneGold.copy(alpha = 0.8f)
                    )
                ) {
                    Text(
                        text = if (product.isOutOfStock) "OUT OF STOCK" else product.badge,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (product.isOutOfStock) ErrorRose else BrightGold,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                    )
                }

                IconButton(
                    onClick = onWishlistToggle,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .minimumInteractiveComponentSize()
                        .testTag("wishlist_toggle_${product.id}")
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(MatteBlack.copy(alpha = 0.7f))
                            .border(0.8.dp, ChampagneGold.copy(alpha = 0.45f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isWishlisted) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                            contentDescription = if (isWishlisted) "Remove from wishlist" else "Save to wishlist",
                            tint = if (isWishlisted) ChampagneGold else IvoryText,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = EmeraldVelvet.copy(alpha = 0.92f),
                        border = BorderStroke(0.6.dp, ChampagneGold.copy(alpha = 0.4f))
                    ) {
                        Text(
                            text = product.categoryName.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = IvoryText,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MatteBlack.copy(alpha = 0.8f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(3.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Star,
                                contentDescription = null,
                                tint = ChampagneGold,
                                modifier = Modifier.size(12.dp)
                            )
                            Text(
                                text = product.rating.toString(),
                                style = MaterialTheme.typography.labelSmall,
                                color = IvoryText
                            )
                        }
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = product.name,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    color = IvoryText,
                    maxLines = 2,
                    minLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = product.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = SageMuted,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Text(
                    text = "${product.variants.first().label} · ${if (product.isLowStock) "Only ${product.stockCount} left" else "${product.reviewCount} reviews"}",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (product.isLowStock) ErrorRose else ChampagneGold.copy(alpha = 0.85f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = formatInr(product.priceInr),
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = BrightGold
                        )
                        if (product.originalPriceInr != null && product.originalPriceInr > product.priceInr) {
                            Text(
                                text = formatInr(product.originalPriceInr),
                                style = MaterialTheme.typography.bodySmall.copy(
                                    textDecoration = TextDecoration.LineThrough
                                ),
                                color = SageMuted.copy(alpha = 0.7f)
                            )
                        }
                    }

                    Button(
                        onClick = onAddToCart,
                        enabled = !product.isOutOfStock,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldVelvet,
                            contentColor = BrightGold,
                            disabledContainerColor = CharcoalElevated,
                            disabledContentColor = SageMuted
                        ),
                        border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.65f)),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("add_to_cart_${product.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AddShoppingCart,
                            contentDescription = "Add ${product.name} to bag",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (product.isOutOfStock) "Sold" else "Add",
                            style = MaterialTheme.typography.labelMedium
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun GoldPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingIcon: (@Composable () -> Unit)? = null
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.minimumInteractiveComponentSize(),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = ChampagneGold,
            contentColor = MatteBlack,
            disabledContainerColor = CharcoalElevated,
            disabledContentColor = SageMuted
        ),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)
    ) {
        if (leadingIcon != null) {
            leadingIcon()
            Spacer(modifier = Modifier.width(8.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
        )
    }
}

@Composable
fun WhatsAppOrderButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        modifier = modifier.minimumInteractiveComponentSize(),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = EmeraldVelvet,
            contentColor = BrightGold
        ),
        border = BorderStroke(1.5.dp, ChampagneGold),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp)
    ) {
        Icon(
            imageVector = Icons.Outlined.Chat,
            contentDescription = null,
            tint = ChampagneGold,
            modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
            color = IvoryText
        )
    }
}

@Composable
fun EmeraldOutlinedButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    leadingIcon: (@Composable () -> Unit)? = null
) {
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.minimumInteractiveComponentSize(),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = EmeraldDeep.copy(alpha = 0.5f),
            contentColor = BrightGold,
            disabledContentColor = SageMuted
        ),
        border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.65f)),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 13.dp)
    ) {
        if (leadingIcon != null) {
            leadingIcon()
            Spacer(modifier = Modifier.width(8.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge
        )
    }
}
