package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.outlined.AddLocationAlt
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Gavel
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.LocalShipping
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material.icons.outlined.PhotoCamera
import androidx.compose.material.icons.outlined.Policy
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.SupportAgent
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.auth.GoogleSignInButton
import com.example.data.local.CustomerProfileEntity
import com.example.data.model.DeliveryAddress
import com.example.data.model.StoreConstants
import com.example.data.model.StoreSettingsConfig
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.components.IslamicGeometricDivider
import com.example.ui.components.OwaisBrandLogo
import com.example.ui.components.WhatsAppOrderButton
import com.example.ui.theme.BrightGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldVelvet
import com.example.ui.theme.ErrorRose
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MatteBlack
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.OnyxSurface
import com.example.ui.theme.SageMuted
import com.example.util.openInstagramProfile
import com.example.util.openStoreInMaps
import com.example.util.openWhatsAppConcierge
import com.google.firebase.auth.FirebaseUser

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    currentUser: FirebaseUser?,
    isAdmin: Boolean,
    profile: CustomerProfileEntity,
    savedAddresses: List<DeliveryAddress>,
    storeSettings: StoreSettingsConfig,
    ordersCount: Int,
    wishlistCount: Int,
    onSignedIn: (FirebaseUser) -> Unit,
    onSignOut: () -> Unit,
    onOpenAdminDashboard: () -> Unit,
    onSaveProfile: (String, String, String, String, String, String) -> Unit,
    onSaveAddress: (DeliveryAddress) -> Unit,
    onDeleteAddress: (String) -> Unit,
    onOpenOrders: () -> Unit,
    onOpenWishlist: () -> Unit,
    onOpenLegalTopic: (LegalInfoTopic) -> Unit,
    onNotify: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    var fullName by remember { mutableStateOf(profile.fullName) }
    var phone by remember { mutableStateOf(profile.phoneNumber) }
    var address by remember { mutableStateOf(profile.addressLine) }
    var city by remember { mutableStateOf(profile.city) }
    var pincode by remember { mutableStateOf(profile.pincode) }
    var preferredScent by remember { mutableStateOf(profile.preferredScent) }
    var showAddAddressDialog by remember { mutableStateOf(false) }

    LaunchedEffect(profile) {
        fullName = profile.fullName
        phone = profile.phoneNumber
        address = profile.addressLine
        city = profile.city
        pincode = profile.pincode
        preferredScent = profile.preferredScent
    }

    val scentOptions = listOf("Oud & Saffron", "White Musk", "Floral Rose", "Warm Amber")

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MatteBlack),
        contentPadding = PaddingValues(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Official Brand Crest & Google Auth Card
        item {
            Card(
                modifier = Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = EmeraldDeep.copy(alpha = 0.72f)),
                border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.55f))
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OwaisBrandLogo(emblemSize = 54.dp, showFullText = true)
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = "${StoreConstants.GREETING}, ${currentUser?.displayName ?: fullName.ifBlank { "Guest Patron" }}",
                            style = MaterialTheme.typography.titleLarge,
                            color = IvoryText
                        )
                        Text(
                            text = if (currentUser != null) {
                                "Signed in as ${currentUser.email}"
                            } else {
                                "Browsing as Guest · Sign in with Google for cloud order sync"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = ChampagneGold
                        )
                    }

                    if (currentUser == null) {
                        GoogleSignInButton(
                            onSuccess = onSignedIn,
                            onError = onNotify
                        )
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = EmeraldVelvet,
                                border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.5f)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.VerifiedUser,
                                        contentDescription = null,
                                        tint = BrightGold,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = if (isAdmin) "Store Admin Account" else "Verified Customer",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = BrightGold
                                    )
                                }
                            }

                            OutlinedButton(
                                onClick = onSignOut,
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, ObsidianBorder),
                                modifier = Modifier.testTag("sign_out_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Outlined.Logout,
                                    contentDescription = "Sign Out",
                                    tint = IvoryText,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Admin-only Dashboard Entry Card
        if (isAdmin) {
            item {
                Card(
                    modifier = Modifier
                        .widthIn(max = 680.dp)
                        .fillMaxWidth()
                        .testTag("open_admin_dashboard_card")
                        .clickable(onClick = onOpenAdminDashboard),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = EmeraldVelvet),
                    border = BorderStroke(1.5.dp, ChampagneGold)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.AdminPanelSettings,
                                contentDescription = null,
                                tint = BrightGold,
                                modifier = Modifier.size(30.dp)
                            )
                            Column {
                                Text(
                                    text = "Admin Store Dashboard",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = BrightGold
                                )
                                Text(
                                    text = "Products, Categories, Orders, Analytics & Store Settings",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = IvoryText
                                )
                            }
                        }
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                            contentDescription = "Open Admin Dashboard",
                            tint = BrightGold
                        )
                    }
                }
            }
        }

        // 2. Quick Shortcuts: My Orders & Wishlist
        item {
            Row(
                modifier = Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ProfileShortcutCard(
                    title = "My Orders",
                    subtitle = "$ordersCount placed",
                    icon = Icons.Outlined.ReceiptLong,
                    onClick = onOpenOrders,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("profile_my_orders_button")
                )
                ProfileShortcutCard(
                    title = "Wishlist",
                    subtitle = "$wishlistCount saved",
                    icon = Icons.Outlined.FavoriteBorder,
                    onClick = onOpenWishlist,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("profile_wishlist_button")
                )
            }
        }

        // 3. Saved Delivery Addresses (for Google-signed-in users)
        if (currentUser != null) {
            item {
                Card(
                    modifier = Modifier
                        .widthIn(max = 680.dp)
                        .fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = OnyxSurface),
                    border = BorderStroke(1.dp, ObsidianBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Saved Delivery Addresses",
                                style = MaterialTheme.typography.titleMedium,
                                color = BrightGold
                            )
                            TextButton(onClick = { showAddAddressDialog = true }) {
                                Icon(
                                    imageVector = Icons.Outlined.AddLocationAlt,
                                    contentDescription = null,
                                    tint = ChampagneGold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(" Add", color = ChampagneGold)
                            }
                        }

                        if (savedAddresses.isEmpty()) {
                            Text(
                                text = "No cloud addresses saved yet. Add your home or shop address for 1-tap checkout.",
                                style = MaterialTheme.typography.bodySmall,
                                color = SageMuted
                            )
                        } else {
                            savedAddresses.forEach { addr ->
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = CharcoalElevated,
                                    border = BorderStroke(
                                        1.dp,
                                        if (addr.defaultAddress) ChampagneGold else ObsidianBorder
                                    )
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "${addr.label}${if (addr.defaultAddress) " (Default)" else ""} · ${addr.recipientName}",
                                                style = MaterialTheme.typography.labelLarge,
                                                color = IvoryText
                                            )
                                            Text(
                                                text = "${addr.formattedAddress()} · ${addr.phone}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = SageMuted
                                            )
                                        }
                                        IconButton(
                                            onClick = { onDeleteAddress(addr.id) },
                                            modifier = Modifier.minimumInteractiveComponentSize()
                                        ) {
                                            Icon(
                                                imageVector = Icons.Outlined.DeleteOutline,
                                                contentDescription = "Delete address",
                                                tint = ErrorRose
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Editable Customer Profile & Fragrance Preferences
        item {
            Card(
                modifier = Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = OnyxSurface),
                border = BorderStroke(1.dp, ObsidianBorder)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Customer Profile & Preferences",
                        style = MaterialTheme.typography.titleLarge,
                        color = BrightGold
                    )

                    val fieldColors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ChampagneGold,
                        unfocusedBorderColor = ObsidianBorder,
                        focusedTextColor = IvoryText,
                        unfocusedTextColor = IvoryText,
                        focusedLabelColor = ChampagneGold,
                        unfocusedLabelColor = SageMuted,
                        cursorColor = ChampagneGold
                    )

                    OutlinedTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = { Text("Full Name") },
                        singleLine = true,
                        colors = fieldColors,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_name_input")
                    )

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Phone / WhatsApp Number") },
                        singleLine = true,
                        colors = fieldColors,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_phone_input")
                    )

                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text("Default Street / Locality") },
                        maxLines = 2,
                        colors = fieldColors,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("profile_address_input")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedTextField(
                            value = city,
                            onValueChange = { city = it },
                            label = { Text("City / District") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = pincode,
                            onValueChange = { pincode = it },
                            label = { Text("PIN Code") },
                            singleLine = true,
                            colors = fieldColors,
                            modifier = Modifier.weight(0.75f)
                        )
                    }

                    Text(
                        text = "Preferred Fragrance Notes",
                        style = MaterialTheme.typography.labelLarge,
                        color = IvoryText
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        scentOptions.forEach { scent ->
                            val selected = preferredScent == scent
                            FilterChip(
                                selected = selected,
                                onClick = { preferredScent = scent },
                                label = { Text(scent) },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = CharcoalElevated,
                                    labelColor = IvoryText,
                                    selectedContainerColor = EmeraldVelvet,
                                    selectedLabelColor = BrightGold
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = selected,
                                    borderColor = ObsidianBorder,
                                    selectedBorderColor = ChampagneGold
                                )
                            )
                        }
                    }

                    GoldPrimaryButton(
                        text = "Save Profile",
                        onClick = {
                            onSaveProfile(fullName, phone, address, city, pincode, preferredScent)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("save_profile_button"),
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Outlined.Save,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    )
                }
            }
        }

        // 5. Trust, Policies & Direct Support
        item {
            Column(
                modifier = Modifier
                    .widthIn(max = 680.dp)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                IslamicGeometricDivider()

                Text(
                    text = "Store Info & Customer Support",
                    style = MaterialTheme.typography.titleLarge,
                    color = BrightGold
                )

                WhatsAppOrderButton(
                    text = "WhatsApp Support · ${storeSettings.whatsappNumber}",
                    onClick = {
                        if (!openWhatsAppConcierge(context, storeSettings.whatsappDigits)) {
                            onNotify("WhatsApp unavailable — greeting copied (${storeSettings.whatsappNumber})")
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("profile_whatsapp_tile")
                )

                ContactActionTile(
                    icon = Icons.Outlined.PhotoCamera,
                    title = "Instagram",
                    value = storeSettings.instagramHandle,
                    onClick = {
                        if (!openInstagramProfile(context, storeSettings.instagramUrl, storeSettings.instagramHandle)) {
                            onNotify("Browser unavailable — ${storeSettings.instagramHandle} copied")
                        }
                    },
                    testTag = "profile_instagram_tile"
                )

                ContactActionTile(
                    icon = Icons.Outlined.LocationOn,
                    title = "Store Location",
                    value = storeSettings.location,
                    onClick = {
                        if (!openStoreInMaps(context, storeSettings.location)) {
                            onNotify("Maps unavailable — address copied to clipboard")
                        }
                    },
                    testTag = "profile_location_tile"
                )

                ContactActionTile(
                    icon = Icons.Outlined.Info,
                    title = "About Us",
                    value = "THE OWAIS OFFICIAL · Heritage & Story",
                    onClick = { onOpenLegalTopic(LegalInfoTopic.ABOUT_US) },
                    testTag = "profile_about_tile"
                )
                ContactActionTile(
                    icon = Icons.Outlined.SupportAgent,
                    title = "Contact & Support",
                    value = StoreConstants.SUPPORT_EMAIL,
                    onClick = { onOpenLegalTopic(LegalInfoTopic.CONTACT_SUPPORT) },
                    testTag = "profile_contact_tile"
                )
                ContactActionTile(
                    icon = Icons.Outlined.LocalShipping,
                    title = "Shipping & Delivery Info",
                    value = "Dispatch, fees & Kupwara coverage",
                    onClick = { onOpenLegalTopic(LegalInfoTopic.SHIPPING_INFO) },
                    testTag = "profile_shipping_tile"
                )
                ContactActionTile(
                    icon = Icons.Outlined.Policy,
                    title = "Return, Refund & Privacy Policies",
                    value = "Returns, refunds & customer privacy",
                    onClick = { onOpenLegalTopic(LegalInfoTopic.RETURN_POLICY) },
                    testTag = "profile_returns_tile"
                )
                ContactActionTile(
                    icon = Icons.Outlined.Gavel,
                    title = "Privacy Policy & Terms",
                    value = "Google Play data safety & terms",
                    onClick = { onOpenLegalTopic(LegalInfoTopic.PRIVACY_POLICY) },
                    testTag = "profile_privacy_tile"
                )
                ContactActionTile(
                    icon = Icons.Outlined.Gavel,
                    title = "Terms & Conditions",
                    value = "Purchase & verification terms",
                    onClick = { onOpenLegalTopic(LegalInfoTopic.TERMS_CONDITIONS) },
                    testTag = "profile_terms_tile"
                )

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    if (showAddAddressDialog) {
        AddAddressDialog(
            initialName = fullName,
            initialPhone = phone,
            onDismiss = { showAddAddressDialog = false },
            onSave = { newAddr ->
                showAddAddressDialog = false
                onSaveAddress(newAddr)
            }
        )
    }
}

@Composable
private fun AddAddressDialog(
    initialName: String,
    initialPhone: String,
    onDismiss: () -> Unit,
    onSave: (DeliveryAddress) -> Unit
) {
    var label by remember { mutableStateOf("Home") }
    var recipient by remember { mutableStateOf(initialName) }
    var phone by remember { mutableStateOf(initialPhone) }
    var street by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("Kupwara") }
    var state by remember { mutableStateOf("Jammu & Kashmir") }
    var pincode by remember { mutableStateOf("193222") }
    var isDefault by remember { mutableStateOf(true) }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = ChampagneGold,
        unfocusedBorderColor = ObsidianBorder,
        focusedTextColor = IvoryText,
        unfocusedTextColor = IvoryText
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = OnyxSurface,
        titleContentColor = IvoryText,
        textContentColor = IvoryText,
        title = { Text("Add Delivery Address") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = label, onValueChange = { label = it }, label = { Text("Label (Home / Work)") }, singleLine = true, colors = fieldColors)
                OutlinedTextField(value = recipient, onValueChange = { recipient = it }, label = { Text("Recipient Name") }, singleLine = true, colors = fieldColors)
                OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone (>=6 digits)") }, singleLine = true, colors = fieldColors)
                OutlinedTextField(value = street, onValueChange = { street = it }, label = { Text("House / Street / Village") }, colors = fieldColors)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = city, onValueChange = { city = it }, label = { Text("City") }, singleLine = true, colors = fieldColors, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = pincode, onValueChange = { pincode = it }, label = { Text("PIN") }, singleLine = true, colors = fieldColors, modifier = Modifier.weight(0.7f))
                }
                OutlinedTextField(value = state, onValueChange = { state = it }, label = { Text("State / UT") }, singleLine = true, colors = fieldColors)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = isDefault,
                        onCheckedChange = { isDefault = it },
                        colors = CheckboxDefaults.colors(checkedColor = ChampagneGold, checkmarkColor = MatteBlack)
                    )
                    Text("Set as default delivery address", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            GoldPrimaryButton(
                text = "Save Address",
                enabled = recipient.isNotBlank() && phone.trim().length >= 6 && street.trim().length >= 3 && pincode.trim().length >= 4,
                onClick = {
                    onSave(
                        DeliveryAddress(
                            label = label,
                            recipientName = recipient,
                            phone = phone,
                            streetAddress = street,
                            city = city,
                            state = state,
                            pincode = pincode,
                            defaultAddress = isDefault
                        )
                    )
                }
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = SageMuted)
            }
        }
    )
}

@Composable
private fun ProfileShortcutCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .minimumInteractiveComponentSize()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = OnyxSurface),
        border = BorderStroke(1.dp, ObsidianBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = EmeraldVelvet
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = BrightGold,
                        modifier = Modifier.padding(8.dp)
                    )
                }
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = IvoryText
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = ChampagneGold
                    )
                }
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = SageMuted
            )
        }
    }
}

@Composable
private fun ContactActionTile(
    icon: ImageVector,
    title: String,
    value: String,
    onClick: () -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .testTag(testTag)
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = OnyxSurface),
        border = BorderStroke(1.dp, ObsidianBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = CircleShape,
                    color = EmeraldDeep,
                    border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.5f))
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = ChampagneGold,
                        modifier = Modifier
                            .padding(10.dp)
                            .size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.labelMedium,
                        color = SageMuted
                    )
                    Text(
                        text = value,
                        style = MaterialTheme.typography.titleSmall,
                        color = IvoryText
                    )
                }
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "Open $title",
                tint = ChampagneGold
            )
        }
    }
}
