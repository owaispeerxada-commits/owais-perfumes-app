package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.StoreConstants
import com.example.data.model.StoreSettingsConfig
import com.example.ui.components.IslamicGeometricDivider
import com.example.ui.components.OwaisBrandLogo
import com.example.ui.components.WhatsAppOrderButton
import com.example.ui.theme.BrightGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MatteBlack
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.OnyxSurface
import com.example.ui.theme.SageMuted
import com.example.util.formatInr
import com.example.util.openInstagramProfile
import com.example.util.openStoreInMaps
import com.example.util.openWhatsAppConcierge

enum class LegalInfoTopic(val title: String) {
    ABOUT_US("About Us"),
    CONTACT_SUPPORT("Contact & Customer Support"),
    SHIPPING_INFO("Shipping & Delivery Info"),
    RETURN_POLICY("Return & Refund Policy"),
    PRIVACY_POLICY("Privacy Policy"),
    TERMS_CONDITIONS("Terms & Conditions")
}

@Composable
fun LegalInfoScreen(
    topic: LegalInfoTopic,
    storeSettings: StoreSettingsConfig,
    onBack: () -> Unit,
    onNotify: (String) -> Unit
) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current

    Scaffold(
        containerColor = MatteBlack,
        topBar = {
            Surface(
                color = OnyxSurface,
                border = BorderStroke(1.dp, ObsidianBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("legal_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = ChampagneGold
                        )
                    }
                    Text(
                        text = topic.title,
                        style = MaterialTheme.typography.headlineSmall,
                        color = IvoryText
                    )
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MatteBlack),
            contentPadding = PaddingValues(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    modifier = Modifier
                        .widthIn(max = 680.dp)
                        .fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = EmeraldDeep.copy(alpha = 0.65f)),
                    border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OwaisBrandLogo(emblemSize = 48.dp, showFullText = true)
                        Text(
                            text = storeSettings.tagline,
                            style = MaterialTheme.typography.titleSmall,
                            color = BrightGold
                        )
                        Text(
                            text = "Location: ${storeSettings.location} · WhatsApp: ${storeSettings.whatsappNumber} · Instagram: ${storeSettings.instagramHandle}",
                            style = MaterialTheme.typography.bodySmall,
                            color = SageMuted
                        )
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier
                        .widthIn(max = 680.dp)
                        .fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = OnyxSurface),
                    border = BorderStroke(1.dp, ObsidianBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        val sections: List<Pair<String, String>> = when (topic) {
                            LegalInfoTopic.ABOUT_US -> listOf(
                                "Our Heritage — ${storeSettings.brandOfficial}" to storeSettings.aboutStory,
                                "Fragrance & Sunnah Craft" to "Every perfume, alcohol-free attar, velvet Quran Pak, Janamaz, Tasbeeh, and Topi is hand-inspected in Kupwara before dispatch.",
                                "Boutique Location" to "${storeSettings.location}\nInstagram: ${storeSettings.instagramHandle}\nWhatsApp Support: ${storeSettings.whatsappNumber}"
                            )
                            LegalInfoTopic.CONTACT_SUPPORT -> listOf(
                                "Direct WhatsApp Concierge" to "Message us directly at ${storeSettings.whatsappNumber} for order status, custom fragrance recommendations, or bulk Nikah/Eid gift inquiries.",
                                "Official Email Support" to "Reach our team at ${StoreConstants.SUPPORT_EMAIL} with your Order ID (e.g., OWS-12345).",
                                "Instagram & Storefront" to "Follow ${storeSettings.instagramHandle} or visit us in ${storeSettings.location}."
                            )
                            LegalInfoTopic.SHIPPING_INFO -> listOf(
                                "Dispatch & Processing" to "Orders placed are reviewed and packed within 24–48 business hours from ${storeSettings.location}.",
                                "Delivery Charges" to "Standard shipping charge is ${formatInr(storeSettings.deliveryChargeInr)}. Orders of ${formatInr(storeSettings.freeDeliveryThresholdInr)} or above qualify for FREE delivery.",
                                "Delivery Coverage" to "We deliver across Jammu & Kashmir and pan-India via trusted courier partners. Tracking confirmation is shared on WhatsApp."
                            )
                            LegalInfoTopic.RETURN_POLICY -> listOf(
                                "Damaged or Incorrect Items" to "Please record an unboxing video within 48 hours of delivery and send it with your Order ID on WhatsApp (${storeSettings.whatsappNumber}). Verified damaged or incorrect items are eligible for free replacement or refund.",
                                "Non-Returnable Hygiene Items" to "Opened perfume bottles, used roll-on attars, miswak sticks, and personal prayer items cannot be returned for hygiene reasons unless received damaged.",
                                "Order Cancellations" to "Pending orders can be cancelled directly from 'My Orders' before confirmation."
                            )
                            LegalInfoTopic.PRIVACY_POLICY -> listOf(
                                "Information We Collect" to "When browsing in Guest mode, cart and wishlist items stay locally on your device. When you sign in with Google, we store your name, verified email, phone number, saved delivery addresses, and order records securely in Google Cloud Firestore.",
                                "How We Use Your Data" to "Your data is used strictly to fulfill orders, verify UPI payments, send order status notifications, and prefill checkout details. We never sell or rent customer data to third parties.",
                                "Data Deletion & Control" to "You can delete saved delivery addresses directly in the app or email ${StoreConstants.SUPPORT_EMAIL} to request full account data deletion."
                            )
                            LegalInfoTopic.TERMS_CONDITIONS -> listOf(
                                "Store Terms" to "By placing an order through OWAIS PERFUMES & ISLAMIC STORE (THE OWAIS OFFICIAL), you agree to provide accurate delivery and contact information.",
                                "Pricing & Payment Verification" to "All prices are listed in Indian Rupees (INR). UPI payments require entering a valid UTR reference and are verified manually by store administration before dispatch.",
                                "Availability & Stock" to "Product availability is updated in real time. Should an item go out of stock unexpectedly, our team will promptly contact you on WhatsApp for a replacement or full refund."
                            )
                        }

                        sections.forEachIndexed { index, (heading, body) ->
                            if (index > 0) IslamicGeometricDivider()
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = heading,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                    color = BrightGold
                                )
                                Text(
                                    text = body,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = IvoryText.copy(alpha = 0.9f)
                                )
                            }
                        }

                        IslamicGeometricDivider()

                        WhatsAppOrderButton(
                            text = "Contact Us on WhatsApp (${storeSettings.whatsappNumber})",
                            onClick = {
                                if (!openWhatsAppConcierge(context, storeSettings.whatsappDigits)) {
                                    onNotify("WhatsApp unavailable — greeting copied")
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            androidx.compose.material3.OutlinedButton(
                                onClick = {
                                    if (!openInstagramProfile(context, storeSettings.instagramUrl, storeSettings.instagramHandle)) {
                                        onNotify("Handle ${storeSettings.instagramHandle} copied")
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                border = BorderStroke(1.dp, ObsidianBorder)
                            ) {
                                Text("Instagram", color = ChampagneGold)
                            }
                            androidx.compose.material3.OutlinedButton(
                                onClick = {
                                    if (!openStoreInMaps(context, storeSettings.location)) {
                                        onNotify("Address copied")
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                border = BorderStroke(1.dp, ObsidianBorder)
                            ) {
                                Text("Kupwara Map", color = ChampagneGold)
                            }
                        }
                    }
                }
            }
        }
    }
}
