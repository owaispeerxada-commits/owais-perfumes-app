package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.model.Product
import com.example.data.model.ProductCategory
import com.example.data.model.ProductVariant
import com.example.data.model.StoreBanner
import com.example.data.model.StoreCategory
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.theme.BrightGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.EmeraldVelvet
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MatteBlack
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.OnyxSurface
import com.example.ui.theme.SageMuted
import java.util.UUID

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminProductEditorDialog(
    initialProduct: Product?,
    categories: List<StoreCategory>,
    onUploadImage: (productId: String, uri: Uri, onUrl: (String) -> Unit) -> Unit,
    onDismiss: () -> Unit,
    onSave: (Product) -> Unit
) {
    val stableId = remember(initialProduct) {
        initialProduct?.id?.ifBlank { "prod_${UUID.randomUUID().toString().take(8)}" }
            ?: "prod_${UUID.randomUUID().toString().take(8)}"
    }
    val initialCat = categories.firstOrNull { it.id == initialProduct?.categoryId } ?: categories.first()

    var name by remember { mutableStateOf(initialProduct?.name.orEmpty()) }
    var subtitle by remember { mutableStateOf(initialProduct?.subtitle.orEmpty()) }
    var selectedCategory by remember { mutableStateOf(initialCat) }
    var priceText by remember { mutableStateOf((initialProduct?.priceInr ?: 1499).toString()) }
    var mrpText by remember { mutableStateOf((initialProduct?.originalPriceInr ?: 0).toString()) }
    var stockText by remember { mutableStateOf((initialProduct?.stockCount ?: 25).toString()) }
    var badge by remember { mutableStateOf(initialProduct?.badge ?: "OWAIS OFFICIAL") }
    var variantLabel by remember { mutableStateOf(initialProduct?.variants?.firstOrNull()?.label ?: "100 ml") }
    var topNotes by remember { mutableStateOf(initialProduct?.topNotes ?: "Saffron, Bergamot") }
    var heartNotes by remember { mutableStateOf(initialProduct?.heartNotes ?: "Damask Rose, Amber") }
    var baseNotes by remember { mutableStateOf(initialProduct?.baseNotes ?: "Aged Oud, Musk") }
    var origin by remember { mutableStateOf(initialProduct?.originOrMaterial ?: "Kupwara Store Curation") }
    var description by remember { mutableStateOf(initialProduct?.description.orEmpty()) }
    var featured by remember { mutableStateOf(initialProduct?.isFeatured ?: false) }
    var enabled by remember { mutableStateOf(initialProduct?.enabled ?: true) }
    var imageUrls by remember { mutableStateOf(initialProduct?.imageUrls.orEmpty()) }

    val photoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            onUploadImage(stableId, uri) { uploadedUrl ->
                imageUrls = (imageUrls + uploadedUrl).take(6)
            }
        }
    }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = ChampagneGold,
        unfocusedBorderColor = ObsidianBorder,
        focusedTextColor = IvoryText,
        unfocusedTextColor = IvoryText
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = OnyxSurface,
        titleContentColor = IvoryText,
        textContentColor = IvoryText,
        title = { Text(if (initialProduct == null) "Add New Product" else "Edit Product") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Product Name *") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = subtitle, onValueChange = { subtitle = it }, label = { Text("Subtitle / Highlights") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())

                Text("Category", style = MaterialTheme.typography.labelMedium, color = ChampagneGold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    categories.forEach { cat ->
                        val selected = selectedCategory.id == cat.id
                        FilterChip(
                            selected = selected,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat.name, style = MaterialTheme.typography.labelSmall) },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = CharcoalElevated,
                                labelColor = IvoryText,
                                selectedContainerColor = EmeraldVelvet,
                                selectedLabelColor = BrightGold
                            )
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = priceText, onValueChange = { priceText = it.filter { c -> c.isDigit() } }, label = { Text("Price (₹) *") }, singleLine = true, colors = fieldColors, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = mrpText, onValueChange = { mrpText = it.filter { c -> c.isDigit() } }, label = { Text("MRP (₹, opt)") }, singleLine = true, colors = fieldColors, modifier = Modifier.weight(1f))
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = stockText, onValueChange = { stockText = it.filter { c -> c.isDigit() } }, label = { Text("Stock Qty") }, singleLine = true, colors = fieldColors, modifier = Modifier.weight(1f))
                    OutlinedTextField(value = variantLabel, onValueChange = { variantLabel = it }, label = { Text("Size / Edition") }, singleLine = true, colors = fieldColors, modifier = Modifier.weight(1f))
                }

                OutlinedTextField(value = badge, onValueChange = { badge = it }, label = { Text("Badge Label") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Full Description *") }, maxLines = 3, colors = fieldColors, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = topNotes, onValueChange = { topNotes = it }, label = { Text("Top Notes / Material") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = heartNotes, onValueChange = { heartNotes = it }, label = { Text("Heart Notes / Design") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = baseNotes, onValueChange = { baseNotes = it }, label = { Text("Base Notes / Finish") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = origin, onValueChange = { origin = it }, label = { Text("Origin / Concentration") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = CharcoalElevated,
                    border = BorderStroke(1.dp, ObsidianBorder)
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Product Images (${imageUrls.size}/6 uploaded)",
                            style = MaterialTheme.typography.labelMedium,
                            color = ChampagneGold
                        )
                        OutlinedButton(
                            onClick = {
                                photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                            modifier = Modifier.fillMaxWidth(),
                            border = BorderStroke(1.dp, ChampagneGold)
                        ) {
                            Text("Upload Photo via Photo Picker", color = BrightGold)
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = featured,
                        onCheckedChange = { featured = it },
                        colors = CheckboxDefaults.colors(checkedColor = ChampagneGold, checkmarkColor = MatteBlack)
                    )
                    Text("Featured", style = MaterialTheme.typography.bodySmall)
                    Checkbox(
                        checked = enabled,
                        onCheckedChange = { enabled = it },
                        colors = CheckboxDefaults.colors(checkedColor = ChampagneGold, checkmarkColor = MatteBlack)
                    )
                    Text("Visible in Store", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            GoldPrimaryButton(
                text = "Save Product",
                enabled = name.trim().length >= 2 && description.trim().length >= 4 && (priceText.toIntOrNull() ?: 0) >= 1,
                onClick = {
                    val price = (priceText.toIntOrNull() ?: 999).coerceAtLeast(1)
                    val mrp = mrpText.toIntOrNull()?.takeIf { it > price }
                    val stock = (stockText.toIntOrNull() ?: 10).coerceAtLeast(0)
                    onSave(
                        Product(
                            id = stableId,
                            name = name.trim(),
                            subtitle = subtitle.trim().ifBlank { selectedCategory.name },
                            category = selectedCategory.groupType,
                            categoryId = selectedCategory.id,
                            categoryName = selectedCategory.name,
                            priceInr = price,
                            originalPriceInr = mrp,
                            stockCount = stock,
                            rating = initialProduct?.rating ?: 4.9,
                            reviewCount = initialProduct?.reviewCount ?: 12,
                            badge = badge.trim().ifBlank { "OWAIS OFFICIAL" },
                            isDemo = initialProduct?.isDemo ?: false,
                            isFeatured = featured,
                            enabled = enabled,
                            drawableResName = initialProduct?.drawableResName ?: selectedCategory.drawableResName,
                            imageUrls = imageUrls,
                            topNotes = topNotes,
                            heartNotes = heartNotes,
                            baseNotes = baseNotes,
                            originOrMaterial = origin,
                            description = description.trim(),
                            variants = listOf(ProductVariant(variantLabel.ifBlank { "Standard" }, price))
                        )
                    )
                }
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = SageMuted)
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminCategoryDialog(
    onDismiss: () -> Unit,
    onSave: (StoreCategory) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var subtitle by remember { mutableStateOf("") }
    var selectedGroup by remember { mutableStateOf(ProductCategory.PERFUMES) }
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = ChampagneGold,
        unfocusedBorderColor = ObsidianBorder,
        focusedTextColor = IvoryText,
        unfocusedTextColor = IvoryText
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = OnyxSurface,
        titleContentColor = IvoryText,
        textContentColor = IvoryText,
        title = { Text("Add Unlimited Category") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Category Name *") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = subtitle, onValueChange = { subtitle = it }, label = { Text("Subtitle") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())
                Text("Group Section", style = MaterialTheme.typography.labelMedium, color = ChampagneGold)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ProductCategory.entries.forEach { group ->
                        FilterChip(
                            selected = selectedGroup == group,
                            onClick = { selectedGroup = group },
                            label = { Text(group.displayName) },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = CharcoalElevated,
                                labelColor = IvoryText,
                                selectedContainerColor = EmeraldVelvet,
                                selectedLabelColor = BrightGold
                            )
                        )
                    }
                }
            }
        },
        confirmButton = {
            GoldPrimaryButton(
                text = "Save Category",
                enabled = name.trim().length >= 2,
                onClick = {
                    onSave(
                        StoreCategory(
                            id = "",
                            name = name.trim(),
                            groupType = selectedGroup,
                            subtitle = subtitle.trim().ifBlank { "${name.trim()} Collection" },
                            displayOrder = 50,
                            enabled = true,
                            drawableResName = when (selectedGroup) {
                                ProductCategory.ATTARS -> "img_featured_oud"
                                ProductCategory.ISLAMIC_PRODUCTS -> "img_category_islamic"
                                else -> "img_category_perfumes"
                            }
                        )
                    )
                }
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = SageMuted)
            }
        }
    )
}

@Composable
fun AdminBannerEditorDialog(
    initialBanner: StoreBanner?,
    onDismiss: () -> Unit,
    onSave: (StoreBanner) -> Unit
) {
    var title by remember { mutableStateOf(initialBanner?.title.orEmpty()) }
    var subtitle by remember { mutableStateOf(initialBanner?.subtitle.orEmpty()) }
    var badge by remember { mutableStateOf(initialBanner?.badgeText ?: "THE OWAIS OFFICIAL") }
    var cta by remember { mutableStateOf(initialBanner?.ctaText ?: "Shop Now") }
    var active by remember { mutableStateOf(initialBanner?.active ?: true) }
    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = ChampagneGold,
        unfocusedBorderColor = ObsidianBorder,
        focusedTextColor = IvoryText,
        unfocusedTextColor = IvoryText
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = OnyxSurface,
        titleContentColor = IvoryText,
        textContentColor = IvoryText,
        title = { Text(if (initialBanner == null) "Add Banner" else "Edit Banner") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Banner Title *") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = subtitle, onValueChange = { subtitle = it }, label = { Text("Banner Subtitle") }, maxLines = 2, colors = fieldColors, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = badge, onValueChange = { badge = it }, label = { Text("Badge Text") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = cta, onValueChange = { cta = it }, label = { Text("Button CTA Text") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(
                        checked = active,
                        onCheckedChange = { active = it },
                        colors = CheckboxDefaults.colors(checkedColor = ChampagneGold, checkmarkColor = MatteBlack)
                    )
                    Text("Active on Homepage", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            GoldPrimaryButton(
                text = "Save Banner",
                enabled = title.trim().length >= 2,
                onClick = {
                    onSave(
                        StoreBanner(
                            id = initialBanner?.id.orEmpty(),
                            title = title.trim(),
                            subtitle = subtitle.trim(),
                            badgeText = badge.trim(),
                            ctaText = cta.trim(),
                            targetCategory = initialBanner?.targetCategory.orEmpty(),
                            drawableResName = initialBanner?.drawableResName ?: "img_hero_banner",
                            imageUrl = initialBanner?.imageUrl.orEmpty(),
                            active = active,
                            displayOrder = initialBanner?.displayOrder ?: 5
                        )
                    )
                }
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = SageMuted)
            }
        }
    )
}
