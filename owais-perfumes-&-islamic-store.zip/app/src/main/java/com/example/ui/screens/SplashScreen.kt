package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.LocationOn
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.StoreConstants
import com.example.ui.components.IslamicGeometricDivider
import com.example.ui.theme.BrightGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MatteBlack
import com.example.ui.theme.SageMuted
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SplashScreen(
    onFinished: () -> Unit
) {
    val logoScale = remember { Animatable(0.75f) }
    val contentAlpha = remember { Animatable(0f) }

    val infiniteTransition = rememberInfiniteTransition(label = "splash_halo")
    val haloRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 16000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "halo_rotation"
    )

    LaunchedEffect(Unit) {
        logoScale.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 700, easing = FastOutSlowInEasing)
        )
        contentAlpha.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 550)
        )
        delay(1200)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        EmeraldDeep,
                        MatteBlack,
                        MatteBlack
                    ),
                    radius = 1200f
                )
            )
            .systemBarsPadding()
            .clickable { onFinished() }
            .testTag("splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(210.dp)
                    .scale(logoScale.value),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val outerRadius = size.minDimension * 0.48f
                    rotate(haloRotation, pivot = center) {
                        val starPath = Path()
                        val points = 12
                        for (i in 0 until points * 2) {
                            val r = if (i % 2 == 0) outerRadius else outerRadius * 0.88f
                            val angle = i * Math.PI / points
                            val x = center.x + (r * cos(angle)).toFloat()
                            val y = center.y + (r * sin(angle)).toFloat()
                            if (i == 0) starPath.moveTo(x, y) else starPath.lineTo(x, y)
                        }
                        starPath.close()
                        drawPath(
                            path = starPath,
                            color = ChampagneGold.copy(alpha = 0.42f),
                            style = Stroke(width = 1.4.dp.toPx())
                        )
                    }
                    drawCircle(
                        color = ChampagneGold.copy(alpha = 0.25f),
                        radius = outerRadius * 0.82f,
                        style = Stroke(width = 1.dp.toPx())
                    )
                }

                Image(
                    painter = painterResource(id = R.drawable.owais_logo_icon),
                    contentDescription = "OWAIS PERFUMES & ISLAMIC STORE Logo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(142.dp)
                        .clip(CircleShape)
                        .border(2.dp, ChampagneGold, CircleShape)
                )
            }

            Spacer(modifier = Modifier.height(26.dp))

            Column(
                modifier = Modifier.alpha(contentAlpha.value),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = StoreConstants.BRAND_OFFICIAL,
                    style = MaterialTheme.typography.labelLarge.copy(
                        letterSpacing = 3.sp
                    ),
                    color = ChampagneGold
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "OWAIS PERFUMES",
                    style = MaterialTheme.typography.displaySmall.copy(
                        fontSize = 30.sp,
                        letterSpacing = 3.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = IvoryText,
                    textAlign = TextAlign.Center
                )

                Text(
                    text = "& ISLAMIC STORE",
                    style = MaterialTheme.typography.titleMedium.copy(
                        letterSpacing = 2.4.sp,
                        fontWeight = FontWeight.SemiBold
                    ),
                    color = BrightGold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = StoreConstants.TAGLINE,
                    style = MaterialTheme.typography.bodyMedium,
                    color = SageMuted,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(18.dp))
                IslamicGeometricDivider(modifier = Modifier.fillMaxWidth(0.7f))
                Spacer(modifier = Modifier.height(16.dp))

                Surface(
                    shape = RoundedCornerShape(50),
                    color = EmeraldDeep.copy(alpha = 0.8f),
                    border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.45f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.LocationOn,
                            contentDescription = null,
                            tint = ChampagneGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = StoreConstants.STORE_LOCATION,
                            style = MaterialTheme.typography.bodySmall,
                            color = IvoryText
                        )
                    }
                }

                Spacer(modifier = Modifier.height(22.dp))
                Text(
                    text = "${StoreConstants.GREETING} · Tap to enter",
                    style = MaterialTheme.typography.labelSmall,
                    color = SageMuted.copy(alpha = 0.85f)
                )
            }
        }
    }
}
