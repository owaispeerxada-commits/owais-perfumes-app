package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.AdminAnalytics
import com.example.data.model.OrderStatus
import com.example.data.model.PaymentStatus
import com.example.data.model.Product
import com.example.data.model.StoreBanner
import com.example.data.model.StoreCategory
import com.example.data.model.StoreOrder
import com.example.data.model.StoreSettingsConfig
import com.example.ui.components.EmeraldOutlinedButton
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.theme.BrightGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldVelvet
import com.example.ui.theme.ErrorRose
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MatteBlack
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.OnyxSurface
import com.example.ui.theme.SageMuted
import com.example.util.formatInr
import com.example.util.formatOrderDate

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AdminDashboardScreen(
    analytics: AdminAnalytics,
    products: List<Product>,
    categories: List<StoreCategory>,
    orders: List<StoreOrder>,
    banners: List<StoreBanner>,
    storeSettings: StoreSettingsConfig,
    onBack: () -> Unit,
    onSeedCatalog: () -> Unit,
    onSaveProduct: (Product) -> Unit,
    onDeleteProduct: (String) -> Unit,
    onToggleFeatured: (Product) -> Unit,
    onToggleEnabled: (Product) -> Unit,
    onUploadProductImage: (String, Uri, (String) -> Unit) -> Unit,
    onSaveCategory: (StoreCategory) -> Unit,
    onUpdateOrderStatus: (String, OrderStatus, PaymentStatus) -> Unit,
    onSaveStoreSettings: (StoreSettingsConfig) -> Unit,
    onSaveBanner: (StoreBanner) -> Unit
) {
    BackHandler(onBack = onBack)

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Analytics", "Catalog", "Orders", "Store")

    var editingProduct by remember { mutableStateOf<Product?>(null) }
    var showProductDialog by remember { mutableStateOf(false) }
    var showCategoryDialog by remember { mutableStateOf(false) }
    var editingBanner by remember { mutableStateOf<StoreBanner?>(null) }
    var showBannerDialog by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = MatteBlack,
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(OnyxSurface)
                    .statusBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("admin_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = ChampagneGold
                            )
                        }
                        Column {
                            Text(
                                text = "Admin Control Center",
                                style = MaterialTheme.typography.titleLarge,
                                color = BrightGold
                            )
                            Text(
                                text = "THE OWAIS OFFICIAL · Store Operations",
                                style = MaterialTheme.typography.labelSmall,
                                color = SageMuted
                            )
                        }
                    }

                    TextButton(onClick = onSeedCatalog) {
                        Icon(
                            imageVector = Icons.Filled.CloudSync,
                            contentDescription = null,
                            tint = ChampagneGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(" Sync Seed", color = ChampagneGold, style = MaterialTheme.typography.labelSmall)
                    }
                }

                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = OnyxSurface,
                    contentColor = BrightGold,
                    indicator = { tabPositions ->
                        if (selectedTab < tabPositions.size) {
                            TabRowDefaults.SecondaryIndicator(
                                modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                                color = ChampagneGold
                            )
                        }
                    }
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = { selectedTab = index },
                            text = {
                                Text(
                                    text = title,
                                    color = if (selectedTab == index) BrightGold else SageMuted
                                )
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MatteBlack),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            when (selectedTab) {
                0 -> AdminAnalyticsTab(
                    analytics = analytics,
                    modifier = Modifier.widthIn(max = 720.dp)
                )
                1 -> AdminCatalogTab(
                    products = products,
                    categories = categories,
                    onAddProduct = {
                        editingProduct = null
                        showProductDialog = true
                    },
                    onEditProduct = { product ->
                        editingProduct = product
                        showProductDialog = true
                    },
                    onDeleteProduct = onDeleteProduct,
                    onToggleFeatured = onToggleFeatured,
                    onToggleEnabled = onToggleEnabled,
                    onAddCategory = { showCategoryDialog = true },
                    modifier = Modifier.widthIn(max = 720.dp)
                )
                2 -> AdminOrdersTab(
                    orders = orders,
                    onUpdateStatus = onUpdateOrderStatus,
                    modifier = Modifier.widthIn(max = 720.dp)
                )
                3 -> AdminStoreSettingsTab(
                    storeSettings = storeSettings,
                    banners = banners,
                    onSaveSettings = onSaveStoreSettings,
                    onAddBanner = {
                        editingBanner = null
                        showBannerDialog = true
                    },
                    onEditBanner = { banner ->
                        editingBanner = banner
                        showBannerDialog = true
                    },
                    modifier = Modifier.widthIn(max = 720.dp)
                )
            }
        }
    }

    if (showProductDialog) {
        AdminProductEditorDialog(
            initialProduct = editingProduct,
            categories = categories.ifEmpty { com.example.data.model.StoreCatalog.defaultCategories },
            onUploadImage = onUploadProductImage,
            onDismiss = { showProductDialog = false },
            onSave = { product ->
                showProductDialog = false
                onSaveProduct(product)
            }
        )
    }

    if (showCategoryDialog) {
        AdminCategoryDialog(
            onDismiss = { showCategoryDialog = false },
            onSave = { cat ->
                showCategoryDialog = false
                onSaveCategory(cat)
            }
        )
    }

    if (showBannerDialog) {
        AdminBannerEditorDialog(
            initialBanner = editingBanner,
            onDismiss = { showBannerDialog = false },
            onSave = { banner ->
                showBannerDialog = false
                onSaveBanner(banner)
            }
        )
    }
}

@Composable
private fun AdminAnalyticsTab(
    analytics: AdminAnalytics,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Store Analytics Overview",
                style = MaterialTheme.typography.headlineSmall,
                color = IvoryText
            )
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricBox("Total Products", analytics.totalProducts.toString(), Modifier.weight(1f))
                MetricBox("Customers", analytics.totalCustomers.toString(), Modifier.weight(1f))
            }
        }
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricBox("Total Orders", analytics.totalOrders.toString(), Modifier.weight(1f))
                MetricBox("Pending Orders", analytics.pendingOrders.toString(), Modifier.weight(1f))
            }
        }
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MetricBox("Delivered Orders", analytics.deliveredOrders.toString(), Modifier.weight(1f))
                MetricBox("Verified Sales", formatInr(analytics.verifiedSalesInr), Modifier.weight(1f))
            }
        }
        item {
            MetricBox(
                "Total Order Volume (All Non-Cancelled)",
                formatInr(analytics.totalOrderVolumeInr),
                Modifier.fillMaxWidth()
            )
        }

        item {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.WarningAmber,
                    contentDescription = null,
                    tint = if (analytics.lowStockProducts.isNotEmpty()) ErrorRose else ChampagneGold
                )
                Text(
                    text = "Low-Stock Alerts (${analytics.lowStockProducts.size})",
                    style = MaterialTheme.typography.titleMedium,
                    color = BrightGold
                )
            }
        }

        if (analytics.lowStockProducts.isEmpty()) {
            item {
                Text("All products have healthy inventory (> 5 units).", style = MaterialTheme.typography.bodySmall, color = SageMuted)
            }
        } else {
            items(analytics.lowStockProducts, key = { it.id }) { prod ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = OnyxSurface),
                    border = BorderStroke(1.dp, ErrorRose.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(prod.name, style = MaterialTheme.typography.titleSmall, color = IvoryText)
                            Text(prod.categoryName, style = MaterialTheme.typography.bodySmall, color = SageMuted)
                        }
                        Text(
                            text = "${prod.stockCount} left",
                            style = MaterialTheme.typography.labelLarge,
                            color = ErrorRose
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricBox(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = EmeraldDeep.copy(alpha = 0.6f)),
        border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.4f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = SageMuted)
            Text(
                text = value,
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                color = BrightGold
            )
        }
    }
}

@Composable
private fun AdminCatalogTab(
    products: List<Product>,
    categories: List<StoreCategory>,
    onAddProduct: () -> Unit,
    onEditProduct: (Product) -> Unit,
    onDeleteProduct: (String) -> Unit,
    onToggleFeatured: (Product) -> Unit,
    onToggleEnabled: (Product) -> Unit,
    onAddCategory: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GoldPrimaryButton(
                    text = "Add Product",
                    onClick = onAddProduct,
                    modifier = Modifier.weight(1f),
                    leadingIcon = { Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                EmeraldOutlinedButton(
                    text = "Add Category",
                    onClick = onAddCategory,
                    modifier = Modifier.weight(1f),
                    leadingIcon = { Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
            }
        }

        item {
            Text(
                text = "Categories (${categories.size}) · Products (${products.size})",
                style = MaterialTheme.typography.labelMedium,
                color = ChampagneGold
            )
        }

        items(products, key = { it.id }) { prod ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = OnyxSurface),
                border = BorderStroke(1.dp, ObsidianBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(prod.name, style = MaterialTheme.typography.titleMedium, color = IvoryText)
                            Text(
                                text = "${prod.categoryName} · ${formatInr(prod.priceInr)} · Stock: ${prod.stockCount}",
                                style = MaterialTheme.typography.bodySmall,
                                color = ChampagneGold
                            )
                        }
                        Row {
                            IconButton(onClick = { onToggleFeatured(prod) }) {
                                Icon(
                                    imageVector = Icons.Filled.Star,
                                    contentDescription = "Toggle featured",
                                    tint = if (prod.isFeatured) BrightGold else ObsidianBorder
                                )
                            }
                            IconButton(onClick = { onEditProduct(prod) }) {
                                Icon(Icons.Filled.Edit, contentDescription = "Edit product", tint = ChampagneGold)
                            }
                            IconButton(onClick = { onDeleteProduct(prod.id) }) {
                                Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete product", tint = ErrorRose)
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (prod.enabled) "Visible in Storefront" else "Hidden from Storefront",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (prod.enabled) IvoryText else SageMuted
                        )
                        Switch(
                            checked = prod.enabled,
                            onCheckedChange = { onToggleEnabled(prod) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = MatteBlack,
                                checkedTrackColor = ChampagneGold
                            )
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AdminOrdersTab(
    orders: List<StoreOrder>,
    onUpdateStatus: (String, OrderStatus, PaymentStatus) -> Unit,
    modifier: Modifier = Modifier
) {
    var search by remember { mutableStateOf("") }
    val filtered = remember(search, orders) {
        val q = search.trim().lowercase()
        if (q.isEmpty()) orders else orders.filter {
            it.orderNumber.lowercase().contains(q) ||
                it.customerName.lowercase().contains(q) ||
                it.customerPhone.lowercase().contains(q)
        }
    }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                label = { Text("Search Order ID, Customer, or Phone") },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ChampagneGold,
                    unfocusedBorderColor = ObsidianBorder,
                    focusedTextColor = IvoryText,
                    unfocusedTextColor = IvoryText
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (filtered.isEmpty()) {
            item {
                Text("No orders matching filter.", style = MaterialTheme.typography.bodyMedium, color = SageMuted)
            }
        } else {
            items(filtered, key = { it.id }) { order ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = OnyxSurface),
                    border = BorderStroke(1.dp, ObsidianBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${order.orderNumber} · ${order.customerName}", style = MaterialTheme.typography.titleSmall, color = BrightGold)
                            Text(formatInr(order.totalAmountInr), style = MaterialTheme.typography.titleSmall, color = IvoryText)
                        }
                        Text(
                            text = "${formatOrderDate(order.createdAtMillis)} · ${order.customerPhone}",
                            style = MaterialTheme.typography.bodySmall,
                            color = SageMuted
                        )
                        Text(order.itemsSummary, style = MaterialTheme.typography.bodySmall, color = IvoryText)
                        Text("Address: ${order.deliveryAddress}", style = MaterialTheme.typography.bodySmall, color = SageMuted)
                        if (order.upiTransactionRef.isNotBlank()) {
                            Text("UPI UTR: ${order.upiTransactionRef}", style = MaterialTheme.typography.labelSmall, color = ChampagneGold)
                        }

                        HorizontalDivider(color = ObsidianBorder)

                        Text("Order Status", style = MaterialTheme.typography.labelSmall, color = ChampagneGold)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            OrderStatus.entries.forEach { st ->
                                val selected = order.orderStatus == st
                                FilterChip(
                                    selected = selected,
                                    onClick = { onUpdateStatus(order.id, st, order.paymentStatus) },
                                    label = { Text(st.label, style = MaterialTheme.typography.labelSmall) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        containerColor = CharcoalElevated,
                                        labelColor = SageMuted,
                                        selectedContainerColor = EmeraldVelvet,
                                        selectedLabelColor = BrightGold
                                    )
                                )
                            }
                        }

                        Text("Payment Verification", style = MaterialTheme.typography.labelSmall, color = ChampagneGold)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            PaymentStatus.entries.forEach { pst ->
                                val selected = order.paymentStatus == pst
                                FilterChip(
                                    selected = selected,
                                    onClick = { onUpdateStatus(order.id, order.orderStatus, pst) },
                                    label = { Text(pst.label, style = MaterialTheme.typography.labelSmall) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        containerColor = CharcoalElevated,
                                        labelColor = SageMuted,
                                        selectedContainerColor = EmeraldVelvet,
                                        selectedLabelColor = BrightGold
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminStoreSettingsTab(
    storeSettings: StoreSettingsConfig,
    banners: List<StoreBanner>,
    onSaveSettings: (StoreSettingsConfig) -> Unit,
    onAddBanner: () -> Unit,
    onEditBanner: (StoreBanner) -> Unit,
    modifier: Modifier = Modifier
) {
    var whatsapp by remember { mutableStateOf(storeSettings.whatsappNumber) }
    var instagram by remember { mutableStateOf(storeSettings.instagramHandle) }
    var location by remember { mutableStateOf(storeSettings.location) }
    var deliveryCharge by remember { mutableStateOf(storeSettings.deliveryChargeInr.toString()) }
    var freeThreshold by remember { mutableStateOf(storeSettings.freeDeliveryThresholdInr.toString()) }
    var codEnabled by remember { mutableStateOf(storeSettings.codEnabled) }
    var upiId by remember { mutableStateOf(storeSettings.upiId) }
    var paymentInstructions by remember { mutableStateOf(storeSettings.paymentInstructions) }
    var aboutStory by remember { mutableStateOf(storeSettings.aboutStory) }

    LaunchedEffect(storeSettings) {
        whatsapp = storeSettings.whatsappNumber
        instagram = storeSettings.instagramHandle
        location = storeSettings.location
        deliveryCharge = storeSettings.deliveryChargeInr.toString()
        freeThreshold = storeSettings.freeDeliveryThresholdInr.toString()
        codEnabled = storeSettings.codEnabled
        upiId = storeSettings.upiId
        paymentInstructions = storeSettings.paymentInstructions
        aboutStory = storeSettings.aboutStory
    }

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = ChampagneGold,
        unfocusedBorderColor = ObsidianBorder,
        focusedTextColor = IvoryText,
        unfocusedTextColor = IvoryText
    )

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Store Contact, Delivery & UPI Settings", style = MaterialTheme.typography.titleLarge, color = BrightGold)
        }
        item {
            OutlinedTextField(value = whatsapp, onValueChange = { whatsapp = it }, label = { Text("WhatsApp Number") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())
        }
        item {
            OutlinedTextField(value = instagram, onValueChange = { instagram = it }, label = { Text("Instagram Handle") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())
        }
        item {
            OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("Store Location") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = deliveryCharge, onValueChange = { deliveryCharge = it.filter { c -> c.isDigit() } }, label = { Text("Delivery Fee (₹)") }, singleLine = true, colors = fieldColors, modifier = Modifier.weight(1f))
                OutlinedTextField(value = freeThreshold, onValueChange = { freeThreshold = it.filter { c -> c.isDigit() } }, label = { Text("Free Above (₹)") }, singleLine = true, colors = fieldColors, modifier = Modifier.weight(1f))
            }
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Enable Cash on Delivery (COD)", style = MaterialTheme.typography.bodyMedium, color = IvoryText)
                Switch(
                    checked = codEnabled,
                    onCheckedChange = { codEnabled = it },
                    colors = SwitchDefaults.colors(checkedThumbColor = MatteBlack, checkedTrackColor = ChampagneGold)
                )
            }
        }
        item {
            OutlinedTextField(value = upiId, onValueChange = { upiId = it }, label = { Text("Store UPI ID") }, singleLine = true, colors = fieldColors, modifier = Modifier.fillMaxWidth())
        }
        item {
            OutlinedTextField(value = paymentInstructions, onValueChange = { paymentInstructions = it }, label = { Text("Payment Instructions") }, maxLines = 3, colors = fieldColors, modifier = Modifier.fillMaxWidth())
        }
        item {
            OutlinedTextField(value = aboutStory, onValueChange = { aboutStory = it }, label = { Text("About Store Story") }, maxLines = 4, colors = fieldColors, modifier = Modifier.fillMaxWidth())
        }
        item {
            GoldPrimaryButton(
                text = "Save Store Settings",
                onClick = {
                    onSaveSettings(
                        storeSettings.copy(
                            whatsappNumber = whatsapp,
                            instagramHandle = instagram,
                            location = location,
                            deliveryChargeInr = deliveryCharge.toIntOrNull() ?: 99,
                            freeDeliveryThresholdInr = freeThreshold.toIntOrNull() ?: 1999,
                            codEnabled = codEnabled,
                            upiId = upiId,
                            paymentInstructions = paymentInstructions,
                            aboutStory = aboutStory
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth()
            )
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Homepage Banners (${banners.size})", style = MaterialTheme.typography.titleMedium, color = BrightGold)
                TextButton(onClick = onAddBanner) {
                    Text("+ Add Banner", color = ChampagneGold)
                }
            }
        }

        items(banners, key = { it.id }) { banner ->
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = OnyxSurface,
                border = BorderStroke(1.dp, ObsidianBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(banner.title, style = MaterialTheme.typography.titleSmall, color = IvoryText)
                        Text(
                            text = "${if (banner.active) "Active" else "Hidden"} · ${banner.badgeText}",
                            style = MaterialTheme.typography.bodySmall,
                            color = ChampagneGold
                        )
                    }
                    IconButton(onClick = { onEditBanner(banner) }) {
                        Icon(Icons.Filled.Edit, contentDescription = "Edit banner", tint = ChampagneGold)
                    }
                }
            }
        }
    }
}
