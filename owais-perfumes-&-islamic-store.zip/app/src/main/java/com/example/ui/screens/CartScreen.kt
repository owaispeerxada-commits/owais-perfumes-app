package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.LocalShipping
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.CartItemEntity
import com.example.data.local.CustomerProfileEntity
import com.example.data.model.DeliveryAddress
import com.example.data.model.PaymentPreference
import com.example.data.model.StoreSettingsConfig
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.components.productDrawableRes
import com.example.ui.theme.BrightGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.ErrorRose
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MatteBlack
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.OnyxSurface
import com.example.ui.theme.SageMuted
import com.example.util.formatInr

@Composable
fun CartScreen(
    cartItems: List<CartItemEntity>,
    subtotalInr: Int,
    storeSettings: StoreSettingsConfig,
    customerProfile: CustomerProfileEntity,
    savedAddresses: List<DeliveryAddress>,
    onQuantityChange: (String, Int) -> Unit,
    onRemoveItem: (String) -> Unit,
    onProductClick: (String) -> Unit,
    onExploreClick: () -> Unit,
    onBack: (() -> Unit)? = null,
    onPlaceOrder: (
        name: String,
        phone: String,
        address: String,
        paymentPreference: PaymentPreference,
        upiRef: String,
        launchWhatsApp: Boolean
    ) -> Unit,
    modifier: Modifier = Modifier
) {
    if (onBack != null) {
        BackHandler(onBack = onBack)
    }

    var showCheckoutDialog by remember { mutableStateOf(false) }
    val deliveryCharge = storeSettings.calculateDeliveryCharge(subtotalInr)
    val grandTotal = subtotalInr + deliveryCharge

    Scaffold(
        containerColor = MatteBlack,
        topBar = {
            if (onBack != null) {
                Surface(
                    color = OnyxSurface,
                    border = BorderStroke(1.dp, ObsidianBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(horizontal = 8.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(
                            onClick = onBack,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("cart_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = ChampagneGold
                            )
                        }
                        Text(
                            text = "Shopping Bag",
                            style = MaterialTheme.typography.headlineSmall,
                            color = IvoryText
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MatteBlack),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (cartItems.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = EmeraldDeep.copy(alpha = 0.6f),
                        border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.4f)),
                        modifier = Modifier.size(84.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.ShoppingBag,
                            contentDescription = null,
                            tint = ChampagneGold,
                            modifier = Modifier
                                .padding(20.dp)
                                .fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.height(18.dp))
                    Text(
                        text = "Your Shopping Bag is Empty",
                        style = MaterialTheme.typography.headlineSmall,
                        color = IvoryText,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Explore our Kashmiri saffron attars, luxury perfumes, and Sunnah essentials to begin your order.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SageMuted,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    GoldPrimaryButton(
                        text = "Explore Boutique",
                        onClick = onExploreClick,
                        modifier = Modifier.testTag("empty_cart_explore_button")
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .widthIn(max = 680.dp)
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(
                                text = "Shopping Bag",
                                style = MaterialTheme.typography.headlineMedium,
                                color = IvoryText
                            )
                            Text(
                                text = "${cartItems.sumOf { it.quantity }} item(s) ready for checkout",
                                style = MaterialTheme.typography.bodySmall,
                                color = SageMuted
                            )
                        }
                    }

                    items(cartItems, key = { it.cartKey }) { item ->
                        CartItemRow(
                            item = item,
                            onClick = { onProductClick(item.productId) },
                            onDecrease = { onQuantityChange(item.cartKey, item.quantity - 1) },
                            onIncrease = { onQuantityChange(item.cartKey, item.quantity + 1) },
                            onRemove = { onRemoveItem(item.cartKey) }
                        )
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = EmeraldDeep.copy(alpha = 0.5f)
                            ),
                            border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.4f))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.LocalShipping,
                                        contentDescription = null,
                                        tint = ChampagneGold,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = "Dispatched from ${storeSettings.location}",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = BrightGold
                                    )
                                }

                                HorizontalDivider(color = ObsidianBorder)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "Items Subtotal",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = SageMuted
                                    )
                                    Text(
                                        text = formatInr(subtotalInr),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = IvoryText
                                    )
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = if (storeSettings.freeDeliveryThresholdInr > 0) {
                                            "Delivery (Free over ${formatInr(storeSettings.freeDeliveryThresholdInr)})"
                                        } else {
                                            "Delivery Charge"
                                        },
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = SageMuted
                                    )
                                    Text(
                                        text = if (deliveryCharge == 0) "FREE" else formatInr(deliveryCharge),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = ChampagneGold
                                    )
                                }

                                HorizontalDivider(color = ObsidianBorder)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Grand Total",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = IvoryText
                                    )
                                    Text(
                                        text = formatInr(grandTotal),
                                        style = MaterialTheme.typography.headlineSmall.copy(
                                            fontWeight = FontWeight.Bold
                                        ),
                                        color = BrightGold
                                    )
                                }
                            }
                        }
                    }
                }

                Surface(
                    color = OnyxSurface,
                    border = BorderStroke(1.dp, ObsidianBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .widthIn(max = 680.dp)
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        GoldPrimaryButton(
                            text = "Proceed to Checkout · ${formatInr(grandTotal)}",
                            onClick = { showCheckoutDialog = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("cart_whatsapp_checkout_button"),
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Outlined.Chat,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        )
                    }
                }
            }
        }
    }

    if (showCheckoutDialog) {
        CheckoutModalDialog(
            title = "Complete Your Order",
            subtotalInr = subtotalInr,
            storeSettings = storeSettings,
            initialProfile = customerProfile,
            savedAddresses = savedAddresses,
            onDismiss = { showCheckoutDialog = false },
            onConfirmOrder = { name, phone, address, pref, upiRef, launchWhatsApp ->
                showCheckoutDialog = false
                onPlaceOrder(name, phone, address, pref, upiRef, launchWhatsApp)
            }
        )
    }
}

@Composable
private fun CartItemRow(
    item: CartItemEntity,
    onClick: () -> Unit,
    onDecrease: () -> Unit,
    onIncrease: () -> Unit,
    onRemove: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = OnyxSurface),
        border = BorderStroke(1.dp, ObsidianBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                painter = painterResource(id = productDrawableRes(item.drawableResName)),
                contentDescription = item.productName,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(84.dp)
                    .clip(RoundedCornerShape(12.dp))
            )

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = item.productName,
                            style = MaterialTheme.typography.titleMedium,
                            color = IvoryText,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${item.categoryName} · ${item.variantLabel}",
                            style = MaterialTheme.typography.bodySmall,
                            color = SageMuted
                        )
                    }
                    IconButton(
                        onClick = onRemove,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("remove_cart_${item.cartKey}")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.DeleteOutline,
                            contentDescription = "Remove item",
                            tint = ErrorRose
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = formatInr(item.unitPriceInr * item.quantity),
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = BrightGold
                    )

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = CharcoalElevated,
                        border = BorderStroke(1.dp, ObsidianBorder)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = onDecrease,
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Remove,
                                    contentDescription = "Decrease quantity",
                                    tint = ChampagneGold,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Text(
                                text = item.quantity.toString(),
                                style = MaterialTheme.typography.labelLarge,
                                color = IvoryText,
                                modifier = Modifier.padding(horizontal = 4.dp)
                            )
                            IconButton(
                                onClick = onIncrease,
                                modifier = Modifier.minimumInteractiveComponentSize()
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Add,
                                    contentDescription = "Increase quantity",
                                    tint = ChampagneGold,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
