package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.auth.GoogleAuthHelper
import com.example.data.local.CartItemEntity
import com.example.data.local.CustomerProfileEntity
import com.example.data.local.OrderEntity
import com.example.data.model.AdminAnalytics
import com.example.data.model.DeliveryAddress
import com.example.data.model.OrderStatus
import com.example.data.model.PaymentPreference
import com.example.data.model.PaymentStatus
import com.example.data.model.Product
import com.example.data.model.ProductCategory
import com.example.data.model.ProductVariant
import com.example.data.model.SortOption
import com.example.data.model.StoreBanner
import com.example.data.model.StoreCatalog
import com.example.data.model.StoreCategory
import com.example.data.model.StoreOrder
import com.example.data.model.StoreSettingsConfig
import com.example.data.remote.StoreAdminFirestoreRepository
import com.example.data.remote.StoreFirestoreRepository
import com.example.data.repository.StoreRepository
import com.example.service.OwaisNotificationHelper
import com.example.util.buildWhatsAppOrderMessage
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

sealed interface StoreUiEvent {
    data class ShowMessage(val message: String) : StoreUiEvent
    data class LaunchWhatsAppOrder(val message: String, val orderId: String) : StoreUiEvent
    data class LaunchUpiPayment(
        val upiId: String,
        val payeeName: String,
        val amountInr: Int,
        val orderNumber: String
    ) : StoreUiEvent
}

@OptIn(ExperimentalCoroutinesApi::class)
class StoreViewModel(
    application: Application,
    private val localRepo: StoreRepository,
    private val firestoreRepo: StoreFirestoreRepository
) : AndroidViewModel(application) {

    private val adminRepo = StoreAdminFirestoreRepository(application.applicationContext, firestoreRepo.db)
    private val auth: FirebaseAuth = firestoreRepo.auth

    private val _currentUser = MutableStateFlow(auth.currentUser)
    val currentUser: StateFlow<FirebaseUser?> = _currentUser.asStateFlow()

    private val _isAdmin = MutableStateFlow(false)
    val isAdmin: StateFlow<Boolean> = _isAdmin.asStateFlow()

    private val _selectedHomeCategory = MutableStateFlow<ProductCategory?>(null)
    val selectedHomeCategory: StateFlow<ProductCategory?> = _selectedHomeCategory.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchCategory = MutableStateFlow<ProductCategory?>(null)
    val searchCategory: StateFlow<ProductCategory?> = _searchCategory.asStateFlow()

    private val _searchSubCategoryId = MutableStateFlow<String?>(null)
    val searchSubCategoryId: StateFlow<String?> = _searchSubCategoryId.asStateFlow()

    private val _sortOption = MutableStateFlow(SortOption.FEATURED)
    val sortOption: StateFlow<SortOption> = _sortOption.asStateFlow()

    private val _events = MutableSharedFlow<StoreUiEvent>()
    val events = _events.asSharedFlow()

    private var lastKnownOrderStatuses: Map<String, OrderStatus> = emptyMap()

    private val authListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
        val user = firebaseAuth.currentUser
        _currentUser.value = user
        if (user == null) {
            _isAdmin.value = false
            lastKnownOrderStatuses = emptyMap()
        } else {
            viewModelScope.launch {
                firestoreRepo.ensureUserProfile(user)
                val admin = firestoreRepo.checkIsAdmin(user)
                _isAdmin.value = admin
                if (admin) {
                    adminRepo.seedInitialStoreDataIfEmpty()
                }
            }
        }
    }

    init {
        auth.addAuthStateListener(authListener)
        viewModelScope.launch {
            GoogleAuthHelper.attemptAutoSignIn(getApplication(), auth)
        }
    }

    override fun onCleared() {
        auth.removeAuthStateListener(authListener)
        super.onCleared()
    }

    private fun <T> safeFlow(flow: Flow<T>, fallback: T, tag: String): Flow<T> =
        flow.catch { e ->
            if (e is CancellationException) throw e
            Log.e("StoreViewModel", "Stream error in $tag", e)
            emit(fallback)
        }

    // Catalog & Store Configuration: live from Firestore when authenticated, rich default catalog in Guest mode
    val categories: StateFlow<List<StoreCategory>> = _currentUser.flatMapLatest { user ->
        if (user == null) {
            flowOf(StoreCatalog.defaultCategories)
        } else {
            safeFlow(
                firestoreRepo.observeCategories().map { list ->
                    if (list.isEmpty()) StoreCatalog.defaultCategories else list
                },
                StoreCatalog.defaultCategories,
                "categories"
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StoreCatalog.defaultCategories)

    val allProducts: StateFlow<List<Product>> = _currentUser.flatMapLatest { user ->
        if (user == null) {
            flowOf(StoreCatalog.products)
        } else {
            safeFlow(
                firestoreRepo.observeProducts().map { list ->
                    if (list.isEmpty()) StoreCatalog.products else list
                },
                StoreCatalog.products,
                "products"
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StoreCatalog.products)

    val activeProducts: StateFlow<List<Product>> = allProducts
        .map { list -> list.filter { it.enabled } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StoreCatalog.products)

    val banners: StateFlow<List<StoreBanner>> = _currentUser.flatMapLatest { user ->
        if (user == null) {
            flowOf(StoreCatalog.defaultBanners)
        } else {
            safeFlow(
                firestoreRepo.observeBanners().map { list ->
                    val active = list.filter { it.active }
                    active.ifEmpty { StoreCatalog.defaultBanners }
                },
                StoreCatalog.defaultBanners,
                "banners"
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StoreCatalog.defaultBanners)

    val storeSettings: StateFlow<StoreSettingsConfig> = _currentUser.flatMapLatest { user ->
        if (user == null) {
            flowOf(StoreSettingsConfig())
        } else {
            safeFlow(
                firestoreRepo.observeStoreSettings().map { it ?: StoreSettingsConfig() },
                StoreSettingsConfig(),
                "store_settings"
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StoreSettingsConfig())

    val homeProducts: StateFlow<List<Product>> = combine(
        _selectedHomeCategory,
        activeProducts
    ) { category, products ->
        if (category == null) products else products.filter { it.category == category }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StoreCatalog.products)

    val featuredProducts: StateFlow<List<Product>> = activeProducts
        .map { list -> list.filter { it.isFeatured } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StoreCatalog.products.filter { it.isFeatured })

    val searchResults: StateFlow<List<Product>> = combine(
        _searchQuery,
        _searchCategory,
        _searchSubCategoryId,
        _sortOption,
        activeProducts
    ) { query, category, subCatId, sort, products ->
        val q = query.trim().lowercase()
        val filtered = products.filter { product ->
            val matchesGroup = category == null || product.category == category
            val matchesSubCat = subCatId == null || product.categoryId == subCatId
            val matchesQuery = q.isEmpty() ||
                product.name.lowercase().contains(q) ||
                product.subtitle.lowercase().contains(q) ||
                product.categoryName.lowercase().contains(q) ||
                product.description.lowercase().contains(q) ||
                product.topNotes.lowercase().contains(q) ||
                product.heartNotes.lowercase().contains(q) ||
                product.baseNotes.lowercase().contains(q)
            matchesGroup && matchesSubCat && matchesQuery
        }
        when (sort) {
            SortOption.FEATURED -> filtered.sortedByDescending { it.isFeatured }
            SortOption.PRICE_LOW_HIGH -> filtered.sortedBy { it.priceInr }
            SortOption.PRICE_HIGH_LOW -> filtered.sortedByDescending { it.priceInr }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), StoreCatalog.products)

    // Cart, Wishlist, Orders, Addresses, Profile
    val cartItems: StateFlow<List<CartItemEntity>> = _currentUser.flatMapLatest { user ->
        if (user == null) localRepo.cartItems else safeFlow(firestoreRepo.observeCart(user.uid), emptyList(), "cart")
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartItemCount: StateFlow<Int> = cartItems
        .map { items -> items.sumOf { it.quantity } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val cartSubtotalInr: StateFlow<Int> = cartItems
        .map { items -> items.sumOf { it.unitPriceInr * it.quantity } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val wishlistIds: StateFlow<Set<String>> = _currentUser.flatMapLatest { user ->
        if (user == null) localRepo.wishlistIds else safeFlow(firestoreRepo.observeWishlist(user.uid), emptySet(), "wishlist")
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    val wishlistProducts: StateFlow<List<Product>> = combine(
        wishlistIds,
        activeProducts
    ) { ids, products ->
        products.filter { it.id in ids }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<StoreOrder>> = _currentUser.flatMapLatest { user ->
        if (user == null) {
            localRepo.orders.map { list -> list.map { it.toStoreOrder() } }
        } else {
            safeFlow(firestoreRepo.observeUserOrders(user.uid), emptyList(), "orders").map { list ->
                notifyOrderStatusChanges(list)
                list
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedAddresses: StateFlow<List<DeliveryAddress>> = _currentUser.flatMapLatest { user ->
        if (user == null) flowOf(emptyList()) else safeFlow(firestoreRepo.observeAddresses(user.uid), emptyList(), "addresses")
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val defaultProfile = CustomerProfileEntity(
        fullName = "",
        phoneNumber = "",
        addressLine = "",
        city = "Kupwara",
        pincode = "193222",
        preferredScent = "Oud & Saffron"
    )

    val customerProfile: StateFlow<CustomerProfileEntity> = _currentUser.flatMapLatest { user ->
        if (user == null) {
            localRepo.customerProfile.map { it ?: defaultProfile }
        } else {
            safeFlow(
                firestoreRepo.observeUserProfile(user.uid).combine(localRepo.customerProfile) { remote, local ->
                    remote?.copy(
                        addressLine = local?.addressLine.orEmpty(),
                        city = local?.city ?: "Kupwara",
                        pincode = local?.pincode ?: "193222"
                    ) ?: defaultProfile.copy(fullName = user.displayName.orEmpty())
                },
                defaultProfile,
                "profile"
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), defaultProfile)

    // Admin Streams
    val adminOrders: StateFlow<List<StoreOrder>> = _isAdmin.flatMapLatest { admin ->
        if (!admin) flowOf(emptyList()) else safeFlow(adminRepo.observeAllOrders(), emptyList(), "admin_orders")
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val adminCustomersCount: StateFlow<Int> = _isAdmin.flatMapLatest { admin ->
        if (!admin) flowOf(0) else safeFlow(adminRepo.observeAllCustomersCount(), 0, "admin_customers")
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val adminAnalytics: StateFlow<AdminAnalytics> = combine(
        allProducts,
        adminOrders,
        adminCustomersCount
    ) { products, allOrders, customersCount ->
        AdminAnalytics(
            totalProducts = products.size,
            totalCustomers = customersCount,
            totalOrders = allOrders.size,
            pendingOrders = allOrders.count { it.orderStatus == OrderStatus.PENDING },
            deliveredOrders = allOrders.count { it.orderStatus == OrderStatus.DELIVERED },
            verifiedSalesInr = allOrders
                .filter { it.orderStatus != OrderStatus.CANCELLED && it.paymentStatus == PaymentStatus.VERIFIED }
                .sumOf { it.totalAmountInr },
            totalOrderVolumeInr = allOrders
                .filter { it.orderStatus != OrderStatus.CANCELLED }
                .sumOf { it.totalAmountInr },
            lowStockProducts = products.filter { it.stockCount <= 5 }
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AdminAnalytics())

    private fun notifyOrderStatusChanges(latestOrders: List<StoreOrder>) {
        if (lastKnownOrderStatuses.isEmpty()) {
            lastKnownOrderStatuses = latestOrders.associate { it.id to it.orderStatus }
            return
        }
        latestOrders.forEach { order ->
            val prev = lastKnownOrderStatuses[order.id]
            if (prev != null && prev != order.orderStatus) {
                OwaisNotificationHelper.showOrderNotification(
                    context = getApplication(),
                    notificationId = order.id.hashCode(),
                    title = "Order ${order.orderNumber} · ${order.orderStatus.label}",
                    body = "Your order status has been updated to ${order.orderStatus.label}."
                )
            }
        }
        lastKnownOrderStatuses = latestOrders.associate { it.id to it.orderStatus }
    }

    fun getProduct(productId: String): Product? =
        allProducts.value.firstOrNull { it.id == productId } ?: StoreCatalog.findById(productId)

    fun selectHomeCategory(category: ProductCategory?) {
        _selectedHomeCategory.value = category
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectSearchCategory(category: ProductCategory?, subCategoryId: String? = null) {
        _searchCategory.value = category
        _searchSubCategoryId.value = subCategoryId
    }

    fun selectSortOption(sort: SortOption) {
        _sortOption.value = sort
    }

    fun onSignedInSuccess(user: FirebaseUser) {
        viewModelScope.launch {
            firestoreRepo.ensureUserProfile(user)
            val isAdminUser = firestoreRepo.checkIsAdmin(user)
            _isAdmin.value = isAdminUser
            if (isAdminUser) {
                adminRepo.seedInitialStoreDataIfEmpty()
                _events.emit(StoreUiEvent.ShowMessage("Welcome Admin (${user.email}) — Dashboard unlocked"))
            } else {
                _events.emit(StoreUiEvent.ShowMessage("Assalamu Alaikum, ${user.displayName ?: "Signed in"}!"))
            }
        }
    }

    fun signOut() {
        viewModelScope.launch {
            GoogleAuthHelper.signOut(getApplication(), auth)
            _events.emit(StoreUiEvent.ShowMessage("Signed out — browsing in Guest mode"))
        }
    }

    fun addToCart(product: Product, variant: ProductVariant = product.variants.first(), quantity: Int = 1) {
        if (product.isOutOfStock) {
            viewModelScope.launch {
                _events.emit(StoreUiEvent.ShowMessage("${product.name} is currently out of stock"))
            }
            return
        }
        viewModelScope.launch {
            val user = _currentUser.value
            if (user == null) {
                localRepo.addToCart(product, variant, quantity)
                _events.emit(StoreUiEvent.ShowMessage("${product.name} (${variant.label}) added to bag"))
            } else {
                firestoreRepo.addToCart(user.uid, product, variant, quantity)
                    .onSuccess {
                        _events.emit(StoreUiEvent.ShowMessage("${product.name} (${variant.label}) added to bag"))
                    }
                    .onFailure { err ->
                        _events.emit(StoreUiEvent.ShowMessage(err.message ?: "Failed to add item"))
                    }
            }
        }
    }

    fun updateCartQuantity(cartKey: String, newQuantity: Int) {
        viewModelScope.launch {
            val user = _currentUser.value
            if (user == null) {
                localRepo.updateCartQuantity(cartKey, newQuantity)
            } else {
                firestoreRepo.updateCartQuantity(cartKey, newQuantity)
            }
        }
    }

    fun removeFromCart(cartKey: String) {
        viewModelScope.launch {
            val user = _currentUser.value
            if (user == null) {
                localRepo.removeFromCart(cartKey)
            } else {
                firestoreRepo.removeFromCart(cartKey)
            }
            _events.emit(StoreUiEvent.ShowMessage("Item removed from bag"))
        }
    }

    fun toggleWishlist(product: Product) {
        viewModelScope.launch {
            val user = _currentUser.value
            if (user == null) {
                val added = localRepo.toggleWishlist(product.id)
                _events.emit(
                    StoreUiEvent.ShowMessage(
                        if (added) "${product.name} saved to wishlist" else "${product.name} removed from wishlist"
                    )
                )
            } else {
                firestoreRepo.toggleWishlist(user.uid, product.id)
                    .onSuccess { added ->
                        _events.emit(
                            StoreUiEvent.ShowMessage(
                                if (added) "${product.name} saved to wishlist" else "${product.name} removed from wishlist"
                            )
                        )
                    }
                    .onFailure { err ->
                        _events.emit(StoreUiEvent.ShowMessage(err.message ?: "Could not update wishlist"))
                    }
            }
        }
    }

    fun saveCustomerProfile(
        fullName: String,
        phoneNumber: String,
        addressLine: String,
        city: String,
        pincode: String,
        preferredScent: String
    ) {
        viewModelScope.launch {
            localRepo.saveProfile(
                CustomerProfileEntity(
                    id = 1,
                    fullName = fullName.trim(),
                    phoneNumber = phoneNumber.trim(),
                    addressLine = addressLine.trim(),
                    city = city.trim(),
                    pincode = pincode.trim(),
                    preferredScent = preferredScent
                )
            )
            val user = _currentUser.value
            if (user != null) {
                firestoreRepo.saveUserProfile(
                    uid = user.uid,
                    email = user.email.orEmpty(),
                    fullName = fullName,
                    phone = phoneNumber,
                    preferredScent = preferredScent
                )
            }
            _events.emit(StoreUiEvent.ShowMessage("Profile saved"))
        }
    }

    fun saveDeliveryAddress(address: DeliveryAddress) {
        val user = _currentUser.value
        if (user == null) {
            viewModelScope.launch {
                _events.emit(StoreUiEvent.ShowMessage("Sign in with Google to save cloud delivery addresses"))
            }
            return
        }
        viewModelScope.launch {
            firestoreRepo.saveDeliveryAddress(user.uid, address)
                .onSuccess { _events.emit(StoreUiEvent.ShowMessage("Delivery address saved")) }
                .onFailure { _events.emit(StoreUiEvent.ShowMessage(it.message ?: "Could not save address")) }
        }
    }

    fun deleteDeliveryAddress(addressId: String) {
        val user = _currentUser.value ?: return
        viewModelScope.launch {
            firestoreRepo.deleteDeliveryAddress(user.uid, addressId)
        }
    }

    fun checkoutCart(
        customerName: String,
        customerPhone: String,
        deliveryAddress: String,
        paymentPreference: PaymentPreference,
        upiTransactionRef: String,
        launchWhatsAppAfter: Boolean
    ) {
        val currentCart = cartItems.value
        if (currentCart.isEmpty()) return
        placeItemsOrder(
            items = currentCart,
            customerName = customerName,
            customerPhone = customerPhone,
            deliveryAddress = deliveryAddress,
            paymentPreference = paymentPreference,
            upiTransactionRef = upiTransactionRef,
            clearCart = true,
            launchWhatsAppAfter = launchWhatsAppAfter
        )
    }

    fun buySingleProductNow(
        product: Product,
        variant: ProductVariant,
        quantity: Int,
        customerName: String,
        customerPhone: String,
        deliveryAddress: String,
        paymentPreference: PaymentPreference,
        upiTransactionRef: String,
        launchWhatsAppAfter: Boolean
    ) {
        val item = CartItemEntity(
            cartKey = "${product.id}_${variant.label}",
            productId = product.id,
            productName = product.name,
            categoryName = product.categoryName,
            variantLabel = variant.label,
            unitPriceInr = variant.priceInr,
            quantity = quantity,
            drawableResName = product.drawableResName
        )
        placeItemsOrder(
            items = listOf(item),
            customerName = customerName,
            customerPhone = customerPhone,
            deliveryAddress = deliveryAddress,
            paymentPreference = paymentPreference,
            upiTransactionRef = upiTransactionRef,
            clearCart = false,
            launchWhatsAppAfter = launchWhatsAppAfter
        )
    }

    fun orderSingleProductViaWhatsApp(product: Product, variant: ProductVariant, quantity: Int) {
        val profile = customerProfile.value
        val address = savedAddresses.value.firstOrNull { it.defaultAddress }?.formattedAddress()
            ?: listOf(profile.addressLine, profile.city, profile.pincode).filter { it.isNotBlank() }.joinToString(", ")
                .ifBlank { "Kupwara, Jammu & Kashmir" }
        buySingleProductNow(
            product = product,
            variant = variant,
            quantity = quantity,
            customerName = profile.fullName.ifBlank { _currentUser.value?.displayName ?: "Guest Customer" },
            customerPhone = profile.phoneNumber,
            deliveryAddress = address,
            paymentPreference = PaymentPreference.WHATSAPP_CONFIRM,
            upiTransactionRef = "",
            launchWhatsAppAfter = true
        )
    }

    private fun placeItemsOrder(
        items: List<CartItemEntity>,
        customerName: String,
        customerPhone: String,
        deliveryAddress: String,
        paymentPreference: PaymentPreference,
        upiTransactionRef: String,
        clearCart: Boolean,
        launchWhatsAppAfter: Boolean
    ) {
        viewModelScope.launch {
            val settings = storeSettings.value
            val subtotal = items.sumOf { it.unitPriceInr * it.quantity }
            val deliveryCharge = settings.calculateDeliveryCharge(subtotal)
            val total = subtotal + deliveryCharge
            val orderNum = "OWS-${(10000..99999).random()}"
            val idempotencyKey = UUID.randomUUID().toString().replace("-", "").take(16)
            val message = buildWhatsAppOrderMessage(
                orderId = orderNum,
                items = items,
                totalAmountInr = total,
                customerName = customerName,
                customerPhone = customerPhone,
                deliveryAddress = deliveryAddress,
                deliveryChargeInr = deliveryCharge,
                paymentPreference = paymentPreference,
                upiTransactionRef = upiTransactionRef
            )

            val user = _currentUser.value
            if (user == null) {
                val summary = items.joinToString("\n") {
                    "${it.productName} (${it.variantLabel}) x${it.quantity} — ₹${it.unitPriceInr * it.quantity}"
                }
                localRepo.placeOrder(
                    OrderEntity(
                        orderId = orderNum,
                        customerName = customerName.ifBlank { "Guest Customer" },
                        customerPhone = customerPhone,
                        deliveryAddress = deliveryAddress.ifBlank { "Kupwara, Jammu & Kashmir" },
                        itemsSummary = summary,
                        itemCount = items.sumOf { it.quantity },
                        totalAmountInr = total,
                        status = OrderStatus.PENDING.label,
                        whatsappMessage = message
                    ),
                    clearCart = clearCart
                )
                if (launchWhatsAppAfter) {
                    _events.emit(StoreUiEvent.LaunchWhatsAppOrder(message, orderNum))
                } else {
                    _events.emit(StoreUiEvent.ShowMessage("Guest order $orderNum saved locally. Sign in with Google for cloud order sync."))
                }
            } else {
                firestoreRepo.placeOrder(
                    user = user,
                    orderNumber = orderNum,
                    customerName = customerName,
                    customerPhone = customerPhone,
                    deliveryAddress = deliveryAddress,
                    items = items,
                    deliveryChargeInr = deliveryCharge,
                    paymentPreference = paymentPreference,
                    upiTransactionRef = upiTransactionRef,
                    whatsappMessage = message,
                    idempotencyKey = idempotencyKey,
                    clearCart = clearCart
                ).onSuccess { created ->
                    if (launchWhatsAppAfter) {
                        _events.emit(StoreUiEvent.LaunchWhatsAppOrder(created.whatsappMessage, created.orderNumber))
                    } else if (paymentPreference == PaymentPreference.UPI && upiTransactionRef.isBlank()) {
                        _events.emit(
                            StoreUiEvent.LaunchUpiPayment(
                                upiId = settings.upiId,
                                payeeName = settings.upiPayeeName,
                                amountInr = created.totalAmountInr,
                                orderNumber = created.orderNumber
                            )
                        )
                    } else {
                        _events.emit(StoreUiEvent.ShowMessage("Order ${created.orderNumber} placed!"))
                    }
                }.onFailure { err ->
                    _events.emit(StoreUiEvent.ShowMessage(err.message ?: "Failed to place order"))
                }
            }
        }
    }

    fun cancelOrder(orderId: String) {
        if (_currentUser.value == null) return
        viewModelScope.launch {
            firestoreRepo.cancelPendingOrder(orderId)
                .onSuccess { _events.emit(StoreUiEvent.ShowMessage("Order cancelled")) }
                .onFailure { _events.emit(StoreUiEvent.ShowMessage(it.message ?: "Could not cancel order")) }
        }
    }

    fun submitUpiRef(orderId: String, utrRef: String) {
        if (_currentUser.value == null || utrRef.isBlank()) return
        viewModelScope.launch {
            firestoreRepo.submitUpiReference(orderId, utrRef)
                .onSuccess { _events.emit(StoreUiEvent.ShowMessage("UTR submitted for admin verification")) }
                .onFailure { _events.emit(StoreUiEvent.ShowMessage(it.message ?: "Failed to submit UTR")) }
        }
    }

    // --- Admin Actions ---
    fun adminSeedCatalog() {
        viewModelScope.launch {
            adminRepo.seedInitialStoreDataIfEmpty()
                .onSuccess { _events.emit(StoreUiEvent.ShowMessage(it)) }
                .onFailure { _events.emit(StoreUiEvent.ShowMessage(it.message ?: "Seed failed")) }
        }
    }

    fun adminSaveProduct(product: Product) {
        viewModelScope.launch {
            adminRepo.saveProduct(product)
                .onSuccess { _events.emit(StoreUiEvent.ShowMessage("${product.name} saved")) }
                .onFailure { _events.emit(StoreUiEvent.ShowMessage(it.message ?: "Failed to save product")) }
        }
    }

    fun adminDeleteProduct(productId: String) {
        viewModelScope.launch {
            adminRepo.deleteProduct(productId)
                .onSuccess { _events.emit(StoreUiEvent.ShowMessage("Product deleted")) }
                .onFailure { _events.emit(StoreUiEvent.ShowMessage(it.message ?: "Failed to delete product")) }
        }
    }

    fun adminToggleProductFeatured(product: Product) {
        viewModelScope.launch {
            adminRepo.updateProductFlags(product.id, featured = !product.isFeatured)
        }
    }

    fun adminToggleProductEnabled(product: Product) {
        viewModelScope.launch {
            adminRepo.updateProductFlags(product.id, enabled = !product.enabled)
        }
    }

    fun adminUploadProductImage(productId: String, uri: Uri, onUploaded: (String) -> Unit) {
        viewModelScope.launch {
            adminRepo.uploadProductImage(productId, uri)
                .onSuccess { url ->
                    onUploaded(url)
                    _events.emit(StoreUiEvent.ShowMessage("Product image uploaded"))
                }
                .onFailure { err ->
                    _events.emit(StoreUiEvent.ShowMessage(err.message ?: "Image upload failed"))
                }
        }
    }

    fun adminSaveCategory(category: StoreCategory) {
        viewModelScope.launch {
            adminRepo.saveCategory(category)
                .onSuccess { _events.emit(StoreUiEvent.ShowMessage("Category '${category.name}' saved")) }
                .onFailure { _events.emit(StoreUiEvent.ShowMessage(it.message ?: "Failed to save category")) }
        }
    }

    fun adminUpdateOrderStatus(orderId: String, orderStatus: OrderStatus, paymentStatus: PaymentStatus) {
        viewModelScope.launch {
            adminRepo.updateOrderStatus(orderId, orderStatus, paymentStatus)
                .onSuccess { _events.emit(StoreUiEvent.ShowMessage("Order updated to ${orderStatus.label}")) }
                .onFailure { _events.emit(StoreUiEvent.ShowMessage(it.message ?: "Failed to update order")) }
        }
    }

    fun adminSaveStoreSettings(settings: StoreSettingsConfig) {
        viewModelScope.launch {
            adminRepo.saveStoreSettings(settings)
                .onSuccess { _events.emit(StoreUiEvent.ShowMessage("Store settings updated")) }
                .onFailure { _events.emit(StoreUiEvent.ShowMessage(it.message ?: "Failed to save store settings")) }
        }
    }

    fun adminSaveBanner(banner: StoreBanner) {
        viewModelScope.launch {
            adminRepo.saveBanner(banner)
                .onSuccess { _events.emit(StoreUiEvent.ShowMessage("Banner updated")) }
                .onFailure { _events.emit(StoreUiEvent.ShowMessage(it.message ?: "Failed to save banner")) }
        }
    }

    private fun OrderEntity.toStoreOrder(): StoreOrder = StoreOrder(
        id = orderId,
        orderNumber = orderId,
        createdAtMillis = createdAt,
        customerName = customerName,
        customerPhone = customerPhone,
        deliveryAddress = deliveryAddress,
        itemsSummary = itemsSummary,
        itemCount = itemCount,
        subtotalInr = totalAmountInr,
        deliveryChargeInr = 0,
        totalAmountInr = totalAmountInr,
        paymentPreference = PaymentPreference.WHATSAPP_CONFIRM,
        paymentStatus = PaymentStatus.UNVERIFIED,
        orderStatus = OrderStatus.fromLabel(status),
        whatsappMessage = whatsappMessage
    )
}

class StoreViewModelFactory(
    private val application: Application,
    private val repository: StoreRepository,
    private val firestoreRepository: StoreFirestoreRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(StoreViewModel::class.java)) {
            return StoreViewModel(application, repository, firestoreRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
    }
}
