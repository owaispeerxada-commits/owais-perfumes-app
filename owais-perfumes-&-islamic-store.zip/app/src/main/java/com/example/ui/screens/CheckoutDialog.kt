package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.local.CustomerProfileEntity
import com.example.data.model.DeliveryAddress
import com.example.data.model.PaymentPreference
import com.example.data.model.StoreSettingsConfig
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.theme.BrightGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldVelvet
import com.example.ui.theme.ErrorRose
import com.example.ui.theme.IvoryText
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.OnyxSurface
import com.example.ui.theme.SageMuted
import com.example.util.copyToClipboard
import com.example.util.formatInr
import com.example.util.openUpiPaymentApp

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CheckoutModalDialog(
    title: String,
    subtotalInr: Int,
    storeSettings: StoreSettingsConfig,
    initialProfile: CustomerProfileEntity,
    savedAddresses: List<DeliveryAddress>,
    onDismiss: () -> Unit,
    onConfirmOrder: (
        name: String,
        phone: String,
        address: String,
        paymentPreference: PaymentPreference,
        upiRef: String,
        launchWhatsApp: Boolean
    ) -> Unit
) {
    val context = LocalContext.current
    val defaultSaved = savedAddresses.firstOrNull { it.defaultAddress } ?: savedAddresses.firstOrNull()

    var name by remember {
        mutableStateOf(
            defaultSaved?.recipientName?.ifBlank { initialProfile.fullName } ?: initialProfile.fullName
        )
    }
    var phone by remember {
        mutableStateOf(
            defaultSaved?.phone?.ifBlank { initialProfile.phoneNumber } ?: initialProfile.phoneNumber
        )
    }
    val fallbackAddr = listOf(initialProfile.addressLine, initialProfile.city, initialProfile.pincode)
        .filter { it.isNotBlank() }
        .joinToString(", ")
    var address by remember {
        mutableStateOf(
            defaultSaved?.formattedAddress()?.ifBlank { fallbackAddr }
                ?: fallbackAddr.ifBlank { "Kupwara, Jammu & Kashmir 193222" }
        )
    }

    val availableMethods = remember(storeSettings.codEnabled) {
        if (storeSettings.codEnabled) {
            listOf(PaymentPreference.UPI, PaymentPreference.COD, PaymentPreference.WHATSAPP_CONFIRM)
        } else {
            listOf(PaymentPreference.UPI, PaymentPreference.WHATSAPP_CONFIRM)
        }
    }
    var selectedPayment by remember { mutableStateOf(PaymentPreference.WHATSAPP_CONFIRM) }
    var upiRef by remember { mutableStateOf("") }
    var validationError by remember { mutableStateOf<String?>(null) }
    var copiedNotice by remember { mutableStateOf(false) }

    val deliveryCharge = storeSettings.calculateDeliveryCharge(subtotalInr)
    val grandTotal = subtotalInr + deliveryCharge

    val fieldColors = OutlinedTextFieldDefaults.colors(
        focusedBorderColor = ChampagneGold,
        unfocusedBorderColor = ObsidianBorder,
        focusedTextColor = IvoryText,
        unfocusedTextColor = IvoryText,
        focusedLabelColor = ChampagneGold,
        unfocusedLabelColor = SageMuted,
        cursorColor = ChampagneGold
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = OnyxSurface,
        titleContentColor = IvoryText,
        textContentColor = IvoryText,
        title = {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineSmall
            )
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = EmeraldDeep.copy(alpha = 0.65f),
                    border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.4f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Subtotal", style = MaterialTheme.typography.bodySmall, color = SageMuted)
                            Text(formatInr(subtotalInr), style = MaterialTheme.typography.bodySmall, color = IvoryText)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Delivery", style = MaterialTheme.typography.bodySmall, color = SageMuted)
                            Text(
                                if (deliveryCharge == 0) "FREE" else formatInr(deliveryCharge),
                                style = MaterialTheme.typography.bodySmall,
                                color = ChampagneGold
                            )
                        }
                        HorizontalDivider(color = ObsidianBorder)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total Payable", style = MaterialTheme.typography.titleSmall, color = IvoryText)
                            Text(
                                formatInr(grandTotal),
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = BrightGold
                            )
                        }
                    }
                }

                if (savedAddresses.isNotEmpty()) {
                    Text(
                        text = "Saved Delivery Addresses",
                        style = MaterialTheme.typography.labelMedium,
                        color = ChampagneGold
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        savedAddresses.forEach { saved ->
                            FilterChip(
                                selected = address == saved.formattedAddress(),
                                onClick = {
                                    name = saved.recipientName
                                    phone = saved.phone
                                    address = saved.formattedAddress()
                                },
                                label = { Text("${saved.label} · ${saved.city}") },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = CharcoalElevated,
                                    labelColor = IvoryText,
                                    selectedContainerColor = EmeraldVelvet,
                                    selectedLabelColor = BrightGold
                                )
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; validationError = null },
                    label = { Text("Full Name *") },
                    singleLine = true,
                    colors = fieldColors,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it; validationError = null },
                    label = { Text("Phone / WhatsApp Number *") },
                    singleLine = true,
                    colors = fieldColors,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it; validationError = null },
                    label = { Text("Full Delivery Address & PIN *") },
                    maxLines = 2,
                    colors = fieldColors,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Payment Option",
                    style = MaterialTheme.typography.labelMedium,
                    color = ChampagneGold
                )
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    availableMethods.forEach { method ->
                        val selected = selectedPayment == method
                        FilterChip(
                            selected = selected,
                            onClick = { selectedPayment = method },
                            label = {
                                Text(
                                    when (method) {
                                        PaymentPreference.UPI -> "UPI Payment"
                                        PaymentPreference.COD -> "Cash on Delivery"
                                        PaymentPreference.WHATSAPP_CONFIRM -> "WhatsApp Confirm"
                                    }
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = CharcoalElevated,
                                labelColor = IvoryText,
                                selectedContainerColor = EmeraldVelvet,
                                selectedLabelColor = BrightGold
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = selected,
                                borderColor = ObsidianBorder,
                                selectedBorderColor = ChampagneGold
                            )
                        )
                    }
                }

                if (selectedPayment == PaymentPreference.UPI) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = CharcoalElevated,
                        border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.45f))
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Store UPI ID", style = MaterialTheme.typography.labelSmall, color = SageMuted)
                                    Text(storeSettings.upiId, style = MaterialTheme.typography.titleSmall, color = BrightGold)
                                }
                                Row(
                                    modifier = Modifier
                                        .clickable {
                                            copyToClipboard(context, "Store UPI ID", storeSettings.upiId)
                                            copiedNotice = true
                                        }
                                        .padding(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Outlined.ContentCopy,
                                        contentDescription = "Copy UPI ID",
                                        tint = ChampagneGold,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        if (copiedNotice) "Copied" else "Copy",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = ChampagneGold
                                    )
                                }
                            }

                            Text(
                                text = storeSettings.paymentInstructions,
                                style = MaterialTheme.typography.bodySmall,
                                color = SageMuted
                            )

                            OutlinedButton(
                                onClick = {
                                    openUpiPaymentApp(
                                        context = context,
                                        upiId = storeSettings.upiId,
                                        payeeName = storeSettings.upiPayeeName,
                                        amountInr = grandTotal,
                                        orderNote = "Owais Store Order"
                                    )
                                },
                                modifier = Modifier.fillMaxWidth(),
                                border = BorderStroke(1.dp, ChampagneGold)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = BrightGold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Open UPI App (${formatInr(grandTotal)})", color = BrightGold)
                            }

                            OutlinedTextField(
                                value = upiRef,
                                onValueChange = { upiRef = it },
                                label = { Text("UPI UTR / Transaction Ref (optional)") },
                                singleLine = true,
                                colors = fieldColors,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                if (validationError != null) {
                    Text(
                        text = validationError!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = ErrorRose
                    )
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(
                    onClick = {
                        if (name.isBlank() || phone.trim().length < 6 || address.trim().length < 4) {
                            validationError = "Please enter valid name, phone (>=6 digits), and delivery address."
                        } else {
                            onConfirmOrder(name, phone, address, selectedPayment, upiRef, false)
                        }
                    }
                ) {
                    Text("Place Order", color = ChampagneGold)
                }
                GoldPrimaryButton(
                    text = "Order + WhatsApp",
                    onClick = {
                        if (name.isBlank() || phone.trim().length < 6 || address.trim().length < 4) {
                            validationError = "Please enter valid name, phone (>=6 digits), and delivery address."
                        } else {
                            onConfirmOrder(name, phone, address, selectedPayment, upiRef, true)
                        }
                    },
                    modifier = Modifier.testTag("confirm_whatsapp_order_button")
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = SageMuted)
            }
        }
    )
}
