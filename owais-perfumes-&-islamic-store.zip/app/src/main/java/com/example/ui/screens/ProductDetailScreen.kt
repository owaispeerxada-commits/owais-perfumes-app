package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.data.local.CustomerProfileEntity
import com.example.data.model.DeliveryAddress
import com.example.data.model.PaymentPreference
import com.example.data.model.Product
import com.example.data.model.ProductCategory
import com.example.data.model.ProductVariant
import com.example.data.model.StoreSettingsConfig
import com.example.ui.components.EmeraldOutlinedButton
import com.example.ui.components.GoldPrimaryButton
import com.example.ui.components.IslamicGeometricDivider
import com.example.ui.components.ProductMediaImage
import com.example.ui.components.WhatsAppOrderButton
import com.example.ui.theme.BrightGold
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CharcoalElevated
import com.example.ui.theme.EmeraldDeep
import com.example.ui.theme.EmeraldVelvet
import com.example.ui.theme.ErrorRose
import com.example.ui.theme.IvoryText
import com.example.ui.theme.MatteBlack
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.OnyxSurface
import com.example.ui.theme.SageMuted
import com.example.util.formatInr

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ProductDetailScreen(
    product: Product,
    isWishlisted: Boolean,
    storeSettings: StoreSettingsConfig,
    customerProfile: CustomerProfileEntity,
    savedAddresses: List<DeliveryAddress>,
    onBack: () -> Unit,
    onWishlistToggle: () -> Unit,
    onAddToCart: (ProductVariant, Int) -> Unit,
    onBuyNow: (
        variant: ProductVariant,
        quantity: Int,
        name: String,
        phone: String,
        address: String,
        paymentPreference: PaymentPreference,
        upiRef: String,
        launchWhatsApp: Boolean
    ) -> Unit,
    onOrderViaWhatsApp: (ProductVariant, Int) -> Unit
) {
    BackHandler(onBack = onBack)

    var selectedVariant by remember(product.id) { mutableStateOf(product.variants.first()) }
    var quantity by remember(product.id) { mutableIntStateOf(1) }
    var showBuyNowDialog by remember { mutableStateOf(false) }

    val mediaPages = remember(product.id, product.imageUrls) {
        if (product.imageUrls.isNotEmpty()) product.imageUrls else listOf("")
    }
    val pagerState = rememberPagerState(pageCount = { mediaPages.size })

    Scaffold(
        containerColor = MatteBlack,
        bottomBar = {
            Surface(
                color = OnyxSurface,
                border = BorderStroke(1.dp, ObsidianBorder),
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .navigationBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    EmeraldOutlinedButton(
                        text = "Add to Bag",
                        enabled = !product.isOutOfStock,
                        onClick = { onAddToCart(selectedVariant, quantity) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("detail_add_to_cart_button"),
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.ShoppingBag,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    )

                    GoldPrimaryButton(
                        text = if (product.isOutOfStock) "Out of Stock" else "Buy Now",
                        enabled = !product.isOutOfStock,
                        onClick = { showBuyNowDialog = true },
                        modifier = Modifier
                            .weight(1.1f)
                            .testTag("detail_buy_now_button"),
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Filled.Bolt,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Multi-image Hero Pager
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
                    .background(MatteBlack)
            ) {
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier.fillMaxSize()
                ) { page ->
                    ProductMediaImage(
                        imageUrl = mediaPages[page],
                        fallbackDrawableName = product.drawableResName,
                        contentDescription = "${product.name} image ${page + 1}",
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    MatteBlack.copy(alpha = 0.6f),
                                    Color.Transparent,
                                    MatteBlack
                                )
                            )
                        )
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("detail_back_button")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MatteBlack.copy(alpha = 0.72f))
                                .border(1.dp, ChampagneGold.copy(alpha = 0.5f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Go back",
                                tint = IvoryText
                            )
                        }
                    }

                    IconButton(
                        onClick = onWishlistToggle,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("detail_wishlist_button")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(MatteBlack.copy(alpha = 0.72f))
                                .border(1.dp, ChampagneGold.copy(alpha = 0.5f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isWishlisted) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                                contentDescription = if (isWishlisted) "Remove from wishlist" else "Save to wishlist",
                                tint = if (isWishlisted) ChampagneGold else IvoryText
                            )
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (mediaPages.size > 1) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            repeat(mediaPages.size) { index ->
                                val active = pagerState.currentPage == index
                                Box(
                                    modifier = Modifier
                                        .padding(horizontal = 3.dp)
                                        .size(if (active) 9.dp else 6.dp)
                                        .clip(CircleShape)
                                        .background(if (active) ChampagneGold else IvoryText.copy(alpha = 0.4f))
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = EmeraldVelvet,
                            border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.6f))
                        ) {
                            Text(
                                text = product.categoryName.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = IvoryText,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MatteBlack.copy(alpha = 0.85f),
                            border = BorderStroke(1.dp, if (product.isOutOfStock) ErrorRose else ChampagneGold)
                        ) {
                            Text(
                                text = when {
                                    product.isOutOfStock -> "OUT OF STOCK"
                                    product.isLowStock -> "ONLY ${product.stockCount} LEFT"
                                    else -> product.badge
                                },
                                style = MaterialTheme.typography.labelSmall,
                                color = if (product.isOutOfStock) ErrorRose else BrightGold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }

            Column(
                modifier = Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = product.name,
                        style = MaterialTheme.typography.displaySmall,
                        color = IvoryText
                    )
                    Text(
                        text = product.subtitle,
                        style = MaterialTheme.typography.titleSmall,
                        color = SageMuted
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.Bottom,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                text = formatInr(selectedVariant.priceInr * quantity),
                                style = MaterialTheme.typography.headlineMedium.copy(
                                    fontWeight = FontWeight.Bold
                                ),
                                color = BrightGold
                            )
                            if (product.originalPriceInr != null && product.originalPriceInr > product.priceInr) {
                                Text(
                                    text = formatInr(product.originalPriceInr * quantity),
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        textDecoration = TextDecoration.LineThrough
                                    ),
                                    color = SageMuted
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(50),
                            color = CharcoalElevated,
                            border = BorderStroke(1.dp, ObsidianBorder)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Star,
                                    contentDescription = null,
                                    tint = ChampagneGold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "${product.rating} · ${product.reviewCount} reviews",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = IvoryText
                                )
                            }
                        }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Select Size / Edition",
                        style = MaterialTheme.typography.titleSmall,
                        color = IvoryText
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        product.variants.forEach { variant ->
                            val isSelected = selectedVariant == variant
                            Surface(
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { selectedVariant = variant }
                                    .testTag("variant_${variant.label}"),
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) EmeraldVelvet else OnyxSurface,
                                border = BorderStroke(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) ChampagneGold else ObsidianBorder
                                )
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                                ) {
                                    Text(
                                        text = variant.label,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (isSelected) BrightGold else IvoryText
                                    )
                                    Text(
                                        text = formatInr(variant.priceInr),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SageMuted
                                    )
                                }
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Quantity",
                        style = MaterialTheme.typography.titleSmall,
                        color = IvoryText
                    )
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = OnyxSurface,
                        border = BorderStroke(1.dp, ObsidianBorder)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { if (quantity > 1) quantity-- },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("detail_qty_minus")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Remove,
                                    contentDescription = "Decrease quantity",
                                    tint = ChampagneGold
                                )
                            }
                            Text(
                                text = quantity.toString(),
                                style = MaterialTheme.typography.titleMedium,
                                color = IvoryText,
                                modifier = Modifier.padding(horizontal = 10.dp)
                            )
                            IconButton(
                                onClick = { if (quantity < product.stockCount.coerceAtLeast(1)) quantity++ },
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("detail_qty_plus")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Add,
                                    contentDescription = "Increase quantity",
                                    tint = ChampagneGold
                                )
                            }
                        }
                    }
                }

                WhatsAppOrderButton(
                    text = "Quick Order via WhatsApp (${storeSettings.whatsappNumber})",
                    onClick = { onOrderViaWhatsApp(selectedVariant, quantity) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("detail_whatsapp_order_button")
                )

                IslamicGeometricDivider()

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "Craft & Story",
                        style = MaterialTheme.typography.titleLarge,
                        color = BrightGold
                    )
                    Text(
                        text = product.description,
                        style = MaterialTheme.typography.bodyLarge,
                        color = IvoryText.copy(alpha = 0.92f)
                    )
                }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = EmeraldDeep.copy(alpha = 0.55f)),
                    border = BorderStroke(1.dp, ChampagneGold.copy(alpha = 0.35f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        val heading = if (product.category == ProductCategory.ISLAMIC_PRODUCTS) {
                            "Craftsmanship & Highlights"
                        } else {
                            "Fragrance Pyramid"
                        }
                        Text(
                            text = heading,
                            style = MaterialTheme.typography.titleLarge,
                            color = BrightGold
                        )
                        SpecRow(
                            label = if (product.category == ProductCategory.ISLAMIC_PRODUCTS) "Material" else "Top Notes",
                            value = product.topNotes
                        )
                        SpecRow(
                            label = if (product.category == ProductCategory.ISLAMIC_PRODUCTS) "Design" else "Heart Notes",
                            value = product.heartNotes
                        )
                        SpecRow(
                            label = if (product.category == ProductCategory.ISLAMIC_PRODUCTS) "Finish" else "Base Notes",
                            value = product.baseNotes
                        )
                        SpecRow(
                            label = "Origin / Spec",
                            value = product.originOrMaterial
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    if (showBuyNowDialog) {
        CheckoutModalDialog(
            title = "Express Checkout · ${product.name}",
            subtotalInr = selectedVariant.priceInr * quantity,
            storeSettings = storeSettings,
            initialProfile = customerProfile,
            savedAddresses = savedAddresses,
            onDismiss = { showBuyNowDialog = false },
            onConfirmOrder = { name, phone, address, pref, upiRef, launchWhatsApp ->
                showBuyNowDialog = false
                onBuyNow(selectedVariant, quantity, name, phone, address, pref, upiRef, launchWhatsApp)
            }
        )
    }
}

@Composable
private fun SpecRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = SageMuted,
            modifier = Modifier.weight(0.36f)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            color = IvoryText,
            modifier = Modifier.weight(0.64f)
        )
    }
}
