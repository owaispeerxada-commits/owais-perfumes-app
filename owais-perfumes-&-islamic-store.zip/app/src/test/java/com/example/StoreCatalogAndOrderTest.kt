package com.example

import com.example.data.local.CartItemEntity
import com.example.data.model.PaymentPreference
import com.example.data.model.ProductCategory
import com.example.data.model.StoreCatalog
import com.example.data.model.StoreConstants
import com.example.data.model.StoreSettingsConfig
import com.example.util.buildWhatsAppOrderMessage
import com.example.util.formatInr
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StoreCatalogAndOrderTest {

    @Test
    fun `catalog includes all 21 requested perfume attar and islamic product categories`() {
        val catNames = StoreCatalog.defaultCategories.map { it.name }.toSet()
        val expected = listOf(
            "Arabic Perfumes",
            "Luxury Perfumes",
            "Premium Perfumes",
            "Oud Collection",
            "Khamrah",
            "Wafa",
            "Mask Oud",
            "White Oud",
            "Roll-on Attar",
            "Long Lasting Fragrances",
            "Quran Pak",
            "Islamic Books",
            "Prayer Mats",
            "Islamic Topi",
            "Tasbeeh",
            "Digital Tasbeeh",
            "Miswak",
            "Islamic Wall Frames",
            "Islamic Gift Sets",
            "Hijab Accessories",
            "Other Islamic Essentials"
        )
        expected.forEach { requiredCat ->
            assertTrue("Missing category: $requiredCat", requiredCat in catNames)
        }

        val products = StoreCatalog.products
        assertTrue(products.isNotEmpty())
        assertTrue(products.any { it.category == ProductCategory.PERFUMES })
        assertTrue(products.any { it.category == ProductCategory.ATTARS })
        assertTrue(products.any { it.category == ProductCategory.ISLAMIC_PRODUCTS })
    }

    @Test
    fun `brand constants match official store identity`() {
        assertEquals("OWAIS PERFUMES & ISLAMIC STORE", StoreConstants.STORE_NAME)
        assertEquals("THE OWAIS OFFICIAL", StoreConstants.BRAND_OFFICIAL)
        assertEquals("Luxury Fragrances. Authentic Islamic Essentials.", StoreConstants.TAGLINE)
        assertEquals("+91 9906577880", StoreConstants.WHATSAPP_DISPLAY)
        assertEquals("@mrowais_15", StoreConstants.INSTAGRAM_HANDLE)
        assertEquals("Kupwara, Jammu & Kashmir, India", StoreConstants.STORE_LOCATION)
    }

    @Test
    fun `delivery charge calculation respects free delivery threshold`() {
        val settings = StoreSettingsConfig(deliveryChargeInr = 99, freeDeliveryThresholdInr = 1999)
        assertEquals(0, settings.calculateDeliveryCharge(0))
        assertEquals(99, settings.calculateDeliveryCharge(1499))
        assertEquals(0, settings.calculateDeliveryCharge(1999))
        assertEquals(0, settings.calculateDeliveryCharge(3500))
    }

    @Test
    fun `whatsapp order message formats items delivery payment and store details`() {
        val items = listOf(
            CartItemEntity(
                cartKey = "attar_kashmiri_saffron_oud_12 ml",
                productId = "attar_kashmiri_saffron_oud",
                productName = "Royal Kashmiri Saffron Oud Attar",
                categoryName = "Roll-on Attar",
                variantLabel = "12 ml",
                unitPriceInr = 1499,
                quantity = 2,
                drawableResName = "img_featured_oud"
            )
        )
        val msg = buildWhatsAppOrderMessage(
            orderId = "OWS-10001",
            items = items,
            totalAmountInr = 2998,
            customerName = "Owais",
            customerPhone = "+91 9906577880",
            deliveryAddress = StoreConstants.STORE_LOCATION,
            deliveryChargeInr = 0,
            paymentPreference = PaymentPreference.UPI,
            upiTransactionRef = "UTR412345678901"
        )

        assertTrue(msg.contains("Assalamu Alaikum"))
        assertTrue(msg.contains("THE OWAIS OFFICIAL"))
        assertTrue(msg.contains("OWS-10001"))
        assertTrue(msg.contains("Royal Kashmiri Saffron Oud Attar"))
        assertTrue(msg.contains(formatInr(2998)))
        assertTrue(msg.contains("UPI"))
        assertTrue(msg.contains("UTR412345678901"))
        assertTrue(msg.contains("Kupwara"))
    }
}
